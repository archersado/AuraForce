---
name: generate-app-data
description: 用于根据`详细设计.md`文档中的内容生成应用图数据（节点和边），使用前必须确保项目根目录下已经存在`详细设计.md`文档。本skill需要把 SKILL.md 的内容加载到对话上下文中，它不会自动执行任何代码或操作，需要你根据 SKILL.md 的指示来执行。
---

# 应用图数据生成

## 概述

应用图数据由应用名称、节点数据和关系数据组成，节点和关系有不同的类型，所有可供生成的节点类型和关系类型由[node-define.json](./references/node-define.json)和[edge-define.json](./references/edge-define.json)文档进行定义。而本skill的任务是从`详细设计.md`文档中提取包含节点和边的应用图数据，通过分析`详细设计.md`文档中的内容并提取约定类型的节点，以及节点之间的关系作为边，并输出为标准化的JSON格式文件。

## 工作流程

本skill的工作流程如下：

1. 确定并理解可以生成的节点类型；
2. 确定并理解可以生成的边类型；
3. 分析`详细设计.md`文档内容，明确提取的内容；
4. 生成一个业务对象子图，得到业务对象子图ID；
5. 分析需要生成的ai code接口子图数量，依次生成所有的ai code子图;
    - 5.1: 生成第一个ai code接口子图，得到第一个ai code子图ID;
    - 5.2: 生成第二个ai code接口子图，得到第二个ai code子图ID;
    - 5.3: 生成第三个ai code接口子图，得到第三个ai code子图ID;
    - 5.n: 生成第N个ai code接口子图，得到第N个ai code子图ID;
6. 明确应用图数据中节点数据的格式及规则；
7. 明确应用图数据中边数据的格式及规则；
8. 生成并保存应用图数据；
9. 检查生成的数据文件内容是否符合要求；
10. 通过脚本提交应用图数据。

**接下来将对工作流程中每个步骤将要完成的任务进行详细说明。**

### 步骤1：明确可生成的节点类型

读取 [node-define.json](./references/node-define.json) 文档，掌握并理解所有可生成的节点类型定义，节点类型定义中的属性如下：

- `scene`: 节点的使用场景，值为`common`、`logic`或`paper`:
  - `common`: 通用的默认场景，只要不是logic或paper，就属于此类场景
  - `logic`: 业务逻辑
  - `paper`: 子图
- `type`: 此节点定义的类型，是生成的节点数据中`type`属性的值来源；
- `name`: 节点定义的名称；
- `description`: 节点定义的使用场景、约束条件等说明；
- `properties`: 可选属性，代表节点的属性定义数组，表示当生成节点时，可以为该节点生成哪些属性的值。

### 步骤2：明确可生成的边类型

读取 [edge-define.json](./references/edge-define.json) 文档，掌握并理解所有可生成的边类型定义，边类型定义中的属性如下：

- `type`: 此边定义的类型，是生成的边数据中`type`属性的值来源；
- `name`: 边定义的名称；
- `description`: 边定义的使用场景、约束条件等说明；

### 步骤3：分析`详细设计.md`文档内容

**仔细阅读并理解提供的详细设计.md文档：**

1. 根据提供的节点类型定义数据，识别需要从`详细设计.md`中生成的节点及其属性值；
2. 根据提供的边类型定义数据，识别需要从`详细设计.md`中生成的关系；

**需要考虑的关键问题：**

- 文档中的哪些内容是节点？
- 文档中的哪些内容是关系？
- 节点和节点之间的关系是什么？
- 节点上可确定的属性值是什么？

### 步骤4：为应用生成业务对象子图

在应用图数据中，必须有一个业务对象子图，这个子图包含了`详细设计.md`提及到的所有业务对象。

使用skill `generate-biz-object-data`生成业务对象子图，可以得到业务对象的子图ID。

### 步骤5：为业务逻辑代码或交互卡片生成AI Code接口子图

ai code子图，也可以叫http接口子图或ai code接口子图，代表的是要实现的http接口，一个ai code子图表示【业务逻辑-代码】的具体实现或【交互卡片】需要调用的接口。

在应用图数据中，每一个【业务逻辑-代码】，都必须关联一个ai code子图；不同的【业务逻辑-代码】，可以关联到同一个ai code子图。【交互卡片】与ai code子图的关联关系是可选的，如果没有明确的提及，则不需要为【交互卡片】关联ai code子图(卡片不一定会调用接口)。如果【业务逻辑-代码】实现的业务逻辑与【交互卡片】需要的接口逻辑一致，则可以关联到同一个ai code子图。

使用skill `generate-ai-code-data`生成对应的ai code子图，可以得到ai code子图ID。如果有多个ai code子图需要生成，则需要调用多次`generate-ai-code-data` skill。

### 步骤6：明确应用图数据中节点数据的格式及规则

根据 [node-define.json](./references/node-define.json) 定义的节点类型数据确定所有可供提取的节点类型，不是所有类型的节点都需要提取。对于生成的节点，其生成的数据格式如下：

```json
{
    "id": "节点的唯一数字标识符，从数字1开始递增",
    "type": "节点的类型，用于标识生成的节点属于哪种类型的节点，值来自于节点定义中的`type`",    
    "name": "根据实际的业务含义生成的中文名称",
    "description": "根据实际的业务含义生成的业务描述，如果此节点为logic-code，则为详细的业务实现逻辑说明",
    "paperId":"子图ID，仅`paper`子图节点有此属性",
    "properties": [
        {
            "name": "属性名称，是节点类型定义中的properties属性定义的属性名称name",
            "value": "属性值，数据类型默认是字符串，如果属性的description有特殊说明，则以属性description中的为准"
        }
    ]
}

```

**注意事项：**

1. 只有当对应的节点类型定义中存在`properties`属性时，才需要为生成的节点数据生成`properties`属性；
2. 只有当对应的节点类型定义中`scene`的值为`paper`子图时，才需要为生成的节点数据生成`paperId`属性。

**重要指南：**

- id需要保证唯一，且从数字1开始递增；
- name需要保证唯一；
- type必须是[node-define.json](./references/node-define.json)定义中节点的type；
- 子图节点必须有`paperId`属性；
- 确保命名约定的一致性。

### 步骤7：明确应用图数据中边数据的格式及规则

根据 [edge-define.json](./references/edge-define.json) 的边定义类型数据确定所有可供提取的边类型，不是所有类型的边都需要提取。对于生成的边，其生成的数据格式如下：

```json
{
    "sourceId": "源节点id",
    "targetId": "目标节点id",
    "type": "边的类型，用于标识生成的边属于哪种类型的边，值来自于边定义中的`type`"
}

```

**重要指南：**

- 节点之间的关系在[edge-define.json](./references/edge-define.json)中进行定义；
- 方向很重要：source → target；
- 节点之间可以存在不同的关系；
- 确保sourceId和targetId在nodes中存在；
- 避免相同sourceId、targetId和type的重复边。

### 步骤8：生成并保存应用图数据到`app.json`文件中

**按以下格式生成JSON，并将JSON内容写入到项目根目录下的`app.json`文件中：**

```json
{
    "name": "根据实际的业务含义生成的清晰简洁的应用中文名称",
    "nodes":[
        {
            "id": "节点的唯一数字标识符，从数字1开始递增",
            "type": "节点的类型，用于标识生成的节点属于哪种类型的节点，值来自于节点定义中的`type`",    
            "name": "根据实际的业务含义生成的中文名称",
            "description": "根据实际的业务含义生成的业务描述，如果此节点为logic-code，则为详细的业务实现逻辑说明",
            "paperId":"子图ID，仅`paper`子图节点有此属性",
            "properties": [
                {
                    "name": "属性名称，是节点类型定义中的properties属性定义的属性名称name",
                    "value": "属性值，数据类型默认是字符串，如果属性的description有特殊说明，则以属性description中的为准"
                }
            ]
        }
    ],
    "edges":[
        {
            "sourceId": "源节点id",
            "targetId": "目标节点id",
            "type": "边的类型，用于标识生成的边属于哪种类型的边，值来自于边定义中的`type`"
        }
    ]
}
```

**验证清单：**

- [ ] 所有节点ID唯一，且从数字1开始递增
- [ ] 所有节点名称唯一
- [ ] 所有节点`type`有效（来自于[node-define.json](./references/node-define.json)中的type）
- [ ] 所有节点`properties`符合其节点的定义
- [ ] 子图节点`paperId`存在
- [ ] 所有边的source/target ID引用现有节点
- [ ] 所有边`type`有效（来自于[edge-define.json](./references/edge-define.json)中的type）
- [ ] 无重复边
- [ ] JSON格式正确且有效

### 步骤9：审查和优化

**最终确定之前：**

1. **完整性**：是否捕获了所有重要概念？
2. **准确性**：节点和边是否正确表示文档？
3. **一致性**：命名约定和结构是否一致？
4. **清晰性**：描述是否清晰且富有信息？
5. **关系**：是否捕获了所有重要关系？

**需要检查的常见问题：**

- 未生成业务对象子图
- 缺少被引用概念的节点
- 错误的边方向
- 错误的边类型
- 不完整的properties
- 不一致的命名

### 步骤10: 执行脚本提交数据

⚠️ **重要：禁止修改脚本代码！**

通过执行提供的`submit_app_data.py`脚本，将生成的应用图数据提交。

```bash
python .claude/skills/generate-app-data/scripts/submit_app_data.py
```

脚本执行后，将输出图数据ID。

## 最佳实践建议

1. **要全面**：不要遗漏隐式关系或概念
2. **保持一致**：在整个过程中使用一致的命名和结构
3. **要具体**：选择最具体的节点和边类型
4. **添加上下文**：包含有意义的描述和属性
5. **进行验证**：始终检查ID匹配和结构正确性

## 资源

- **[node-define.json](./references/node-define.json)**：所有节点类型及其含义的完整参考
- **[edge-define.json](./references/edge-define.json)**：所有边类型及其含义的完整参考
