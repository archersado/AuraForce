---
description: 'Generates or updates an index.md of all documents in the specified directory'
---

# Index Docs

LOAD and execute the task at: _bmad/core/tasks/index-docs.xml

Follow all instructions in the task file exactly as written.
