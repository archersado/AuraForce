#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import os
import uuid

import requests

env = os.getenv('ENV', 'fat').lower()

ENV_CONFIG = {
    "dev": {
        "url": "https://dt-biz-base.dev.ennew.com",
        "access_key": "",
        "metaPaperId": 60298
    },
    "fat": {
        "url": "https://rdfa-gateway.fat.ennew.com/dt-biz-base",
        "access_key": "Ksjt8LZgr7dgeBVQhkbS6pNYvdMS51R4",
        "metaPaperId": 60298
    },
    "uat": {
        "url": "https://rdfa-gateway.uat.ennew.com/dt-biz-base",
        "access_key": "TsKwADFuHBGYXdfUVi4t7A2fckOLReH8",
        "metaPaperId": 60298
    },
    "prod": {
        "url": "https://rdfa-gateway.ennew.com/dt-biz-base",
        "access_key": "9GeND2MF703TwYh3XQj1crMlz3Yp4eYi",
        "metaPaperId": 60298
    }
}

def call_data_twin(data):
    try:
        response = requests.post(
            url=f'{ENV_CONFIG[env]["url"]}/api/aiModel/meta/generateSubMetaModel',
            json=data,
            headers={
                "Content-Type": "application/json",
                "x-gw-accesskey": ENV_CONFIG[env]["access_key"]
            }
        )
        response_data = response.json()
        if response_data.get("code", "") != "0":
            raise Exception(response_data.get("message", "未知错误"))
        return response_data.get("data").get("paperId")
    except Exception as e:
        print(f"提交数据失败: {str(e)}")
        return None

def load_json_file(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"文件 {filepath} 不存在")
        return None

def submit_data():
    if not os.path.exists("biz-object.json"):
        print("未找到biz-object.json文件，请先生成业务对象子图数据文件，然后再进行提交！")
        return None

    biz_object_data = load_json_file("biz-object.json")
    node_uuid_map = {}

    transformed_data = {
        "name": biz_object_data.get("name", "业务对象子元"),
        "metaPaperId": ENV_CONFIG[env]["metaPaperId"],
        "appSource": "agentos_model",
        "nodes": [],
        "edges": []
    }

    # 转换节点
    for node in biz_object_data.get("nodes", []):
        generated_uuid = uuid.uuid4().hex
        node_uuid_map[node.get("id")] = generated_uuid
        transformed_node = {
            "uuid": generated_uuid,
            "name": node.get('name'),
            "domainName": "业务实体",
            "nodeType": "common",
            "description": node.get("description"),
            "properties": []
        }

        # 转换属性
        for prop in node.get("properties", []):
            transformed_prop = {
                "modelFieldCode": prop.get("code"),
                "modelFieldType": prop.get("dataType"),
                "modelFieldName": prop.get("name")
            }
            transformed_node["properties"].append(transformed_prop)

        transformed_data["nodes"].append(transformed_node)

    # 转换边
    for edge in biz_object_data.get("edges", []):
        transformed_edge = {
            "sourceId": node_uuid_map[edge.get("sourceId")],
            "targetId": node_uuid_map[edge.get("targetId")],
            "name": "关联"
        }
        transformed_data["edges"].append(transformed_edge)

    paper_id = call_data_twin(transformed_data)
    if paper_id is not None:
        print(f"业务对象的子图ID是: {paper_id}")
        graph_data = load_json_file("biz-object.json")
        graph_data["paperId"] = paper_id
        with open("biz-object.json", 'w', encoding='utf-8') as f:
            json.dump(graph_data, f, indent=4, ensure_ascii=False)
        return paper_id
    else:
        print(f"业务对象的子图ID获取失败")
        return None

if __name__ == "__main__":
    submit_data()
