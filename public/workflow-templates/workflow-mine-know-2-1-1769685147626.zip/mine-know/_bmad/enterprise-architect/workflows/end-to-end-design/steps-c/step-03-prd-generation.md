---
name: 'step-03-prd-generation'
description: '产品需求文档生成'

# File References
nextStepFile: './step-04-interaction-generation.md'
sidecarMemory: '{project-root}/_bmad/_memory/domain-consultant-sidecar/memories.md'
outputFolder: '{output_folder}/enterprise-architect'
---

# Step 3: PRD Generation（产品需求文档生成）

## STEP GOAL

基于 Step 2 完成的完整领域知识模型,生成**产品说明书的第一部分（产品需求）**。

## MANDATORY EXECUTION RULES

### Universal Rules:

- 🛑 NEVER use Write tool after creating initial framework
- 📖 CRITICAL: Use Edit tool for ALL content updates
- 🔄 CRITICAL: Progressive editing - replace ONE placeholder at a time
- 📋 YOU ARE A FACILITATOR, generating content section by section
- ✅ YOU MUST ALWAYS SPEAK OUTPUT in your Agent communication style with the config `{communication_language}`

### Step-Specific Rules:

- ✅ YOU ARE Arthur, continuing from Step 2
- ✅ Load complete domain model from sidecar memory
- ✅ Invoke domain-prd-generator skill
- ✅ Generate PRD content following skill guidelines
- ✅ **PROGRESSIVE EDITING PROTOCOL**:
  1. Use Write tool ONCE to create document framework
  2. Use Edit tool to replace each `*（正在生成...）*` placeholder
  3. Inform user after EACH section is completed
  4. NEVER overwrite entire document after initial creation

## EXECUTION PROTOCOLS

### Protocol 1: Load Complete Domain Model

```
【Step 3: PRD Generation - 产品需求文档生成】

我已经加载了 Step 2 中完成的完整领域模型。

现在我将基于这个模型生成产品说明书的第一部分（产品需求）,包含：
- 产品概述
- 功能需求
- 数据模型
- 业务规则

让我开始生成文档...
```

### Protocol 2: Invoke domain-prd-generator Skill

- Use the Skill tool to invoke `domain-prd-generator`
- This loads the PRD generation guidelines into context
- Input: Complete domain model from sidecar memory

### Protocol 3: Generate PRD Content

**CRITICAL**: Follow the detailed PRD structure from reference document `output/enterprise-architect/采购管理系统/PRD.md`

Follow the transformation steps from the skill:

**1. 产品定义章节**:
- 背景: 从 Business Context 提取核心痛点（列表格式）
- 产品定位: 定义目标用户和核心能力
- 核心业务逻辑: 输入 → 处理流程 → 关键规则判断 → 输出
- 目标用户: 创建用户角色表格（角色、职责、使用场景）

**2. 用户旅程章节**:
- 为每个关键用户故事创建详细旅程, 概述用户与核心功能的关系
- 格式: "第一步,[角色]执行[动作],[系统响应];"
- 包含正常流程和异常流程

**3. 功能清单章节**:
- 创建功能清单表格（功能名称、描述、优先级P0/P1/P2、依赖关系、备注）
- 从领域实体和业务规则推导功能

**4. 核心功能说明章节**:
- 为每个P0功能创建详细说明
- 包含: 功能详细描述、触发条件、处理步骤、特殊情况处理
- 包含: 输入输出、业务逻辑、界面交互说明

**5. 数据模型章节**:
- 为每个核心实体创建详细定义
- 包含: 属性表格、生命周期、状态说明表格
- 实体关系图（文本格式）

**6. 业务规则章节**:
- 为每个业务规则创建 BR-XXX 编号
- 包含: 描述、触发条件、执行动作、例外情况、标准依据

### Protocol 4: Create and Fill PRD Document

**🚨 CRITICAL - PROGRESSIVE EDITING PROTOCOL 🚨**

**Step 4.1: Create Document Framework (Use Write Tool ONCE)**

Use Write tool to create the document framework at: `{outputFolder}/{project-name}/产品说明书.md`

```markdown
# 【项目名称】需求文档(PRD)

**项目名称**: [Project Name]
**版本**: 1.0
**创建日期**: [Date]
**创建者**: Enterprise Architect AI (Arthur)
**状态**: Draft
**基于**: Complete Domain Model from Step 2
**生成时间**: [timestamp]

---

# 产品定义

## 背景
*（正在生成...）*

## 产品定位
*（正在生成...）*

## 核心业务逻辑
*（正在生成...）*

## 目标用户
*（正在生成...）*

---

# 用户旅程
*（正在生成...）*

---

# 功能清单
*（正在生成...）*

---

# 核心功能说明
*（正在生成...）*

---

# 数据模型
*（正在生成...）*

---

# 业务规则
*（正在生成...）*

---

## 第二部分：交互设计
*（将在 Step 4 中生成）*

---

**附录**:
- 行业标准列表: 见领域模型
- 业务规则列表: 见领域模型
- 实体定义: 见领域模型
- 状态转换图: 见领域模型
```

Inform user: "✅ 文档框架已创建，开始逐步填充内容..."

**Step 4.2: Fill Content Section by Section (Use Edit Tool for EACH Section)**

**🚨 CRITICAL RULES 🚨**
- ✅ Use Edit tool to replace ONE `*（正在生成...）*` placeholder at a time
- ✅ Inform user after EACH section is completed
- ❌ NEVER use Write tool again (it will overwrite everything)
- ❌ NEVER skip sections or batch multiple replacements

**CRITICAL**: Follow the detailed structure from `output/enterprise-architect/采购管理系统/PRD.md`

**Execution Sequence:**

**1. Fill 产品定义章节:**
- Replace `*（正在生成...）*` in 背景 section with actual content
- Replace `*（正在生成...）*` in 产品定位 section with actual content
- Replace `*（正在生成...）*` in 核心业务逻辑 section with actual content
- Replace `*（正在生成...）*` in 目标用户 section with actual content
- Inform user: "✅ 产品定义章节已完成"

**2. Fill 用户旅程章节:**
- Replace `*（正在生成...）*` with detailed user journey content
- Format: "第一步,[角色]执行[动作],[系统响应];"
- Inform user: "✅ 用户旅程章节已完成"

**3. Fill 功能清单章节:**
- Replace `*（正在生成...）*` with function list table
- Include: 功能名称、描述、优先级P0/P1/P2、依赖关系、备注
- Inform user: "✅ 功能清单章节已完成"

**4. Fill 核心功能说明章节:**
- Replace `*（正在生成...）*` with detailed P0 function descriptions
- For each function: 功能详细描述、输入输出、业务逻辑、界面交互说明
- Inform user: "✅ 核心功能说明章节已完成"

**5. Fill 数据模型章节:**
- Replace `*（正在生成...）*` with entity definitions
- Include: 属性表格、生命周期、状态说明表格、实体关系图
- Inform user: "✅ 数据模型章节已完成"

**6. Fill 业务规则章节:**
- Replace `*（正在生成...）*` with BR-XXX formatted rules
- Include: 描述、触发条件、执行动作、例外情况、标准依据
- Inform user: "✅ 业务规则章节已完成"

**🎯 VERIFICATION CHECKPOINT:**
After all sections are filled, verify:
- ✅ All `*（正在生成...）*` placeholders have been replaced
- ✅ Document structure is intact
- ✅ Each section has substantive content
- ✅ "## 第二部分：交互设计" placeholder remains (for Step 4)

**🚨 REMEMBER: Each section replacement must use Edit tool, NOT Write tool! 🚨**

### Protocol 5: Confirm Generation

```
✅ 产品说明书（第一部分：产品需求）已生成！

文档位置: {outputFolder}/{project-name}/产品说明书.md

这份文档采用企业级PRD结构,包含：

**产品定义**:
- 背景（核心痛点）
- 产品定位（目标用户 + 核心能力）
- 核心业务逻辑（输入-处理-输出）
- 目标用户表格

**用户旅程**:
- 详细的步骤描述（第一步...第N步）

**功能清单**:
- 功能表格（名称、描述、优先级P0/P1/P2、依赖、备注）

**核心功能说明**:
- 功能详细描述、触发条件、处理步骤
- 输入输出、业务逻辑、界面交互说明

**数据模型**:
- 实体详细定义（属性表格、生命周期、状态说明）
- 实体关系图

**业务规则**:
- BR-XXX 格式化规则（触发条件、执行动作、例外情况）

请查看文档,确认内容是否准确。我们将在 Step 4 中追加交互设计部分。
```

Wait for user confirmation.

### Protocol 6: Phase Summary

```
【Step 3 完成 - PRD 生成总结】

✅ 产品说明书（第一部分）已完成！

接下来,我们将进入 Step 4（交互设计生成）,在产品说明书中追加交互设计部分。

准备好继续了吗？
```

## MENU OPTIONS

Display: "**Select an Option:** [C] Continue to Step 4 (Interaction Generation) | [R] Regenerate PRD | [S] Save and Exit"

### Menu Handling Logic:

- IF C: Update workflow status to "Step 3 Complete", then load and read entire file {nextStepFile}
- IF R: Return to Protocol 3 to regenerate PRD
- IF S: Save current state, update workflow status to "Paused at Step 3"
- IF Any other comments or queries: help user respond then redisplay menu options

## SUCCESS METRICS

### ✅ SUCCESS:

- Complete domain model loaded successfully
- domain-prd-generator skill invoked
- PRD content generated following skill guidelines
- Document saved using Write tool
- User confirms document is satisfactory

### ❌ SYSTEM FAILURE:

- Domain model not loaded
- Skill not invoked
- PRD content not generated
- Document not saved
- Proceeding without user confirmation

---

**Step Created**: 2026-01-27
**Agent**: Arthur (Domain Consultant)
**Next Step**: step-04-interaction-generation.md
**Output**: 产品说明书.md (Part 1: PRD)
