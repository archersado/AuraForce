---
name: generate-ai-code-data
description: 用于根据`详细设计.md`文档中的内容生成ai-code接口子图数据（节点和边），使用前必须确保项目根目录下已经存在`详细设计.md`文档。本skill需要把 SKILL.md 的内容加载到对话上下文中，它不会自动执行任何代码或操作，需要你根据 SKILL.md 的指示来执行。
---

# ai code子图数据生成

## 概述

将`详细设计.md`文档转换为包含节点和边的结构化图数据。本skill分析`详细设计.md`文档并提取指定类型的节点，以及节点之间的关系作为边，并输出为标准化的JSON格式; 使用前必须确保项目根目录下已经存在`详细设计.md`文档。

## 工作流程

### 步骤1：确定节点类型

读取 [node-define.json](./references/node-define.json) 文档，掌握并理解所有可生成的节点。

### 步骤2：确定边类型

读取 [edge-define.json](./references/edge-define.json) 文档，掌握并理解所有可生成的边。

### 步骤3：文档分析

**仔细阅读并理解提供的详细设计.md文档：**

1. 根据提供的节点类型定义数据识别节点及其属性值；
2. 根据提供的边类型定义数据识别节点之间存在的关系。

**需要考虑的关键问题：**

- 文档中的哪些内容是节点？
- 文档中的哪些内容是关系？
- 节点和节点之间的关系是什么？
- 节点上可确定的属性值是什么？

### 步骤4：提取节点(重要)

根据 [node-define.json](./references/node-define.json) 的节点定义数据确定所有可供提取的节点类型，不是所有的类型的节点都需要提取，必须为每个节点提取：

- `id`：节点的唯一数字标识符，从数字1开始递增；
- `type`：节点类型编码，用于标识生成的节点属于哪种类型，值来自于[node-define.json](./references/node-define.json)节点定义中的`type`；
- `name`：节点的中文名称,该值根据文档中的实际业务数据提取而来, **并非**[node-define.json](./references/node-define.json)节点定义中的`name`, 并且提取的每个节点的name都不能重复；
- `description`：清晰简洁的节点业务描述或逻辑描述。

**关于 properties 的特殊处理：**

1. **预定义属性的节点**（如 ai-coding、interface、interface-input、interface-output、logic-point）：
   - 如果对应的节点类型定义了`properties`属性，则需要为节点生成`properties`属性值
   - 生成的值是一个对象数组，结构如下：

   ```json
   [
     {
       "name": "属性名称，值来自于节点定义中的properties数组中对象的name定义",
       "value": "识别到的属性值"
     }
   ]
   ```

2. **业务对象本体节点 business-object（特殊处理）**：
   - 该节点类型的 properties 在定义中为空数组，但需要**根据 PRD 文档动态生成**
   - **生成条件**：只有当接口入参或出参的数据类型为**对象**或**对象数组**时才生成该节点
   - 具体方法：在 PRD 文档中找到该业务对象的层级结构，提取其内部字段作为 properties
   - **properties 数组内部的对象只包含 `name` , `dataType`和`code` 三个属性**
   - `name`为属性的中文名, `dataType`为属性的数据类型,`code`是属性的英文名
   - `dataType`为属性的数据类型, 其枚举为: String, Number,ObjectArray, Date, DateTime,Time, Object,Array,Bool
   - 注意当某个字段的类型在文档中的类型是Array, 但实际你提取到的类型是对象数组时, 请将其`dataType`字段设置为`ObjectArray`,因为Array表示的是普通数组, 而ObjectArray表示的是对象数组
   - 示例：
     - 如果 PRD 中有 `用户信息：对象类型`，下面列出：
       - 用户ID（userId）：123456
       - 昵称（nickname）：张三
     - 则对应的 business-object 节点 properties 应为：
     ```json
     [
       {
         "name": "用户ID",
         "dataType": "String",
         "code": "userID"
       },
       {
         "name": "昵称",
         "dataType": "String",
         "code": "nickName"
       }
     ]
     ```

   **嵌套 business-object 的处理**：
   - 如果一个 business-object 的某个属性的数据类型也为**对象(Object)**或**对象数组(ObjectArray)**，需要为该属性再生成新的 business-object 节点
   - 新生成的 business-object 节点由**父 business-object 指向**，通过 `bo-ref-object` 类型的边连接（注意：这里type使用edge-define.json定义的type字段值"bo-ref-object"，而非name字段值"child-object"）
   - **重要**：边的 `type` 字段值应为该属性在父 business-object 中 properties 数组的 `code` 属性值（即该对象属性的英文名）
   - 嵌套可以有多层，形成业务对象的层级结构

**重要指南：**

- id需要保证唯一，且从数字1开始递增；
- name需要保证唯一；
- type必须是[node-define.json](./references/node-define.json)定义中节点的type；
- 对于 business-object 节点，必须从 PRD 文档中提取完整的层级结构来生成 properties；
- 确保命名约定的一致性。

### 步骤5：提取边

**为每条边指定：**

- `sourceId`：源节点ID
- `targetId`：目标节点ID
- `type`：边的类型名称，值来自于[edge-define.json](./references/edge-define.json)中定义中的`type`（注意：使用的是type字段值，而非name字段值;但对于嵌套business-object，应使用父级对象中该属性的code作为type）。

**重要指南：**

- 节点之间的关系在[edge-define.json](./references/edge-define.json)中进行定义；
- 方向很重要：source → target；
- 节点之间可以存在不同的关系；
- 确保sourceId和targetId在nodes中存在；
- 避免相同sourceId、targetId和type的重复边。

### 步骤6：生成输出

**按以下格式生成JSON，并将JSON内容写入到项目根目录下的`ai-code-{enName}.json`文件中，其中`{enName}`需要替换为代表该子图业务含义的英文名称：**

```json
{
  "name": "子图中文名称，名称不要包含'子图', 不要直接使用`AI Coding应用`作为名称,从文档中提取具有实际业务含义的名称",
  "nodes": [
    {
      "id": "节点的唯一数字标识符，从数字1开始递增",
      "type": "节点的类型编码",
      "name": "节点的中文名称,从文档中提取实际的业务名称",
      "description": "节点的业务描述信息",
      "properties": [
        {
          "name": "属性名称",
          "value": "属性值"
        }
      ]
    }
  ],
  "edges": [
    {
      "sourceId": "源节点id",
      "targetId": "目标节点id",
      "type": "边的类型"
    }
  ]
}
```

**验证清单：**

- [ ] 所有节点ID唯一，且从数字1开始递增
- [ ] 所有节点的`name`都不重复
- [ ] 所有节点`type`有效（来自于[node-define.json](./references/node-define.json)中的type）
- [ ] 所有节点`properties`符合其节点的定义
- [ ] business-object节点仅在入参/出参数据类型为对象(Object)或对象数组(ObjectArray)时生成
- [ ] business-object的properties包含name、dataType、code三个属性
- [ ] 嵌套business-object正确生成，父节点的对象(Object)/对象数组(ObjectArray)字段对应了子节点
- [ ] 嵌套business-object之间通过bo-ref-object类型的边连接
- [ ] 嵌套business-object的边的type字段值为对应字段的code属性（英文名）
- [ ] 所有边的sourceId和targetId 引用现有节点
- [ ] 所有边`type`有效（来自于[edge-define.json](./references/edge-define.json)中的type），注意使用type字段值而非name字段值
- [ ] 无重复边
- [ ] JSON格式正确且有效
- [ ] 生成的文件名符合格式`ai-code-{enName}.json`，且`{enName}`被替换为代表该子图业务含义的英文名称

### 步骤7：审查和优化

**最终确定之前：**

1. **完整性**：是否捕获了所有重要概念？
2. **准确性**：节点和边是否正确表示文档？
3. **一致性**：命名约定和结构是否一致？
4. **清晰性**：描述是否清晰且富有信息？
5. **关系**：是否捕获了所有重要关系？

**需要检查的常见问题：**

- 缺少被引用概念的节点
- 错误的边方向
- 错误的边类型（注意使用edge-define.json中的type字段值，而非name字段值）
- 不完整的properties
- 不一致的命名
- 每个节点的`name`是否存在重复情况

### 步骤8: 执行脚本提交数据

⚠️ **重要：禁止修改脚本代码！**

通过执行提供的`submit_ai_code_data.py`脚本，将生成的ai code子图数据提交，由此可得到子图ID。此脚本接收`name`和`file`两个参数：

- name: 代表子图的中文名称，即`步骤6`中生成的子图中文名称
- file: 子图数据文件，即在`步骤6`中生成的格式为`ai-code-{enName}.json`的文件

***脚本使用示例***

```bash
python .claude/skills/generate-ai-code-data/scripts/submit_ai_code_data.py --name 学生管理系统后台 --file ai-code-student-mgt-api.json
```

> 注意：示例中的`name`参数值`学生管理系统后台`和`file`参数值`ai-code-student-mgt-api.json`需要被当前子图的真实数据替换。


## 最佳实践建议

1. **要全面**：不要遗漏隐式关系或概念
2. **保持一致**：在整个过程中使用一致的命名和结构
3. **要具体**：选择最具体的节点和边类型
4. **添加上下文**：包含有意义的描述和属性
5. **进行验证**：始终检查ID匹配和结构正确性

## 资源

- **[node-define.json](./references/node-define.json)**：所有节点类型及其含义的完整参考
- **[edge-define.json](./references/edge-define.json)**：所有边类型及其含义的完整参考
