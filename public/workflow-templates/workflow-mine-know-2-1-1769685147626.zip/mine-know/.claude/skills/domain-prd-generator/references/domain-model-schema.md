# Domain Model Schema

This document describes the expected structure of the domain knowledge model that serves as input for PRD generation.

## Domain Model Location

The domain model is stored in Arthur's sidecar memory:
```
{project-root}/_bmad/_memory/domain-consultant-sidecar/memories.md
```

## Expected Structure

### 1. Business Context

**Purpose**: Describes the business background, industry context, and core problems being solved.

**Format**:
```markdown
## Business Context

[Industry background]
[Current pain points]
[Business opportunities]
[Strategic objectives]
```

**Used in PRD**: Section 1.1 (Business Context), Section 1.2 (Problem Statement)

### 2. Key Scenarios

**Purpose**: Detailed descriptions of how users interact with the system in real-world situations.

**Format**:
```markdown
## Key Scenarios

### Scenario 1: [Scenario Name]
**Actor**: [User role]
**Goal**: [What they want to achieve]
**Steps**:
1. [Step 1]
2. [Step 2]
...

**Success Criteria**: [How to measure success]
**Exceptions**: [What can go wrong]
```

**Used in PRD**: Section 2.1 (User Stories), Section 1.3 (Target Users)

### 3. Domain Entities

**Purpose**: Core business objects and their attributes.

**Format**:
```markdown
## Domain Entities

### Entity: [Entity Name]
**Description**: [What this entity represents]

**Attributes**:
- [attribute_name] ([type]): [description]
- [attribute_name] ([type], required): [description]

**Lifecycle States**: [state1] → [state2] → [state3]

**Business Rules**:
- [Rule affecting this entity]
```

**Used in PRD**: Section 4.1 (Core Entities), Section 4.2 (Entity Relationships)

### 4. Relationships

**Purpose**: How entities connect and interact with each other.

**Format**:
```markdown
## Relationships

### [Entity A] ↔ [Entity B]
**Type**: One-to-Many / Many-to-Many / One-to-One
**Description**: [How they relate]
**Cardinality**: [min..max]
**Constraints**: [Any restrictions]
```

**Used in PRD**: Section 4.2 (Entity Relationships)

### 5. Business Rules

**Purpose**: Constraints, validations, and business logic that govern system behavior.

**Format**:
```markdown
## Business Rules

### BR-[ID]: [Rule Name]
**Description**: [What the rule enforces]
**Trigger**: [When this rule applies]
**Action**: [What happens]
**Exceptions**: [Special cases]
**Priority**: High/Medium/Low
```

**Used in PRD**: Section 5 (Business Rules)

### 6. Constraints

**Purpose**: Technical and business limitations that affect the solution.

**Format**:
```markdown
## Constraints

### Technical Constraints
- [Constraint 1]
- [Constraint 2]

### Business Constraints
- [Constraint 1]
- [Constraint 2]

### Regulatory Constraints
- [Constraint 1]
- [Constraint 2]
```

**Used in PRD**: Section 3 (Non-Functional Requirements), Section 7 (Constraints)

### 7. State Transitions

**Purpose**: How entities change state over their lifecycle.

**Format**:
```markdown
## State Transitions

### [Entity Name] State Machine

**States**: [state1], [state2], [state3]

**Transitions**:
- [state1] → [state2]: [trigger/condition]
- [state2] → [state3]: [trigger/condition]

**Terminal States**: [final states]
```

**Used in PRD**: Section 4.1 (Entity Lifecycle)

### 8. Integration Points

**Purpose**: External systems and interfaces the solution must connect with.

**Format**:
```markdown
## Integration Points

### Integration: [System Name]
**Type**: API / File / Database / Message Queue
**Direction**: Inbound / Outbound / Bidirectional
**Data Format**: JSON / XML / CSV / etc.
**Authentication**: [Method]
**Frequency**: Real-time / Batch / On-demand
**Critical**: Yes/No
```

**Used in PRD**: Section 6 (Integration Requirements)

## Validation Checklist

Before generating PRD, verify the domain model contains:

- [ ] Business Context with clear problem statement
- [ ] At least 3 key scenarios with detailed steps
- [ ] All core entities with attributes and lifecycle
- [ ] Relationships between entities with cardinality
- [ ] Business rules with triggers and actions
- [ ] Technical and business constraints
- [ ] State transitions for stateful entities
- [ ] Integration points with external systems (if applicable)

## Example Domain Model

See `references/example-domain-model.md` for a complete example of a well-structured domain model.
