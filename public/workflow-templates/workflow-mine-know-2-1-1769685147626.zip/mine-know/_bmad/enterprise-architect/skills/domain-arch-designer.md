---
name: domain-arch-designer
description: 基于领域知识模型和PRD生成技术架构设计文档
skill_type: document-generator
---

# Domain Architecture Designer

**Purpose**: 将领域知识模型和PRD需求转化为结构化的技术架构设计文档（Architecture.md），包含系统架构、技术选型、数据架构和部署架构。

---

## Skill Goal

从完整的领域知识模型和PRD文档生成企业级技术架构文档，文档应：
- 符合 TOGAF/4A 企业架构标准
- 清晰定义系统架构和技术选型
- 满足所有功能和非功能需求
- 可直接用于技术实施和开发

---

## Input Requirements

### Required Input

**Domain Model** (from Arthur's sidecar):
```markdown
# Complete Domain Model

## Business Context
[业务背景和痛点]

## Key Scenarios
[详细的业务场景]

## Domain Entities
[实体定义，包含属性和生命周期]

## Relationships
