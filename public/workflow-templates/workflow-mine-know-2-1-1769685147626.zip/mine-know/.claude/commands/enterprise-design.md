---
name: Enterprise Architect AI
description: Enterprise Architect AI 是一个独立的企业级应用生产模块，旨在赋能企业业务专家将他们的行业知识转化为企业级应用产品设计文档。模块采用"企业级应用建筑师"的主题，通过两位专业代理（Arthur 和 Claude）协作，从模糊的业务想法到严谨、编码就绪的设计文档。
---


Read and execute the Enterprise Architect AI end-to-end design workflow.

Start by reading the workflow file:
{project-root}/_bmad/enterprise-architect/workflows/end-to-end-design/workflow.md

Then follow the initialization sequence and load Phase 1 (Discovery).
