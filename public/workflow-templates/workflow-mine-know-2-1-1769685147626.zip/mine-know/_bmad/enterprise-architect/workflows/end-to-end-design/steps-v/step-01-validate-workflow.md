---
name: 'step-01-validate-workflow'
description: '验证工作流本身的 BMAD v6 合规性'
---

# Validate Workflow: end-to-end-design-v6

## VALIDATION GOAL

验证 end-to-end-design-v6 工作流是否符合 BMAD v6 标准和最佳实践。

## VALIDATION SCOPE

This validation checks the workflow itself (not the documents it generates). It verifies:

1. **File Structure Compliance**: Correct folder structure (steps-c/, steps-v/, steps-e/, data/, templates/)
2. **Step File Format**: All step files follow BMAD v6 format
3. **Protocol Completeness**: All required protocols are present
4. **Menu Options**: Proper menu options and handling logic
5. **State Management**: Correct sidecar memory usage
6. **Agent Handoff**: Clear handoff protocols between Arthur and Claude
7. **Documentation**: Complete and accurate workflow.md

## VALIDATION CHECKLIST

### 1. File Structure

- [ ] `workflow.md` exists and is complete
- [ ] `steps-c/` folder exists with all 4 step files
- [ ] `steps-v/` folder exists with validation step
- [ ] `steps-e/` folder exists with edit steps
- [ ] `data/` folder exists
- [ ] `templates/` folder exists with both templates

### 2. Step Files (Create Mode)

#### step-01-discovery-prd.md
- [ ] Frontmatter with name, description, file references
- [ ] STEP GOAL clearly defined
- [ ] MANDATORY EXECUTION RULES present
- [ ] All 9 protocols present and complete
- [ ] MANDATORY SEQUENCE defined
- [ ] MENU OPTIONS with proper handling logic
- [ ] SUCCESS METRICS defined
- [ ] Protocol 8 includes domain-prd-generator skill invocation
- [ ] Generates 产品说明书.md Part 1

#### step-02-refinement-interaction.md
- [ ] Frontmatter with name, description, file references
- [ ] STEP GOAL clearly defined
- [ ] MANDATORY EXECUTION RULES present
- [ ] All 9 protocols present and complete
- [ ] MANDATORY SEQUENCE defined
- [ ] MENU OPTIONS with proper handling logic
- [ ] SUCCESS METRICS defined
- [ ] Protocol 8 includes interaction-mapper skill invocation
- [ ] Appends to existing 产品说明书.md (does not overwrite)

#### step-03-architecture.md
- [ ] Frontmatter with name, description, file references
- [ ] STEP GOAL clearly defined
- [ ] MANDATORY EXECUTION RULES present
- [ ] All 3 protocols present and complete
- [ ] MANDATORY SEQUENCE defined
- [ ] MENU OPTIONS with proper handling logic
- [ ] SUCCESS METRICS defined
- [ ] Protocol 2 includes domain-arch-designer skill invocation
- [ ] Generates independent 详细设计.md

#### step-04-validation.md
- [ ] Frontmatter with name, description, file references
- [ ] STEP GOAL clearly defined
- [ ] MANDATORY EXECUTION RULES present
- [ ] All 9 protocols present and complete
- [ ] MANDATORY SEQUENCE defined
- [ ] MENU OPTIONS with proper handling logic
- [ ] SUCCESS METRICS defined
- [ ] Validates TWO documents (not three)
- [ ] Backtracking mechanism to step-02

### 3. Workflow.md

- [ ] Frontmatter with name, description, version, web_bundle
- [ ] "What's New in V6" section
- [ ] Workflow Architecture section
- [ ] Workflow Steps table (4 steps)
- [ ] Initialization Sequence
- [ ] Phase Handoff Protocol (Arthur ↔ Claude)
- [ ] Backtracking Mechanism
- [ ] State Management
- [ ] Output Structure (2 documents)
- [ ] Tri-Modal Structure explanation
- [ ] Critical Success Factors
- [ ] Error Handling
- [ ] Skills Required section

### 4. Templates

- [ ] product-spec-template.md exists
- [ ] product-spec-template.md has Part 1 (Requirements) structure
- [ ] product-spec-template.md has Part 2 (Interaction) structure
- [ ] architecture-template.md exists
- [ ] architecture-template.md has three-layer structure

### 5. Agent Handoff

- [ ] Arthur → Claude handoff clearly defined (Step 2 → Step 3)
- [ ] Claude → Arthur handoff clearly defined (Step 3 → Step 4)
- [ ] Sidecar memory used for domain model transfer
- [ ] Output folder used for document transfer

### 6. Progressive Document Generation

- [ ] Step 1 generates 产品说明书.md Part 1
- [ ] Step 2 APPENDS Part 2 to existing document
- [ ] Step 3 generates INDEPENDENT 详细设计.md
- [ ] Final output is 2 documents (not 3)

### 7. Backtracking Mechanism

- [ ] Backtracking from Step 4 to Step 2 defined
- [ ] Issue context saved to sidecar
- [ ] Maximum backtrack count enforced (3)
- [ ] User confirmation required before backtracking

## VALIDATION RESULTS

### ✅ PASSED

[List all checks that passed]

### ❌ FAILED

[List all checks that failed with details]

### ⚠️ WARNINGS

[List any warnings or recommendations]

## RECOMMENDATIONS

Based on validation results, here are recommendations for improvement:

1. [Recommendation 1]
2. [Recommendation 2]
3. [Recommendation 3]

## VALIDATION SUMMARY

**Total Checks**: [X]
**Passed**: [Y]
**Failed**: [Z]
**Warnings**: [W]

**Overall Status**: [PASS / FAIL / PASS WITH WARNINGS]

---

**Validation Date**: [Date]
**Validator**: [Name]
**Workflow Version**: 6.0.0
