---
name: 'step-04-interaction-generation'
description: '交互设计文档生成'

# File References
nextStepFile: './step-05-architecture.md'
sidecarMemory: '{project-root}/_bmad/_memory/domain-consultant-sidecar/memories.md'
outputFolder: '{output_folder}/enterprise-architect'
---

# Step 4: Interaction Generation（交互设计文档生成）

## STEP GOAL

基于完整的领域知识模型和已生成的 PRD,在产品说明书中**追加第二部分（交互设计）**。

## MANDATORY EXECUTION RULES

### Universal Rules:

- 🛑 NEVER use Write tool - document already exists!
- 📖 CRITICAL: Use Edit tool for ALL content updates
- 🔄 CRITICAL: Append mode - DO NOT overwrite Part 1 (PRD)
- 📋 YOU ARE A FACILITATOR, appending content section by section
- ✅ YOU MUST ALWAYS SPEAK OUTPUT in your Agent communication style with the config `{communication_language}`

### Step-Specific Rules:

- ✅ YOU ARE Arthur, continuing from Step 3
- ✅ Load complete domain model from sidecar memory
- ✅ Read existing 产品说明书.md (contains Part 1: PRD)
- ✅ Apply conversational application design paradigm
- ✅ Include Mermaid user journey diagrams
- ✅ **APPEND-ONLY PROTOCOL**:
  1. NEVER use Write tool (will overwrite Part 1!)
  2. Use Edit tool to replace the Part 2 placeholder
  3. Use Edit tool to replace each `*（正在生成...）*` in Part 2
  4. Inform user after EACH section is completed
  5. CRITICAL: Part 1 (PRD) must remain unchanged!

## EXECUTION PROTOCOLS

### Protocol 1: Load Resources

```
【Step 4: Interaction Generation - 交互设计文档生成】

我已经加载了：
- Step 2 中完成的完整领域模型
- Step 3 中生成的产品需求文档

现在我将在产品说明书中追加第二部分（交互设计）,包含：
- 交互设计范式
- 用户旅程（含 Mermaid 图表）
- 界面设计
- 交互流程
- 卡片/页面说明
- 状态管理

让我开始生成交互设计...
```

### Protocol 2: Load Interaction Design Paradigm

**CRITICAL**: All interaction designs MUST follow the conversational application paradigm:

**PC端设计范式**:
- 左侧: 会话式聊天窗口（框架已有，无需描述）
- 右侧: 应用工作区（框架已有，无需描述）

**移动端设计范式**:
- 单一会话界面（框架已有，无需描述）
- 核心交互方式: UI 交互卡片

**设计约束**:
- 会话优先、卡片承载、应用扩展、上下文连贯

**🎯 FOCUS: 交互设计应聚焦在实际交互内容，而非框架描述：**
- ✅ 重点描述：卡片类型、GUI应用、它们的形态和交互行为
- ✅ 基于 PRD 的产品功能设计具体交互
- ❌ 不要过多描述会话框架和应用工作区（已有现成框架）

### Protocol 3: Invoke interaction-mapper Skill

- Use the Skill tool to invoke `interaction-mapper`
- This loads the interaction design generation guidelines into context
- Input: Complete domain model + existing PRD content + Interaction Design Paradigm

### Protocol 4: Generate Interaction Design Content

**CRITICAL**: Focus on interaction content, not framework description

**Generation Focus:**
- ✅ **Based on PRD functions**: Extract all P0/P1 functions from PRD
- ✅ **Design interaction cards**: For each function, design corresponding cards
- ✅ **Design GUI applications**: For complex functions, design GUI apps
- ✅ **Card forms**: Define card layout, elements, and interactions
- ✅ **User journey with Mermaid**: Visualize user flow with emotion scores (1-5)
- ❌ **Don't over-describe**: Framework itself (chat window, workspace) - already implemented

**Content to Generate:**
1. User Journey Maps (with Mermaid journey diagrams) - based on PRD user stories
2. Interaction Card Catalog - list all cards derived from PRD functions
3. GUI Application Catalog - list all GUI apps for complex functions
4. Card/App Specifications - detailed design for each card/app

### Protocol 5: Append Interaction Design to Existing Document

**🚨 CRITICAL - APPEND-ONLY PROTOCOL 🚨**

**⚠️ WARNING: Part 1 (PRD) already exists in this document! DO NOT overwrite it! ⚠️**

**Step 5.1: Replace Part 2 Placeholder with Framework (Use Edit Tool)**

**CRITICAL**: Use Edit tool to find and replace the placeholder:
- Read existing document from: `{outputFolder}/{project-name}/产品说明书.md`
- Find: `## 第二部分：交互设计\n*（将在 Step 4 中生成）*`
- Replace with the interaction design framework (see below)

```markdown
## 第二部分：交互设计

### 0. 交互设计说明

**设计范式**: 会话式应用
- PC端：左侧会话窗口 + 右侧应用工作区（框架已实现）
- 移动端：单一会话界面 + UI交互卡片（框架已实现）

**设计聚焦**: 本文档重点描述基于 PRD 功能的具体交互内容（卡片和GUI应用），而非框架本身。

---

### 1. 用户旅程

#### 1.1 核心用户旅程（Mermaid 图表）
*（正在生成...）*

#### 1.2 详细旅程描述
*（正在生成...）*

---

### 2. 交互卡片目录

**说明**: 以下卡片基于 PRD 中的产品功能设计，每个卡片对应一个或多个功能。

#### 2.1 卡片清单
*（正在生成...）*

#### 2.2 卡片规格说明
*（正在生成...）*

---

### 3. GUI 应用目录

**说明**: 以下 GUI 应用用于承载复杂功能，在应用工作区中展示。

#### 3.1 应用清单
*（正在生成...）*

#### 3.2 应用规格说明
*（正在生成...）*

---

### 4. 交互流程设计

#### 4.1 卡片触发与交互流程
*（正在生成...）*

#### 4.2 GUI 应用打开与操作流程
*（正在生成...）*

#### 4.3 跨卡片/应用协作流程
*（正在生成...）*

---

### 5. 状态管理

#### 5.1 交互状态定义
*（正在生成...）*

#### 5.2 实体状态映射
*（正在生成...）*
```

Inform user: "✅ 交互设计框架已追加到产品说明书，开始逐步填充内容..."

**Step 5.2: Fill Content Section by Section (Use Edit Tool for EACH Section)**

**🚨 CRITICAL RULES 🚨**
- ✅ Use Edit tool to replace ONE `*（正在生成...）*` in Part 2 at a time
- ✅ Inform user after EACH section is completed
- ❌ NEVER use Write tool (will overwrite Part 1!)
- ❌ NEVER edit anything in Part 1 (PRD content)
- ❌ NEVER skip sections or batch multiple replacements

**CRITICAL**: Apply the conversational application paradigm to ALL designs

**Execution Sequence:**

**1. Fill 交互设计说明:**
- Replace `*（正在生成...）*` in "### 0. 交互设计说明" section with:
  - 简要说明会话式应用框架（1-2句话）
  - 强调本文档聚焦在交互内容而非框架本身
- Inform user: "✅ 交互设计说明已完成"

**2. Fill 核心用户旅程（Mermaid 图表）:**
- Replace `*（正在生成...）*` in "#### 1.1 核心用户旅程（Mermaid 图表）" section with:
  - **MUST include Mermaid journey diagrams** for key user stories from PRD
  - Use emotion scores (1-5) in journey diagrams
  - Example format:
    ```mermaid
    journey
        title 用户完成XX功能的旅程
        section 阶段1
          步骤1: 5: 用户
          步骤2: 3: 用户
    ```
- Inform user: "✅ 核心用户旅程（含 Mermaid 图表）已完成"

**3. Fill 详细旅程描述:**
- Replace `*（正在生成...）*` in "#### 1.2 详细旅程描述" section with:
  - 详细分析表格（阶段、用户行为、触点、情绪、痛点、机会点）
  - 基于 PRD 的用户故事
- Inform user: "✅ 详细旅程描述已完成"

**4. Fill 卡片清单:**
- Replace `*（正在生成...）*` in "#### 2.1 卡片清单" section with:
  - **从 PRD 功能清单中提取功能，为每个功能设计对应的卡片**
  - 创建卡片清单表格：
    | 卡片名称 | 对应功能 | 使用场景 | 触发方式 | 优先级 |
  - 示例：
    - 订单确认卡片 → 对应"订单管理"功能 → 用户下单后展示 → 自动触发 → P0
    - 库存查询卡片 → 对应"库存查询"功能 → 用户询问库存时展示 → 意图识别 → P1
- Inform user: "✅ 卡片清单已完成"

**5. Fill 卡片规格说明:**
- Replace `*（正在生成...）*` in "#### 2.2 卡片规格说明" section with:
  - **为每个卡片（至少P0卡片）创建详细规格**
  - 每个卡片包含：
    - **卡片形态**: 布局结构（用 ASCII 图或文字描述）
    - **卡片元素**: 列表所有 UI 元素（按钮、文本、输入框等）
    - **输入参数**: 卡片需要的数据
    - **交互行为**: 用户可以进行的操作
    - **触发事件**: 点击按钮后触发什么
  - 示例：
    ```
    ### 订单确认卡片

    **卡片形态**:
    ┌─────────────────────────┐
    │ 订单确认                │
    │ 订单号: #12345          │
    │ 金额: ¥299.00          │
    │ [确认] [取消]           │
    └─────────────────────────┘

    **卡片元素**:
    - 标题: "订单确认"
    - 订单号显示
    - 金额显示
    - 确认按钮
    - 取消按钮

    **输入参数**:
    - orderId: 订单ID
    - amount: 订单金额

    **交互行为**:
    - 点击"确认": 调用确认订单业务逻辑
    - 点击"取消": 关闭卡片

    **触发事件**:
    - onConfirm: 订单确认事件
    - onCancel: 取消事件
    ```
- Inform user: "✅ 卡片规格说明已完成"

**6. Fill 应用清单:**
- Replace `*（正在生成...）*` in "#### 3.1 应用清单" section with:
  - **从 PRD 功能清单中识别需要 GUI 应用的复杂功能**
  - 创建应用清单表格：
    | 应用名称 | 对应功能 | 使用场景 | 打开方式 | 优先级 |
  - 示例：
    - 订单管理面板 → 对应"订单管理"功能 → 批量处理订单 → 从会话或卡片打开 → P0
    - 报表分析应用 → 对应"数据分析"功能 → 查看业务报表 → 从菜单打开 → P1
  - **注意**: 简单功能用卡片，复杂功能用 GUI 应用
- Inform user: "✅ 应用清单已完成"

**7. Fill 应用规格说明:**
- Replace `*（正在生成...）*` in "#### 3.2 应用规格说明" section with:
  - **为每个应用（至少P0应用）创建详细规格**
  - 每个应用包含：
    - **应用形态**: 界面布局（用 ASCII 图或文字描述主要区域）
    - **功能模块**: 应用包含的功能模块列表
    - **主要界面元素**: 列表、表格、表单、按钮等
    - **交互行为**: 用户可以进行的操作
    - **数据展示**: 展示哪些业务数据
  - 示例：
    ```
    ### 订单管理面板

    **应用形态**:
    ┌────────────────────────────────────┐
    │ 顶部：筛选条件（日期、状态等）     │
    ├────────────────────────────────────┤
    │ 中部：订单列表表格                 │
    │   - 订单号 | 客户 | 金额 | 状态   │
    │   - [详情] [处理] [取消]          │
    ├────────────────────────────────────┤
    │ 底部：分页控件                     │
    └────────────────────────────────────┘

    **功能模块**:
    - 订单筛选
    - 订单列表展示
    - 订单详情查看
    - 订单状态处理
    - 批量操作

    **主要界面元素**:
    - 日期选择器
    - 状态下拉框
    - 订单表格（支持排序）
    - 操作按钮组
    - 分页控件

    **交互行为**:
    - 筛选订单：选择条件后自动刷新列表
    - 查看详情：点击"详情"打开订单详情
    - 处理订单：点击"处理"弹出处理对话框
    - 批量操作：勾选多个订单后批量处理

    **数据展示**:
    - 订单列表（来自订单实体）
    - 订单状态（来自业务规则）
    - 客户信息（来自用户实体）
    ```
- Inform user: "✅ 应用规格说明已完成"

**8. Fill 卡片触发与交互流程:**
- Replace `*（正在生成...）*` in "#### 4.1 卡片触发与交互流程" section with:
  - 用户输入 → 意图识别 → 卡片渲染 → 用户操作 → 业务逻辑 → 状态更新
  - 为每种卡片描述典型流程
- Inform user: "✅ 卡片触发与交互流程已完成"

**9. Fill GUI 应用打开与操作流程:**
- Replace `*（正在生成...）*` in "#### 4.2 GUI 应用打开与操作流程" section with:
  - 触发方式 → 应用打开 → 数据加载 → 用户操作 → 数据同步 → 结果反馈
  - 为每个应用描述典型流程
- Inform user: "✅ GUI 应用打开与操作流程已完成"

**10. Fill 跨卡片/应用协作流程:**
- Replace `*（正在生成...）*` in "#### 4.3 跨卡片/应用协作流程" section with:
  - 描述卡片与应用之间的协作关系
  - 示例：从订单确认卡片跳转到订单管理面板
- Inform user: "✅ 跨卡片/应用协作流程已完成"

**11. Fill 交互状态定义:**
- Replace `*（正在生成...）*` in "#### 5.1 交互状态定义" section with:
  - 卡片状态（显示/隐藏、加载中、错误等）
  - 应用状态（打开/关闭、数据加载状态等）
- Inform user: "✅ 交互状态定义已完成"

**12. Fill 实体状态映射:**
- Replace `*（正在生成...）*` in "#### 5.2 实体状态映射" section with:
  - 领域实体与卡片/应用状态的映射关系
  - 示例：订单实体状态 → 订单卡片显示内容
- Inform user: "✅ 实体状态映射已完成"

**🎯 VERIFICATION CHECKPOINT:**
After all sections in Part 2 are filled, verify:
- ✅ All `*（正在生成...）*` in Part 2 have been replaced
- ✅ Part 1 (PRD) remains completely unchanged
- ✅ Mermaid user journey diagrams are included
- ✅ **卡片清单基于 PRD 功能清单生成**
- ✅ **每个卡片都有详细的形态和交互设计**
- ✅ **GUI 应用基于复杂功能设计**
- ✅ **每个应用都有详细的界面布局和功能描述**
- ✅ Conversational application paradigm is applied
- ✅ Document structure is intact

**🚨 CRITICAL REMINDER: 🚨**
- ❌ NEVER use Write tool in this step!
- ❌ NEVER modify Part 1 content!
- ✅ Only Edit placeholders in Part 2 (Interaction Design)
- ✅ **Focus on interaction content (cards & GUI apps), not framework description**

### Protocol 6: Confirm Generation

```
✅ 产品说明书（第二部分：交互设计）已追加！

文档位置: {outputFolder}/{project-name}/产品说明书.md

现在这份文档包含了完整的两部分：
- 第一部分：产品需求（Step 3 生成）
- 第二部分：交互设计（刚刚追加）

**第二部分内容聚焦在实际交互：**
- ✅ 用户旅程（包含 Mermaid 可视化图表）
- ✅ **交互卡片目录**（基于 PRD 功能清单设计）
  - 卡片清单：列出所有卡片及其对应功能
  - 卡片规格：详细描述每个卡片的形态、元素、交互行为
- ✅ **GUI 应用目录**（为复杂功能设计的应用）
  - 应用清单：列出所有 GUI 应用及其对应功能
  - 应用规格：详细描述每个应用的界面布局、功能模块、交互行为
- ✅ 交互流程（卡片、应用、跨组件协作）
- ✅ 状态管理

请查看完整文档,确认交互设计内容是否准确。
```

Wait for user confirmation.

### Protocol 7: Phase Summary

```
【Step 4 完成 - 交互设计生成总结】

✅ 产品说明书（完整版）已完成！

文档包含：
- 第一部分：产品需求 ✓
- 第二部分：交互设计 ✓
  - Mermaid 用户旅程图 ✓
  - **交互卡片目录**（基于 PRD 功能） ✓
  - **GUI 应用目录**（基于复杂功能） ✓
  - 交互流程设计 ✓
  - 状态管理 ✓

**设计聚焦**: 交互内容（卡片形态、GUI 应用界面）而非框架本身

接下来,我们将进入 Step 5（技术架构生成）,Claude 将基于完整的领域模型
和产品说明书生成独立的详细设计。

准备好继续了吗？
```

## MENU OPTIONS

Display: "**Select an Option:** [C] Continue to Step 5 (Architecture) | [R] Regenerate Interaction | [S] Save and Exit"

### Menu Handling Logic:

- IF C: Update workflow status to "Step 4 Complete", prepare handoff to Claude, then load and read entire file {nextStepFile}
- IF R: Return to Protocol 4 to regenerate interaction design
- IF S: Save current state, update workflow status to "Paused at Step 4"
- IF Any other comments or queries: help user respond then redisplay menu options

## SUCCESS METRICS

### ✅ SUCCESS:

- Complete domain model and PRD loaded successfully
- Interaction design paradigm loaded
- interaction-mapper skill invoked
- **Mermaid user journey diagrams included**
- **Conversational application paradigm applied**
- **交互卡片目录基于 PRD 功能清单生成**
- **每个卡片有详细的形态和交互设计**
- **GUI 应用基于复杂功能设计**
- **每个应用有详细的界面布局和功能描述**
- **设计聚焦在交互内容，而非框架描述**
- Content appended using Edit tool
- **Part 1 content preserved**
- User confirms document is satisfactory

### ❌ SYSTEM FAILURE:

- Resources not loaded
- Skill not invoked
- **Mermaid diagrams not included**
- **Paradigm not applied**
- **卡片未基于 PRD 功能设计**
- **卡片缺少详细形态和交互说明**
- **GUI 应用缺少界面布局描述**
- **过度描述会话框架而非交互内容**
- **Part 1 content overwritten**
- Document not saved
- Proceeding without user confirmation

---

**Step Created**: 2026-01-27
**Agent**: Arthur (Domain Consultant)
**Next Step**: step-05-architecture.md
**Output**: 产品说明书.md (Complete: Part 1 + Part 2)
