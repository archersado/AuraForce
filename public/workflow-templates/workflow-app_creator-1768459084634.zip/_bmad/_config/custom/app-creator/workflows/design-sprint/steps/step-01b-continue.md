---
name: 'step-01b-continue'
description: 'Handle workflow continuation'
---

# Step 1b: Continuation

Handle existing design workflow continuation with resume options.