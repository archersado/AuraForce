---
name: interaction-mapper
description: 基于领域知识模型和PRD生成用户旅途与交互说明文档
skill_type: document-generator
---

# Interaction Mapper

**Purpose**: 将领域知识模型和PRD用户故事转化为结构化的用户旅途与交互说明文档（Interaction.md），包含用户旅程地图、UI/UX流程和交互模式。

---

## Skill Goal

从完整的领域知识模型和PRD文档生成用户交互设计文档，文档应：
- 清晰定义用户旅程和关键触点
- 描述UI/UX流程和交互模式
- 与PRD用户故事保持一致
- 可直接用于UI/UX设计和前端开发

---

## Input Requirements

### Required Input

**Domain Model** (from Arthur's sidecar):
```markdown
# Complete Domain Model

## Business Context
[业务背景和痛点]

## Key Scenarios
[详细的业务场景]

## Domain Entities
[实体定义，包含属性和生命周期]

## Relationships
[实体间关系，包含基数和约束]

## Business Rules
[业务规则，包含例外情况]

## State Transitions
[关键实体的状态转换]
```

**PRD Document** (from Phase 3):
```markdown
# PRD.md

## User Stories
[用户故事列表，包含验收标准]

## Functional Modules
[功能模块定义]

## Data Model
[核心实体和关系]
```

### Optional Input

- UI/UX design guidelines (UI/UX设计指南)
- Brand style guide (品牌风格指南)
- Accessibility requirements (无障碍访问要求)

---

## Interaction Design Paradigm (交互设计范式)

**CRITICAL**: All interaction designs MUST follow the **Conversational Application Paradigm** (会话式应用设计范式).

### PC端设计范式

**布局结构**:
- **左侧区域**: 会话式聊天窗口 (Conversational Chat Window)
  - 用户通过自然语言对话与系统交互
  - 系统响应形式: 文本消息、UI交互卡片、应用触发指令
  - UI交互卡片支持内嵌操作(按钮、表单、选择器、数据展示等)
  - 卡片可触发右侧应用工作区打开对应的GUI应用

- **右侧区域**: 应用工作区 (Application Workspace)
  - 展示完整的GUI应用界面
  - 由左侧会话中的交互卡片触发打开
  - 支持多应用标签页切换
  - 应用可以向左侧会话发送消息和卡片反馈

### 移动端设计范式

**布局结构**:
- **单一会话界面**: 全屏会话式交互
  - 核心交互方式: UI交互卡片
  - 卡片内嵌操作和信息展示
  - 轻量级操作直接在卡片内完成
  - 重度操作打开全屏H5移动端应用

### 设计约束

1. **会话优先原则**: 所有功能入口必须通过会话式交互触发
2. **卡片承载原则**: 中等复杂度操作通过交互卡片承载
3. **应用扩展原则**: 重度应用通过工作区(PC)或H5(移动)展示
4. **上下文连贯原则**: 保持会话上下文,应用操作结果反馈到会话

### 交互层级

- **Level 1 - 文本对话**: 简单查询、指令、确认
- **Level 2 - 交互卡片**: 表单填写、选项选择、数据展示、快捷操作
- **Level 3 - GUI应用**: 复杂数据编辑、可视化分析、多步骤流程

---

## Output Format

### Interaction.md Structure

```markdown
# 用户旅途与交互说明 (User Journey & Interaction Specification)
# Interaction Design Document

**项目名称**: [Project Name]
**版本**: 1.0
**创建日期**: [Date]
**创建者**: Enterprise Architect AI
**状态**: Draft

---

## 1. 用户角色定义 (User Roles)

### 角色 1: [Role Name]
**描述**: [从 Key Scenarios 中提取的用户角色描述]
**目标**: [用户目标]
**痛点**: [用户痛点]
**技术熟练度**: 初级/中级/高级
**使用场景**: [主要使用场景]

[为每个识别的用户角色创建定义]

---

## 2. 用户旅程地图 (User Journey Maps)

### 旅程 1: [Journey Name]
**对应用户故事**: US-XXX (from PRD)
**用户角色**: [Role Name]
**目标**: [Journey Goal]

#### 2.1 旅程可视化图 (Journey Visualization)

**CRITICAL**: 必须使用 Mermaid journey 语法绘制用户旅程图。

```mermaid
journey
    title [用户旅程名称]
    section [阶段1名称]
      [步骤1描述]: [情绪分数1-5]: [角色名称]
      [步骤2描述]: [情绪分数1-5]: [角色名称]
    section [阶段2名称]
      [步骤3描述]: [情绪分数1-5]: [角色名称]
      [步骤4描述]: [情绪分数1-5]: [角色名称]
    section [阶段3名称]
      [步骤5描述]: [情绪分数1-5]: [角色名称]
```

**情绪分数说明**:
- 5分: 非常满意 😊 (用户体验极佳)
- 4分: 满意 🙂 (用户体验良好)
- 3分: 一般 😐 (用户体验中等,有改进空间)
- 2分: 不满意 😞 (用户体验较差,需要优化)
- 1分: 非常不满意 😡 (用户体验很差,严重问题)

**示例**:
```mermaid
journey
    title 用户完成订单购买旅程
    section 发现商品
      浏览商品列表: 4: 用户
      查看商品详情: 5: 用户
    section 下单购买
      添加到购物车: 4: 用户
      填写收货信息: 3: 用户
      选择支付方式: 3: 用户
    section 完成支付
      确认订单信息: 4: 用户
      完成支付: 5: 用户
      收到确认通知: 5: 用户
```

#### 2.2 旅程阶段详细说明 (Journey Stages)

| 阶段 | 用户行为 | 触点 | 情绪 | 痛点 | 机会点 |
|------|---------|------|------|------|--------|
| 发现 | [用户如何发现功能] | [接触点] | 😊/😐/😞 | [痛点] | [改进机会] |
| 探索 | [用户如何探索功能] | [接触点] | 😊/😐/😞 | [痛点] | [改进机会] |
| 使用 | [用户如何使用功能] | [接触点] | 😊/😐/😞 | [痛点] | [改进机会] |
| 完成 | [用户如何完成任务] | [接触点] | 😊/😐/😞 | [痛点] | [改进机会] |

[为每个关键用户故事创建旅程地图]

---

## 3. 交互流程 (Interaction Flows)

### 流程 1: [Flow Name]
**对应用户故事**: US-XXX (from PRD)
**触发条件**: [What triggers this flow]
**前置条件**: [Prerequisites]

#### 流程步骤 (Flow Steps)

```
[用户] → [系统响应] → [用户] → [系统响应]

1. 用户: [Action]
   └─> 系统: [Response]
       └─> 显示: [UI Element]
       └─> 状态: [State Change]

2. 用户: [Action]
   └─> 系统: [Response]
       └─> 显示: [UI Element]
       └─> 状态: [State Change]

[继续直到流程完成]
```

**成功路径**: [Happy path description]
**异常路径**: [Error handling paths]
**退出点**: [Exit points]

[为每个关键交互创建流程图]

---

## 4. 界面结构 (Interface Structure)

### 4.1 信息架构 (Information Architecture)

```
应用根目录
├── 首页 (Home)
│   ├── [功能模块 1]
│   ├── [功能模块 2]
│   └── [功能模块 3]
├── [主要功能区 1]
│   ├── [子功能 1.1]
│   ├── [子功能 1.2]
│   └── [子功能 1.3]
├── [主要功能区 2]
│   ├── [子功能 2.1]
│   └── [子功能 2.2]
└── 设置 (Settings)
    ├── 用户设置
    └── 系统设置
```

### 4.2 导航模式 (Navigation Patterns)

**主导航**: [Tab Bar / Side Menu / Top Navigation]
**次级导航**: [Breadcrumbs / Back Button / Tabs]
**快捷操作**: [FAB / Quick Actions / Shortcuts]

---

## 5. 界面设计规范 (UI Design Specifications)

### 5.1 页面模板 (Page Templates)

#### 模板 1: [Template Name]
**用途**: [When to use this template]
**布局**: [Layout description]

**组件结构**:
```
┌─────────────────────────────────┐
│  Header (导航栏)                 │
├─────────────────────────────────┤
│  Content Area (内容区)           │
│  ┌───────────────────────────┐  │
│  │ [主要内容]                 │  │
│  │                           │  │
│  └───────────────────────────┘  │
├─────────────────────────────────┤
│  Footer / Actions (操作区)       │
└─────────────────────────────────┘
```

[为每种主要页面类型创建模板]

### 5.2 关键界面 (Key Screens)

#### 界面 1: [Screen Name]
**对应功能**: F-XXX (from PRD)
**用户故事**: US-XXX (from PRD)

**界面元素**:
- **标题**: [Screen Title]
- **主要内容**: [Main content description]
- **操作按钮**: [Primary actions]
- **次要操作**: [Secondary actions]
- **数据展示**: [Data display format]

**状态变化**:
- 加载中: [Loading state]
- 空状态: [Empty state]
- 错误状态: [Error state]
- 成功状态: [Success state]

[为每个关键功能创建界面规范]

---

## 6. 交互模式 (Interaction Patterns)

### 6.1 数据输入模式 (Data Input Patterns)

#### 表单输入 (Form Input)
**使用场景**: [When to use]
**组件**: [Input fields, dropdowns, date pickers, etc.]
**验证规则**: [Validation rules from Business Rules]
**错误提示**: [Error message patterns]

#### 搜索与筛选 (Search & Filter)
**使用场景**: [When to use]
**搜索类型**: [Keyword / Advanced / Faceted]
**筛选选项**: [Filter options based on entities]

### 6.2 数据展示模式 (Data Display Patterns)

#### 列表视图 (List View)
**使用场景**: [When to use]
**数据项**: [List item structure]
**排序选项**: [Sort options]
**分页**: [Pagination strategy]

#### 详情视图 (Detail View)
**使用场景**: [When to use]
**信息层次**: [Information hierarchy]
**相关数据**: [Related data display]

### 6.3 操作反馈模式 (Feedback Patterns)

#### 成功反馈
**类型**: Toast / Modal / Inline message
**持续时间**: [Duration]
**内容**: [Success message template]

#### 错误反馈
**类型**: Toast / Modal / Inline message
**持续时间**: [Duration]
**内容**: [Error message template]
**恢复操作**: [Recovery actions]

#### 加载反馈
**类型**: Spinner / Progress bar / Skeleton screen
**使用场景**: [When to use each type]

---

## 7. 状态管理 (State Management)

### 7.1 实体状态映射 (Entity State Mapping)

#### 实体: [Entity Name]
**状态来源**: Domain Model State Transitions

| 状态 | UI 表现 | 可用操作 | 状态指示器 |
|------|---------|---------|-----------|
| [State 1] | [UI representation] | [Available actions] | [Status indicator] |
| [State 2] | [UI representation] | [Available actions] | [Status indicator] |

[为每个关键实体创建状态映射]

### 7.2 界面状态 (UI States)

- **初始状态**: [Initial state description]
- **加载状态**: [Loading state description]
- **成功状态**: [Success state description]
- **错误状态**: [Error state description]
- **空状态**: [Empty state description]

---

## 8. 响应式设计 (Responsive Design)

### 8.1 断点定义 (Breakpoints)

- **Mobile**: < 768px
- **Tablet**: 768px - 1024px
- **Desktop**: > 1024px

### 8.2 适配策略 (Adaptation Strategy)

#### Mobile
- 单列布局
- 汉堡菜单
- 全屏模态框
- 触摸优化

#### Tablet
- 双列布局（部分场景）
- 侧边栏导航
- 弹出式模态框

#### Desktop
- 多列布局
- 顶部/侧边导航
- 悬浮提示
- 键盘快捷键

---

## 9. 无障碍设计 (Accessibility)

### 9.1 WCAG 合规性

- **感知性**: 文本替代、颜色对比、可调整文本大小
- **可操作性**: 键盘导航、充足的点击区域、可跳过内容
- **可理解性**: 清晰的标签、一致的导航、错误提示
- **健壮性**: 语义化HTML、ARIA标签

### 9.2 辅助技术支持

- 屏幕阅读器兼容
- 键盘完全可操作
- 高对比度模式
- 文本缩放支持

---

## 10. 交互约束 (Interaction Constraints)

### 10.1 性能约束
**来源**: PRD Non-Functional Requirements

- 页面加载时间: < [X] 秒
- 交互响应时间: < [Y] 毫秒
- 动画帧率: ≥ 60 FPS

### 10.2 业务约束
**来源**: Domain Model Business Rules

- [约束 1]: [描述]
- [约束 2]: [描述]

### 10.3 技术约束
**来源**: PRD Technical Constraints

- 支持的浏览器: [Browser list]
- 支持的设备: [Device list]
- 网络条件: [Network requirements]

---

## 11. 微交互设计 (Micro-interactions)

### 11.1 按钮交互
- **Hover**: [Hover effect]
- **Active**: [Active state]
- **Disabled**: [Disabled state]
- **Loading**: [Loading state]

### 11.2 过渡动画
- **页面切换**: [Transition type, duration]
- **模态框**: [Animation type, duration]
- **列表项**: [Animation type, duration]

### 11.3 手势支持 (Mobile)
- **滑动**: [Swipe actions]
- **长按**: [Long press actions]
- **捏合**: [Pinch actions]

---

## 12. 错误处理与边界情况 (Error Handling & Edge Cases)

### 12.1 网络错误
**场景**: 网络连接失败
**UI 表现**: [Error message and retry option]
**用户操作**: [Available actions]

### 12.2 数据错误
**场景**: 数据加载失败或数据不完整
**UI 表现**: [Error message]
**用户操作**: [Recovery actions]

### 12.3 权限错误
**场景**: 用户无权限访问
**UI 表现**: [Permission denied message]
**用户操作**: [Guidance to request access]

### 12.4 边界情况
- **空列表**: [Empty state design]
- **超长文本**: [Text truncation strategy]
- **大量数据**: [Pagination or virtualization]
- **并发操作**: [Conflict resolution]

---

## 附录 (Appendix)

### A. 交互词汇表 (Interaction Glossary)
[定义关键交互术语]

### B. 参考文档 (References)
- Domain Model: [path]
- PRD: [path]
- UI/UX Guidelines: [references]

### C. 设计资源 (Design Resources)
- Design System: [link]
- Component Library: [link]
- Icon Library: [link]

---

**文档生成**: Enterprise Architect AI
**基于**: Domain Model v[version] + PRD v[version]
**生成时间**: [timestamp]
```

---

## Generation Instructions

### Step 1: Load Input Documents

Read required documents:
```
{project-root}/_bmad/_memory/domain-consultant-sidecar/memories.md
{output_folder}/enterprise-architect/PRD.md
```

### Step 2: Extract Key Information

From Domain Model and PRD, extract:
- **Key Scenarios** → User Journey Maps (Section 2)
- **User Stories (from PRD)** → Interaction Flows (Section 3)
- **Domain Entities** → Interface Structure (Section 4)
- **State Transitions** → State Management (Section 7)
- **Business Rules** → Interaction Constraints (Section 10)
- **Functional Modules (from PRD)** → Key Screens (Section 5.2)

### Step 3: Identify User Roles

From Key Scenarios, identify distinct user roles:
1. Extract actor names from scenarios
2. Group similar actors
3. Define role characteristics (goals, pain points, tech proficiency)
4. Create role definitions (Section 1)

### Step 4: Create User Journey Maps

**CRITICAL**: Must generate Mermaid journey diagrams for visual representation.

For each user story in PRD:
1. Identify corresponding scenario from domain model
2. Break journey into stages (Discover, Explore, Use, Complete)
3. Define user actions at each stage
4. Identify touchpoints (UI elements user interacts with)
5. Map emotional state using emotion scores (1-5)
6. Identify pain points and opportunities

**Step 4.1: Generate Mermaid Journey Diagram**

Create a Mermaid journey diagram for each key user story:

```mermaid
journey
    title [User Story Title]
    section [Stage 1 Name]
      [Action 1]: [Emotion Score 1-5]: [Role Name]
      [Action 2]: [Emotion Score 1-5]: [Role Name]
    section [Stage 2 Name]
      [Action 3]: [Emotion Score 1-5]: [Role Name]
      [Action 4]: [Emotion Score 1-5]: [Role Name]
```

**Emotion Score Guidelines**:
- **5**: Delightful experience, user very satisfied (e.g., task completed successfully, clear feedback)
- **4**: Good experience, user satisfied (e.g., smooth interaction, minor friction)
- **3**: Neutral experience, acceptable (e.g., functional but not optimized, some confusion)
- **2**: Poor experience, user frustrated (e.g., unclear instructions, multiple steps)
- **1**: Very poor experience, user very frustrated (e.g., errors, dead ends, lost progress)

**Example**:
```mermaid
journey
    title 用户完成订单购买旅程
    section 发现商品
      浏览商品列表: 4: 用户
      查看商品详情: 5: 用户
    section 下单购买
      添加到购物车: 4: 用户
      填写收货信息: 3: 用户
      选择支付方式: 3: 用户
    section 完成支付
      确认订单信息: 4: 用户
      完成支付: 5: 用户
      收到确认通知: 5: 用户
```

**Step 4.2: Create Detailed Journey Table**

After the Mermaid diagram, provide detailed journey analysis:

**Template**:
```markdown
### 旅程: [User Story Title]
**对应用户故事**: US-XXX
**用户角色**: [Role from Section 1]
**目标**: [Goal from user story "以便" clause]

#### 旅程可视化
[Insert Mermaid journey diagram here]

#### 旅程详细分析
| 阶段 | 用户行为 | 触点 | 情绪 | 痛点 | 机会点 |
|------|---------|------|------|------|--------|
| 发现 | [How user discovers feature] | [UI element] | 😊 | [Pain point] | [Opportunity] |
| ... | ... | ... | ... | ... | ... |
```

### Step 5: Design Interaction Flows

For each user story:
1. Define trigger condition (what starts the flow)
2. List prerequisites (required state or data)
3. Map step-by-step interaction:
   - User action → System response → UI update → State change
4. Define success path (happy path)
5. Define exception paths (error handling)
6. Identify exit points

**Use State Transitions from Domain Model** to ensure flows align with entity lifecycle.

### Step 6: Define Interface Structure

1. **Information Architecture**:
   - Group functional modules from PRD
   - Create hierarchical navigation structure
   - Define primary and secondary navigation

2. **Navigation Patterns**:
   - Choose appropriate navigation type based on app complexity
   - Define navigation hierarchy

### Step 7: Design Key Screens

For each functional module in PRD:
1. Identify primary screen for the module
2. Define screen layout (header, content, footer)
3. List UI elements (based on entity attributes)
4. Define actions (based on business rules)
5. Map screen states (loading, empty, error, success)

**Reference Entity Attributes** from Domain Model to determine data fields.

### Step 8: Define Interaction Patterns

Categorize interactions by type:
1. **Data Input**: Forms, search, filters (based on entity attributes)
2. **Data Display**: Lists, details, cards (based on entity relationships)
3. **Feedback**: Success, error, loading (based on business rules)

### Step 9: Map Entity States to UI

For each entity with state transitions:
1. List all states from Domain Model
2. Define UI representation for each state
3. Define available actions in each state
4. Design status indicators (badges, colors, icons)

### Step 10: Define Responsive Strategy

Based on PRD technical constraints:
1. Define breakpoints
2. Specify layout adaptations for each breakpoint
3. Define mobile-specific interactions (gestures)

### Step 11: Address Accessibility

Based on PRD compliance requirements:
1. Define WCAG compliance level
2. Specify accessibility features
3. Document assistive technology support

### Step 12: Document Error Handling

From Business Rules and Constraints:
1. Identify potential error scenarios
2. Design error messages and recovery actions
3. Define edge case handling (empty states, long text, etc.)

### Step 13: Generate Complete Interaction.md

Assemble all sections into complete Interaction.md following the structure above.

### Step 14: Validate Output

Check that:
- [ ] All user stories from PRD are addressed
- [ ] All scenarios from domain model are covered
- [ ] All entity states are mapped to UI
- [ ] All business rules are reflected in interactions
- [ ] Interaction flows are complete and logical
- [ ] Document is consistent with PRD

---

## Quality Standards

### Completeness
- ✅ Every user story has corresponding journey map and interaction flow
- ✅ Every entity state has UI representation
- ✅ Every functional module has key screen definition
- ✅ All error scenarios are addressed

### Clarity
- ✅ Journey maps are visual and easy to understand
- ✅ Interaction flows are step-by-step and unambiguous
- ✅ Screen layouts are clearly described
- ✅ UI states are well-defined

### Consistency
- ✅ Terminology consistent with PRD and domain model
- ✅ Navigation patterns consistent across screens
- ✅ Interaction patterns consistent across similar functions
- ✅ State representations consistent across entities

### Usability
- ✅ User journeys are optimized for efficiency
- ✅ Error messages are helpful and actionable
- ✅ Feedback is timely and appropriate
- ✅ Accessibility requirements are met

---

## Example Usage

```yaml
# Called by Claude in Phase 3

skill: interaction-mapper
input:
  domain_model_path: "{project-root}/_bmad/_memory/domain-consultant-sidecar/memories.md"
  prd_path: "{output_folder}/enterprise-architect/PRD.md"
  output_path: "{output_folder}/enterprise-architect/Interaction.md"
  project_name: "Warehouse Management System"
```

---

## Error Handling

**If PRD incomplete:**
- Identify missing user stories
- Return error with specific gaps
- Suggest returning to Phase 3 (Documentation)

**If user roles unclear:**
- Flag ambiguous roles
- Request clarification
- Provide suggestions based on scenarios

**If interaction flows conflict:**
- Identify conflicting flows
- Highlight conflicts in output
- Recommend resolution

---

**Skill Created**: 2026-01-26
**Module**: enterprise-architect
**Type**: Document Generator
**Output**: Interaction.md
