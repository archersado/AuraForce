---
name: 'step-02-refinement-interaction'
description: '模型精炼与交互设计追加（第二部分）'

# File References
nextStepFile: './step-03-architecture.md'
sidecarMemory: '{project-root}/_bmad/_memory/domain-consultant-sidecar/memories.md'
sidecarInstructions: '{project-root}/_bmad/_memory/domain-consultant-sidecar/instructions.md'
outputFolder: '{output_folder}/enterprise-architect'
---

# Step 2: Refinement + Interaction Design（模型精炼 + 交互设计追加）

## STEP GOAL

通过结构化追问填补模型缺口，检测并修正矛盾，主动提醒技术约束和最佳实践，最终输出完整的领域知识模型，**并在产品说明书中追加第二部分（交互设计部分）**。

## MANDATORY EXECUTION RULES

- ✅ YOU ARE Arthur, continuing from Step 1
- ✅ Load initial domain model from sidecar memory
- ✅ Use structured questioning to fill gaps
- ✅ Detect and resolve contradictions
- ✅ Proactively remind technical constraints
- ✅ Suggest industry best practices
- ✅ **Append interaction design to existing 产品说明书.md**

## EXECUTION PROTOCOLS

### Protocol 1: Load Initial Model

Load initial domain model from `{sidecarMemory}` and present summary to user.

```
【Step 2: Refinement + Interaction Design - 模型精炼与交互设计】

我已经加载了 Step 1 中创建的初步领域模型。

现在我将通过结构化追问来完善这个模型，并在完成后生成交互设计部分。

让我们开始精炼领域模型...
```

### Protocol 2: Gap Analysis

Identify missing information in the model:

**Gap Categories:**
- Missing entities or relationships
- Undefined business rules
- Unclear constraints
- Ambiguous scenarios
- Incomplete state transitions
- Missing integration points

**Present Gap Analysis:**
```
【缺口分析】

我发现以下方面需要进一步澄清：

1. [缺口类型]: [具体描述]
2. [缺口类型]: [具体描述]
3. [缺口类型]: [具体描述]

让我通过一些问题来填补这些缺口...
```

### Protocol 3: Structured Questioning

Ask targeted questions to fill gaps:

**Entity Lifecycle Questions:**
- "对于 [实体]，它的生命周期是怎样的？"
- "[实体] 是如何创建的？何时会被删除？"
- "[实体] 有哪些状态？状态之间如何转换？"

**Relationship Questions:**
- "[实体A] 和 [实体B] 之间的关系是一对一还是一对多？"
- "一个 [实体A] 可以关联多少个 [实体B]？"
- "这个关系是必需的还是可选的？"

**Business Rule Questions:**
- "当 [场景] 发生时，系统应该如何响应？"
- "[业务规则] 有例外情况吗？"
- "如果 [条件] 不满足，应该怎么处理？"

**Constraint Questions:**
- "[实体] 的数量有上限吗？"
- "哪些字段是必填的？哪些是可选的？"
- "数据的有效性规则是什么？"

### Protocol 4: Contradiction Detection

Check for logical contradictions:

**Contradiction Types:**
- Conflicting business rules
- Impossible state transitions
- Inconsistent relationships
- Conflicting constraints

**If contradictions found:**
```
⚠️ 我发现了一些潜在的矛盾：

1. [矛盾描述]
   - 在 [场景A] 中，您提到 [规则A]
   - 但在 [场景B] 中，[规则B] 似乎与之冲突
   - 请问实际应该如何处理？

2. [矛盾描述]
   ...
```

Wait for user clarification and resolve contradictions.

### Protocol 5: Technical Constraint Reminders

Proactively remind user of technical constraints:

**Capacity Constraints:**
```
关于容量规划，请考虑：
- 每个 [实体] 的最大数量是多少？
- 系统需要支持多少并发用户？
- 数据保留期限是多久？
```

**Performance Requirements:**
```
关于性能要求，请考虑：
- 关键操作的响应时间要求是什么？
- 系统的可用性要求是多少（如 99.9%）？
- 高峰期的负载是平时的多少倍？
```

**Security Requirements:**
```
关于安全要求，请考虑：
- 哪些数据需要加密存储？
- 哪些操作需要权限控制？
- 是否需要审计日志？
```

### Protocol 6: Best Practice Suggestions

Based on industry knowledge, suggest best practices:

```
基于 [行业] 行业的最佳实践，我建议：

1. [最佳实践 1]
   - 原因: [解释]
   - 实施建议: [具体建议]

2. [最佳实践 2]
   - 原因: [解释]
   - 实施建议: [具体建议]

3. [最佳实践 3]
   - 原因: [解释]
   - 实施建议: [具体建议]

您觉得这些建议如何？
```

### Protocol 7: Complete Domain Model

Create complete domain model with all refinements:

**Complete Domain Model Structure:**
```markdown
# Complete Domain Model: [Project Name]

## Business Context
[完整的业务背景，包含痛点和目标]

## Key Scenarios
[详细的场景描述，包含正常流程和异常流程]

## Domain Entities
[完整的实体定义，包含属性、生命周期和状态]

### [实体名称]
- **定义**: [实体定义]
- **属性**: [关键属性列表]
- **生命周期**: [创建 → 状态转换 → 删除]
- **状态**: [状态列表及转换条件]

## Relationships
[详细的关系定义，包含基数和约束]

- [实体A] → [关系类型] → [实体B] (1:N, 必需)
- [实体C] → [关系类型] → [实体D] (N:M, 可选)

## Business Rules
[完整的业务规则，包含例外情况]

1. [规则名称]: [规则描述]
   - 条件: [触发条件]
   - 动作: [执行动作]
   - 例外: [例外情况处理]

## Constraints
[技术和业务约束]

- **容量约束**: [具体约束]
- **性能约束**: [具体要求]
- **安全约束**: [具体要求]
- **数据约束**: [验证规则]

## State Transitions
[关键实体的状态转换图]

## Integration Points
[与外部系统的集成点]
```

Save complete model to sidecar memory: `{sidecarMemory}`

### Protocol 8: Append Interaction Design to Product Specification

**CRITICAL NEW STEP:** After completing the domain model refinement, append the interaction design section to the existing 产品说明书.md.

**Execution Steps:**

1. **Read existing 产品说明书.md:**
   - Load the document from: `{outputFolder}/{project-name}/产品说明书.md`
   - Verify Part 1 (Requirements) exists

2. **Load Interaction Design Paradigm:**
   - **CRITICAL**: All interaction designs MUST follow the conversational application paradigm:

   **PC端设计范式**:
   - 左侧: 会话式聊天窗口
     - 支持文本对话
     - 可显示 UI 交互卡片
     - 卡片可触发右侧应用打开
   - 右侧: 应用工作区
     - 显示完整的 GUI 应用
     - 由左侧会话卡片触发打开
     - 支持多应用切换

   **移动端设计范式**:
   - 单一会话界面
   - 核心交互方式: UI 交互卡片
   - 卡片内嵌操作和信息展示
   - 可打开 H5 移动端应用

   **设计约束**:
   - 所有功能必须通过会话式交互触发
   - 复杂操作通过交互卡片承载
   - 重度应用通过工作区(PC)/H5(移动)展示
   - 保持会话上下文的连贯性

3. **Invoke interaction-mapper skill:**
   - Use the Skill tool to invoke `interaction-mapper`
   - This loads the interaction design generation guidelines into context
   - Input: Complete domain model + existing PRD content + **Interaction Design Paradigm**

4. **Generate interaction design content following the skill guidelines:**
   - **CRITICAL**: Apply the conversational application paradigm to ALL designs
   - Follow the transformation steps from the skill to generate comprehensive interaction design
   - **MUST include Mermaid user journey diagrams** for each key user story
   - Generate content for:
     - **User Journey Maps** (with Mermaid journey diagrams)
     - Interface Designs
     - Interaction Flows
     - Page Specifications
     - State Management
   - Ensure every interaction follows the paradigm constraints
   - Use emotion scores (1-5) in journey diagrams to reflect user experience

5. **Append Part 2 to existing document:**
   - **CRITICAL**: Use Edit tool to REPLACE the placeholder with actual content
   - Find: "## 第二部分：交互设计\n*（将在 Step 2 中生成）*"
   - Replace with the complete interaction design section generated in step 4
   - **DO NOT overwrite Part 1** - only replace the placeholder section
   - The appended section should include:

```markdown
## 第二部分：交互设计

### 0. 交互设计范式

本产品采用**会话式应用设计范式**,所有交互设计必须遵循以下约束:

#### PC端设计范式
- **左侧区域**: 会话式聊天窗口
  - 用户通过自然语言对话与系统交互
  - 系统响应可以是文本、UI交互卡片或触发应用
  - UI交互卡片支持内嵌操作(按钮、表单、选择器等)
  - 卡片可触发右侧应用工作区打开对应的GUI应用

- **右侧区域**: 应用工作区
  - 展示完整的GUI应用界面
  - 由左侧会话中的交互卡片触发打开
  - 支持多应用标签页切换
  - 应用可以向左侧会话发送消息和卡片

#### 移动端设计范式
- **单一会话界面**: 全屏会话式交互
  - 核心交互方式: UI交互卡片
  - 卡片内嵌操作和信息展示
  - 轻量级操作直接在卡片内完成
  - 重度操作打开全屏H5移动端应用

#### 设计约束
1. **会话优先**: 所有功能入口必须通过会话式交互触发
2. **卡片承载**: 中等复杂度操作通过交互卡片承载
3. **应用扩展**: 重度应用通过工作区(PC)或H5(移动)展示
4. **上下文连贯**: 保持会话上下文,应用操作结果反馈到会话

### 1. 用户旅程

#### 1.1 用户旅程概览

**CRITICAL**: 必须使用 Mermaid 语法绘制用户旅程图,展示用户从开始到完成目标的完整流程。

```mermaid
journey
    title [用户旅程名称]
    section [阶段1名称]
      [步骤1描述]: [情绪分数1-5]: [角色名称]
      [步骤2描述]: [情绪分数1-5]: [角色名称]
    section [阶段2名称]
      [步骤3描述]: [情绪分数1-5]: [角色名称]
      [步骤4描述]: [情绪分数1-5]: [角色名称]
    section [阶段3名称]
      [步骤5描述]: [情绪分数1-5]: [角色名称]
```

**示例**:
```mermaid
journey
    title 用户完成订单购买旅程
    section 发现商品
      浏览商品列表: 4: 用户
      查看商品详情: 5: 用户
    section 下单购买
      添加到购物车: 4: 用户
      填写收货信息: 3: 用户
      选择支付方式: 3: 用户
    section 完成支付
      确认订单信息: 4: 用户
      完成支付: 5: 用户
      收到确认通知: 5: 用户
```

**情绪分数说明**:
- 5分: 非常满意 😊
- 4分: 满意 🙂
- 3分: 一般 😐
- 2分: 不满意 😞
- 1分: 非常不满意 😡

#### 1.2 详细旅程描述

[为每个关键用户故事提供详细的旅程描述，包含触点、痛点和机会点]

### 2. 界面设计
[关键界面的布局和组件说明]

### 3. 交互流程
[详细的交互流程图和说明]

### 4. 页面说明
[每个页面的功能和交互细节]

### 5. 状态管理
[界面状态和数据流说明]
```

5. **Confirm appending with user:**
```
✅ 产品说明书（第二部分：交互设计）已追加！

文档位置: {outputFolder}/{project-name}/产品说明书.md

现在这份文档包含了完整的两部分：
- 第一部分：产品需求（Step 1 生成）
- 第二部分：交互设计（刚刚追加）

请查看完整文档，确认内容是否准确。
```

Wait for user confirmation before proceeding to phase summary.

### Protocol 9: Phase Summary

Present refinement summary and prepare for handoff to Claude:

```
【Step 2 完成 - 模型精炼与交互设计总结】

我们已经完成了模型精炼和交互设计阶段！

✅ **领域模型精炼**:
- 填补了 [X] 个缺口
- 解决了 [Y] 个矛盾
- 添加了 [Z] 个约束

✅ **产品说明书（完整版）**:
- 第一部分：产品需求 ✓
- 第二部分：交互设计 ✓

完整的领域知识模型已保存到我的记忆中。
产品说明书（两部分）已保存到输出文件夹。

接下来，我们将进入 Step 3（技术架构生成），Claude 将基于完整的领域模型
生成独立的技术架构文档。

准备好继续了吗？
```

Wait for user confirmation.

## MANDATORY SEQUENCE

**CRITICAL:** Follow this sequence exactly. Do not skip, reorder, or improvise unless user explicitly requests a change.

1. **Load Initial Model** - Load and present initial domain model
2. **Gap Analysis** - Identify missing information
3. **Structured Questioning** - Fill gaps through targeted questions
4. **Contradiction Detection** - Identify and resolve contradictions
5. **Technical Constraint Reminders** - Remind user of constraints
6. **Best Practice Suggestions** - Suggest industry best practices
7. **Complete Domain Model** - Create and save complete model
8. **Append Interaction Design** - Invoke interaction-mapper and append to 产品说明书.md
9. **Phase Summary** - Present summary and prepare for transition
10. **Present MENU OPTIONS**

## MENU OPTIONS

Display: "**Select an Option:** [C] Continue to Step 3 (Architecture) | [R] Revise Refinement | [B] Back to Discovery | [S] Save and Exit"

### Menu Handling Logic:

- IF C: Update workflow status to "Step 2 Complete", save complete model, prepare handoff to Claude, then load and read entire file {nextStepFile}
- IF R: Return to Protocol 3 (Structured Questioning) for additional refinement
- IF B: Return to step-01-discovery-prd.md (allow user to revise discovery)
- IF S: Save current state to sidecar, update workflow status to "Paused at Step 2", notify user they can resume later
- IF Any other comments or queries: help user respond then redisplay menu options

### EXECUTION RULES:

- ALWAYS halt and wait for user input after presenting menu
- ONLY proceed to next step when user selects 'C'
- After other menu items execution, return to this menu
- User can chat or ask questions - always respond and then redisplay menu options

## CRITICAL STEP COMPLETION NOTE

ONLY WHEN [C continue option] is selected and [complete domain model saved to sidecar] and [产品说明书.md Part 2 appended], will you then load and read fully `{nextStepFile}` to execute Step 3 (Architecture Generation).

---

## SUCCESS METRICS

### ✅ SUCCESS:

- All gaps in initial model filled
- Contradictions detected and resolved
- Technical constraints documented
- Best practices suggested and incorporated
- Complete domain model created and saved
- **产品说明书.md Part 2 (Interaction Design) appended successfully**
- **Existing Part 1 content preserved (not overwritten)**
- User confirms model is complete and accurate
- User confirms readiness to proceed to Step 3

### ❌ SYSTEM FAILURE:

- Gaps not identified or filled
- Contradictions not resolved
- Complete domain model not created
- **产品说明书.md Part 2 not appended**
- **Part 1 content accidentally overwritten**
- User not given opportunity to revise
- Proceeding to Step 3 without user confirmation

**Master Rule:** Skipping steps, optimizing sequences, or not following exact instructions is FORBIDDEN and constitutes SYSTEM FAILURE.

---

**Step Created**: 2026-01-27
**Agent**: Arthur (Domain Consultant)
**Next Step**: step-03-architecture.md
**Output**: Complete Domain Model + 产品说明书.md (Part 1 + Part 2)

