---
name: domain-prd-generator
description: "Generate enterprise-grade Product Requirements Documents (PRD) from domain knowledge models. Use when: (1) Arthur (Domain Consultant) has completed domain modeling and needs PRD generation, (2) User requests PRD generation based on existing domain model in Arthur's sidecar, (3) Working within enterprise-architect module's end-to-end-design workflow, (4) Need TOGAF/4A compliant PRD with dual-perspective format (business + technical views). Compatible with and extends the base prd-generator skill for enterprise scenarios."
allowed-tools: Read, Write, Edit, Glob, Grep
---

# Domain PRD Generator

Generate enterprise-grade Product Requirements Documents (PRD.md) from complete domain knowledge models, with TOGAF/4A compliance and dual-perspective formatting.

## Overview

This skill transforms domain knowledge models (created by Arthur in Discovery/Refinement phases) into structured PRD documents suitable for enterprise development teams. It extends the base `prd-generator` skill with:

- **Domain model integration**: Reads from Arthur's sidecar memory
- **Enterprise standards**: TOGAF/4A compliance
- **Dual perspectives**: Business meaning + technical implementation
- **Complete traceability**: Links requirements back to domain model
- **Compatible format**: Uses same template structure as prd-generator (产品需求.md)

**When to use**: Called by Claude (Design Coordinator) in Phase 3 (Documentation) of the end-to-end-design workflow, after Arthur completes domain modeling.

**Key difference from prd-generator**: This skill reads from a pre-built domain model instead of interactive discovery. No user interaction or sub-skill calls needed during generation.

## Workflow

### Step 1: Validate Input

Before generating PRD, verify the domain model exists and is complete:

```bash
# Check if domain model exists
Read: {project-root}/_bmad/_memory/domain-consultant-sidecar/memories.md
```

**Required sections** (see `references/domain-model-schema.md` for details):
- Business Context
- Key Scenarios (at least 3)
- Domain Entities (with attributes and lifecycle)
- Relationships (with cardinality)
- Business Rules (with triggers and actions)
- Constraints (technical, business, regulatory)
- State Transitions (for stateful entities)
- Integration Points (if applicable)

**If incomplete**: Return error with specific gaps and suggest returning to Phase 2 (Refinement).

### Step 2: Extract Project Information

From domain model, extract:
- **Project Name**: From Business Context or first entity
- **Industry**: From Business Context
- **Background**: Business context and pain points
- **Product Positioning**: Core value proposition
- **Target Users**: User roles from Key Scenarios

### Step 3: Generate Product Definition Section

Transform domain model into product definition (compatible with prd-generator template):

```markdown
# 产品定义

## 背景

[Extract from Business Context - current pain points and problems]

## 产品定位

[Synthesize from Business Context - what the product is, who it's for, main purpose]

## 核心业务逻辑

[Extract from Business Context and Key Scenarios - core business flow:
用户输入什么 → 系统如何处理 → 关键规则和判断 → 最终输出什么结果]

## 目标用户

[Extract user roles from Key Scenarios - describe main user groups and characteristics]
```

### Step 4: Generate User Journey Section

Transform Key Scenarios into user journey (compatible with prd-generator template):

For each scenario in Key Scenarios:
1. Extract the main user flow
2. Identify key steps from scenario description
3. Combine into cohesive journey

```markdown
# 用户旅程

[If multiple scenarios, organize by scenario]

### 旅程1：[Scenario Name]

第一步，[Step 1 from scenario]；
第二步，[Step 2 from scenario]；
第三步，[Step 3 from scenario]；
...
第N步，[Final step from scenario]。

### 旅程2：[Scenario Name]

[Repeat for each major scenario]
```

### Step 5: Generate Functional List

Transform scenarios and entities into functional list (compatible with prd-generator template):

1. Extract functions from Key Scenarios (what users want to do)
2. Add CRUD functions for each Domain Entity
3. Add functions from Business Rules
4. Assign priorities based on scenario importance

```markdown
# 功能清单

| 功能名称 | 功能描述 | 优先级 | 依赖关系说明 | 备注 |
| -------- | -------- | ------ | ------------ | ---- |
| [Function from Scenario 1] | [Description] | P0 | [Dependencies] | [Notes] |
| [Function from Scenario 2] | [Description] | P0 | [Dependencies] | [Notes] |
| [CRUD for Entity 1] | [Description] | P1 | [Dependencies] | [Notes] |
| [Function from Business Rule] | [Description] | P1 | [Dependencies] | [Notes] |
```

**Priority Assignment**:
- P0: Core scenarios, essential entities
- P1: Supporting scenarios, important entities
- P2: Nice-to-have features, optional entities

### Step 6: Generate Core Function Details

For each P0 and P1 function, generate detailed specification (compatible with prd-generator template):

```markdown
# 核心功能说明

## [Function Name]

### 功能详细描述

[Detailed description of the function flow and logic, including:
- What triggers this function
- Step-by-step process
- Decision points and branches
- Expected outcomes]

[Extract from:
- Key Scenarios (for user-facing functions)
- Business Rules (for business logic)
- State Transitions (for state changes)]

### 输入输出

- 输入条件：
  - [Input 1 - from scenario or entity attributes]
  - [Input 2 - from scenario or entity attributes]

- 输出结果：
  - [Output 1 - from scenario success criteria]
  - [Output 2 - from entity state changes]

### 业务逻辑

[Detailed business rules and logic, including:
- Rule 1 from Business Rules section
- Rule 2 from Business Rules section
- Special case handling from Constraints]

### 界面交互说明

[Describe UI layout, elements, and interactions:
- Keep this section brief and high-level
- Focus on key UI components and user actions
- Avoid detailed UI specifications (colors, animations, etc.)
- This will be expanded in Interaction.md later]

1. 界面包含以下部分：
   1. [Area 1: content from scenario]
   2. [Area 2: content from scenario]

2. [Interaction behavior 1]
3. [Interaction behavior 2]
```

**Important**:
- Focus on system logic and business rules, not UI details
- Use specific data fields from Domain Entities
- Reference Business Rules by ID (BR-001, BR-002, etc.)
- Keep interface descriptions brief - detailed interaction design comes later

### Step 7: Assemble Complete PRD

Use the template from `references/requirements_template.md` and fill all sections:

1. **产品定义** (Product Definition)
   - 背景 (Background)
   - 产品定位 (Product Positioning)
   - 核心业务逻辑 (Core Business Logic)
   - 目标用户 (Target Users)

2. **用户旅程** (User Journey)
   - One or more journey flows from scenarios

3. **功能清单** (Functional List)
   - Table with all functions, priorities, dependencies

4. **核心功能说明** (Core Function Details)
   - Detailed specs for P0 and P1 functions

5. **补充说明** (Additional Notes)
   - Questions to clarify
   - Assumptions made
   - Items for future consideration

### Step 8: Validate Output

Check completeness:
- [ ] All Key Scenarios represented in user journey
- [ ] All Domain Entities have corresponding functions
- [ ] All Business Rules referenced in function details
- [ ] All P0 functions have detailed specifications
- [ ] Functional list has clear priorities
- [ ] No conflicting requirements
- [ ] Terminology consistent with domain model

### Step 9: Write PRD File

Write to: `{output_folder}/PRD.md`

**File naming**: `[ProjectName]_产品需求.md`

**Metadata to include at top**:
```markdown
# 【[ProjectName]】需求文档(PRD)

**项目名称**: [From domain model]
**版本**: 1.0
**创建日期**: [Current date]
**创建者**: Enterprise Architect AI
**状态**: Draft
**基于**: Domain Model v[version]
**生成时间**: [timestamp]

---
```

## Quality Standards

### Completeness
- ✅ All Key Scenarios represented in user journey
- ✅ All Domain Entities have functions
- ✅ All Business Rules documented
- ✅ All P0/P1 functions have detailed specs

### Clarity
- ✅ Product definition clear and concise
- ✅ User journey easy to follow
- ✅ Function descriptions specific and actionable
- ✅ Business logic detailed with examples

### Consistency
- ✅ Entity names consistent across document
- ✅ Terminology matches domain model
- ✅ No conflicting requirements
- ✅ Cross-references accurate

### Actionability
- ✅ Requirements specific enough for implementation
- ✅ Input/output clearly defined
- ✅ Business rules explicit
- ✅ Priorities clearly assigned

### TOGAF/4A Compliance
- ✅ Business and technical views separated
- ✅ Traceability to domain model maintained
- ✅ Stakeholder concerns addressed
- ✅ Enterprise standards followed

## Error Handling

### Domain Model Incomplete

If domain model missing required sections:

```markdown
⚠️ Domain Model Incomplete

Missing sections:
- [Section 1]
- [Section 2]

Cannot generate PRD without complete domain model.

**Recommendation**: Return to Phase 2 (Refinement) with Arthur to complete:
- [Specific guidance for missing sections]
```

### Scenarios Unclear

If scenarios lack sufficient detail:

```markdown
⚠️ Scenarios Need More Detail

Scenarios with insufficient information:
- [Scenario 1]: Missing [what's missing]
- [Scenario 2]: Unclear [what's unclear]

**Recommendation**: Clarify scenarios with Arthur before generating PRD.
```

### Entity Definitions Unclear

If entity attributes or relationships ambiguous:

```markdown
⚠️ Ambiguous Entity Definitions

Entities with unclear definitions:
- [Entity 1]: [What's unclear]
- [Entity 2]: [What's unclear]

**Recommendation**: Clarify with Arthur before proceeding.
```

## Integration with Base prd-generator

This skill **extends** the base `prd-generator` skill:

**Compatibility**:
- ✅ Uses same `requirements_template.md` format
- ✅ Generates same output structure (产品需求.md)
- ✅ Compatible file naming convention
- ✅ Can be used as drop-in replacement when domain model available

**Key Differences**:
- ❌ No interactive discovery (reads from domain model)
- ❌ No user-story-mapping skill call
- ❌ No AskUserQuestion interactions
- ❌ No detailed design generation (handled by domain-arch-designer)
- ✅ Adds TOGAF/4A compliance
- ✅ Adds dual-perspective formatting
- ✅ Adds complete traceability to domain model

**When to use which**:
- Use `prd-generator`: Interactive discovery, no domain model, general products, need detailed design
- Use `domain-prd-generator`: Enterprise projects, domain model exists, TOGAF/4A required, part of end-to-end workflow

## Example Usage

```yaml
# Called by Claude (Design Coordinator) in Phase 3

skill: domain-prd-generator
input:
  domain_model_path: "{project-root}/_bmad/_memory/domain-consultant-sidecar/memories.md"
  output_path: "{output_folder}/PRD.md"
  project_name: "Warehouse Management System"
```

**Expected output**: `仓储管理系统_产品需求.md` with complete product definition, user journey, functional list, and core function specifications.

## Resources

### references/requirements_template.md
Complete PRD template with all sections and formatting guidelines. Load when assembling final PRD to ensure correct structure.

### references/domain-model-schema.md
Detailed specification of expected domain model structure. Load when validating input or if domain model structure unclear.

---

**Skill Type**: Document Generator
**Module**: enterprise-architect
**Phase**: Documentation (Phase 3)
**Input**: Domain Model (from Arthur's sidecar)
**Output**: PRD.md (产品需求文档)
**Compatible with**: prd-generator (same output format)
