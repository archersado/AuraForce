---
stepsCompleted: []
inputDocuments: []
date: { system-date }
author: { user }
---

# Product Brief: {{project_name}}

<!-- Content will be appended sequentially through collaborative workflow steps -->
