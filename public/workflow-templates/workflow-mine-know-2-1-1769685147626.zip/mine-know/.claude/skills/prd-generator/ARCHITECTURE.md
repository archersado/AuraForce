# PRD Generator v3.0 - Architecture Design Document

**Version:** 3.0 (Streamlined 2-Stage)
**Date:** 2026-01-21
**Status:** Production

---

## Design Philosophy

PRD Generator is an **orchestrator skill** that coordinates specialized sub-skills to incrementally build comprehensive Product Requirements Documents. Each sub-skill is an expert in its domain, and prd-generator manages the workflow and document integration.

## Architecture Overview

```
prd-generator (Orchestrator)
    │
    ├─ Stage 1: user-story-mapping
    │   └─ Output: User Journey & Features → Update PRD
    │
    └─ Stage 2: architecture-designer (NEW in v3.0)
        └─ Output: Complete Architecture → Update PRD
            ├─ Business Objects (data model)
            ├─ Business Logic (operations)
            └─ Interaction Design (UI & events)
```

## Evolution History

### v1.0 (2025-12-26)
- **Approach:** Monolithic single skill
- **Problem:** Too complex, hard to maintain

### v2.0 (2026-01-21)
- **Approach:** 5-stage orchestrator
  ```
  Stage 1: user-story-mapping
  Stage 2: business-object-designer
  Stage 3: business-logic-designer
  Stage 4: interaction-designer
  Stage 5: implementation-planner
  ```
- **Problem:** Too fragmented, context switching, inconsistencies

### v3.0 (2026-01-21) - Current
- **Approach:** 2-stage orchestrator
  ```
  Stage 1: user-story-mapping
  Stage 2: architecture-designer (merged 2/3/4, removed 5)
  ```
- **Benefits:**
  - ✅ Faster: 2 stages instead of 5
  - ✅ Holistic: Architecture designed as integrated system
  - ✅ Consistent: All layers designed together
  - ✅ Focused: Removed premature implementation details

---

## Core Design Principles

### 1. Incremental Documentation

- Each stage updates PRD immediately upon completion
- Not a single big-bang generation at the end
- Users can see progress in real-time
- Document grows organically through stages

### 2. Sub-Skill Independence

Each sub-skill:
- Has independent SKILL.md documentation
- Has standardized output templates
- Can be invoked standalone for testing
- Outputs structured data (YAML/Markdown)

### 3. Orchestrator Responsibilities

prd-generator manages:
- Workflow control (Stage 1 → Stage 2)
- Sub-skill invocation (using Skill tool)
- PRD document lifecycle (create → update → finalize)
- Data extraction and transformation (sub-skill output → PRD format)
- Progress communication to user

### 4. Consistency Validation

After Stage 2, validate:
- Every P0 feature has logic and UI
- Every business object has CRUD operations
- Every user action has event handler
- Data flows correctly: Objects → Logic → Cards → Events

---

## Detailed Stage Design

### Stage 1: User Journey & Features

**Sub-Skill:** `user-story-mapping` (unchanged from v2.0)

**Purpose:** Understand product vision, users, and core features

**Process:**
1. Analyze product concept
2. Ask 2-3 clarifying questions:
   - User roles and personas
   - Core business logic and rules
   - Usage scenarios
   - Key value proposition
3. Generate user story map with:
   - Backbone (key activities)
   - Walking skeleton (MVP path)
   - Feature releases (prioritized)

**Output Format:**
```yaml
deliverables:
  user_personas:
    - role: "读者"
      goals: [...]
      pain_points: [...]

  journey_map:
    - stage: "发现需求"
      actions: [...]
      pain_points: [...]

  feature_list:
    - id: F-001
      name: "用户注册登录"
      priority: P0
      description: "..."

  core_business_logic:
    rules: [...]
    workflow: [...]

  release_plan:
    - name: "Release 1 (MVP)"
      objectives: [...]
      features: [...]
```

**PRD Updates:**
- User Journey section (personas + journey map)
- Product Feature List section (feature table + dependencies)

---

### Stage 2: Architecture Design

**Sub-Skill:** `architecture-designer` (NEW in v3.0)

**Purpose:** Design complete Single Agent Architecture (data + logic + UI)

**Replaces (from v2.0):**
- business-object-designer (old Stage 2)
- business-logic-designer (old Stage 3)
- interaction-designer (old Stage 4)

**Inputs (from Stage 1):**
- Feature list (all P0/P1/P2)
- Core business logic summary
- User personas and journey
- Business rules and constraints

**Process:**
1. Analyze inputs holistically across three layers
2. Ask 2-3 integrated clarifying questions:
   - Data model and relationships
   - Critical business rules
   - Interaction patterns
3. Design three layers simultaneously:
   - **Layer 1:** Business Objects (entities, attributes, validation, relationships)
   - **Layer 2:** Business Logic (operations, workflows, rules, errors)
   - **Layer 3:** Interaction Design (cards, events, UI/UX)
4. Validate cross-layer consistency
5. Generate complete architecture specification

**Output Format:**
```yaml
deliverables:
  business_objects:
    - name: "User"
      description: "..."
      attributes: [...]
      validation_rules: [...]
      relationships: [...]

  business_logic:
    - name: "ReserveBook"
      description: "..."
      input_params: [...]
      output_params: [...]
      logic_steps: [...]
      business_rules: [...]
      error_handling: [...]

  interaction_cards:
    - name: "BookListCard"
      description: "..."
      input_params: [...]
      events_emitted: [...]
      ui_requirements: [...]

  event_configuration:
    - name: "OnReserveBook"
      description: "..."
      trigger_conditions: [...]
      logic_invoked: "ReserveBook"
      cards_displayed: [...]
```

**PRD Updates:**
- Agent Overview
- Business Objects section
- Business Logic section
- Interaction Cards section
- Event Configuration section

**Key Innovation:** Designs all three layers together to ensure:
- Objects match logic needs
- Logic matches feature requirements
- UI cards display object data
- Events correctly wire UI to logic
- Naming consistency across layers

---

## Implementation Roadmap Handling

### Decision

Implementation Roadmap section is populated from **Stage 1's release plan**, not a separate Stage 5.

### Rationale

- Stage 1 (user-story-mapping) already defines:
  - Walking Skeleton (MVP core)
  - Release 1 (MVP features)
  - Release 2/3 (future enhancements)
  - Feature priorities and dependencies

- This provides sufficient **high-level roadmap** for PRD stakeholders

- Detailed implementation planning (sprint breakdown, tasks, estimates) happens **after PRD approval** in collaboration with engineering team

### Update Strategy

After Stage 1:
1. Extract release plan from user-story-mapping output
2. Populate "Implementation Roadmap" section
3. Keep it high-level: Release → Objectives → Key Features → Success Criteria
4. Add note: "Detailed sprint planning to follow PRD approval"

---

## PRD Document Management

### Initialization

1. User triggers `/create-prd` or provides product name
2. prd-generator creates initial PRD: `PRD_[ProductName]_v1.0.md`
3. Document includes complete template structure with placeholders

### Incremental Update Flow

**After Stage 1:**
```
1. Invoke user-story-mapping skill
2. Capture output data
3. Read current PRD document
4. Locate "User Journey" section
5. Replace placeholder with personas and journey map
6. Locate "Product Feature List" section
7. Replace placeholder with feature table
8. Write updated PRD document
9. Show user what was updated
```

**After Stage 2:**
```
1. Invoke architecture-designer skill
2. Capture complete architecture output
3. Read current PRD document
4. Locate "Single Agent Architecture" section
5. Replace "Agent Overview"
6. Replace "Business Objects" subsection
7. Replace "Business Logic" subsection
8. Replace "Interaction Cards" subsection
9. Replace "Event Configuration" subsection
10. Write updated PRD document
11. Show user comprehensive summary
```

### Document Update Strategy

Use **Edit** tool for precise section replacement:
- Locate section by heading markers
- Replace placeholder content with actual data
- Preserve other sections unchanged
- Maintain consistent formatting

---

## Data Flow Diagram

```
┌──────────────────┐
│      User        │
│   "我要创建PRD"   │
└────────┬─────────┘
         │
         ▼
┌────────────────────────────────────────────┐
│        prd-generator (Orchestrator)         │
│                                            │
│  1. Create PRD_[Product]_v1.0.md          │
│  2. Invoke Stage 1                         │
└────────┬───────────────────────────────────┘
         │
         ▼
┌────────────────────────────────────────────┐
│   Stage 1: user-story-mapping              │
│                                            │
│  - Ask 2-3 questions                       │
│  - Generate user personas                  │
│  - Generate journey map                    │
│  - Generate feature list                   │
│  - Generate release plan                   │
└────────┬───────────────────────────────────┘
         │
         │ Output: personas, journey, features, release plan
         │
         ▼
┌────────────────────────────────────────────┐
│     prd-generator (Update PRD)             │
│                                            │
│  - Update User Journey section             │
│  - Update Feature List section             │
│  - Update Implementation Roadmap section   │
│  - Announce: "Stage 1 Complete"           │
│  - Invoke Stage 2                          │
└────────┬───────────────────────────────────┘
         │
         ▼
┌────────────────────────────────────────────┐
│   Stage 2: architecture-designer           │
│                                            │
│  - Receive Stage 1 outputs as input        │
│  - Ask 2-3 integrated questions            │
│  - Design Layer 1: Business Objects        │
│  - Design Layer 2: Business Logic          │
│  - Design Layer 3: Interaction Design      │
│  - Validate consistency                    │
└────────┬───────────────────────────────────┘
         │
         │ Output: objects, logic, cards, events
         │
         ▼
┌────────────────────────────────────────────┐
│     prd-generator (Update PRD)             │
│                                            │
│  - Update Agent Overview                   │
│  - Update Business Objects section         │
│  - Update Business Logic section           │
│  - Update Interaction Cards section        │
│  - Update Event Configuration section      │
│  - Announce: "PRD Generation Complete!"   │
└────────┬───────────────────────────────────┘
         │
         ▼
┌──────────────────────────────────────────┐
│    PRD_[Product]_v1.0.md (Complete)       │
│                                          │
│  ✅ User Journey                          │
│  ✅ Feature List                          │
│  ✅ Business Objects                      │
│  ✅ Business Logic                        │
│  ✅ Interaction Design                    │
│  ✅ Implementation Roadmap                │
└──────────────────────────────────────────┘
```

---

## Sub-Skill Template Structure

Each sub-skill has a `references/output-template.md` that defines:

```markdown
# [Skill Name] Output Template

## Deliverable 1: [Name]

### [Item 1]
- Field 1: [value]
- Field 2: [value]

### [Item 2]
...

## Summary

[Count and list of delivered items]
```

---

## File Organization

```
.claude/skills/prd-generator/
├── SKILL.md                    # Main orchestrator (v3.0)
├── ARCHITECTURE.md             # This document
├── references/
│   └── prd_template.md         # Complete PRD template
└── ...

.claude/skills/
├── user-story-mapping/         # Stage 1 (unchanged)
│   ├── SKILL.md
│   └── references/
│       ├── guided-approach.md
│       ├── mapping-techniques.md
│       └── release-planning.md
│
└── architecture-designer/      # Stage 2 (NEW in v3.0)
    ├── SKILL.md
    └── references/
        ├── output-template.md
        └── design-examples.md
```

### Deprecated (from v2.0)

```
.claude/skills/
├── business-object-designer/   # ❌ Deprecated (merged into architecture-designer)
├── business-logic-designer/    # ❌ Deprecated (merged into architecture-designer)
├── interaction-designer/       # ❌ Deprecated (merged into architecture-designer)
└── implementation-planner/     # ❌ Removed (use Stage 1 release plan)
```

---

## Comparison: v2.0 vs v3.0

| Aspect | v2.0 (5 Stages) | v3.0 (2 Stages) |
|--------|-----------------|-----------------|
| **Stages** | 5 | 2 |
| **Sub-skills** | 5 separate skills | 2 skills (1 merged) |
| **Clarification rounds** | 5 separate Q&A | 2 consolidated Q&A |
| **Generation time** | Longer | ~60% faster |
| **Consistency** | Risk of misalignment | Guaranteed consistency |
| **Context switching** | High | Minimal |
| **Implementation detail** | Premature (Stage 5) | High-level (from Stage 1) |
| **User experience** | Can feel tedious | Streamlined |
| **Architecture quality** | Good but fragmented | Excellent and integrated |

---

## Best Practices

### For prd-generator (Orchestrator)

✅ **DO:**
- Always invoke sub-skills in order (Stage 1 → Stage 2)
- Pass complete, structured inputs to each sub-skill
- Capture ALL outputs from sub-skills
- Update PRD immediately after each stage
- Show clear progress indicators
- Trust sub-skill outputs (don't second-guess)

❌ **DON'T:**
- Skip stages without user consent
- Modify sub-skill outputs arbitrarily
- Batch all updates at the end
- Interfere with sub-skill workflows

### For Sub-Skills

✅ **DO:**
- Ask focused, high-value clarifying questions (2-3 max)
- Make reasonable assumptions when appropriate
- Output structured, parseable data
- Document design decisions
- Validate internal consistency

❌ **DON'T:**
- Over-interview (too many questions)
- Make wild assumptions without basis
- Output free-form unstructured text
- Skip validation steps

---

## Error Handling

### Sub-Skill Failure

If a sub-skill fails or produces incomplete output:

1. **Acknowledge:** `⚠️ Issue with Stage [X]: [explanation]`
2. **Options:**
   - Retry with same inputs
   - Retry with clarified inputs
   - Skip stage (PRD incomplete)
   - Abort and review partial PRD
3. **User choice:** Let user decide how to proceed

### Document Update Failure

If PRD document update fails:

1. **Preserve output:** Save sub-skill output to separate file
2. **Notify user:** Explain what happened
3. **Manual recovery:** Provide output for manual PRD update

---

## Future Enhancements

### Potential v4.0 Features

1. **Multi-agent support**
   - Auto-detect multi-role products
   - Generate separate agent architectures
   - Define inter-agent communication

2. **Template library**
   - Pre-built patterns for common domains
   - E-commerce, SaaS, CMS, etc.

3. **Visual diagrams**
   - Auto-generate mermaid diagrams
   - ER diagrams for data model
   - Flow diagrams for logic

4. **AI-powered suggestions**
   - LLM-suggested architecture patterns
   - Best practice recommendations
   - Common pitfall warnings

5. **Validation & completeness checks**
   - Automated PRD completeness validation
   - Missing logic/UI detection
   - Consistency verification

---

## Migration Guide

### From v2.0 to v3.0

**If you have a v2.0 PRD in progress:**

- **After Stage 1:** Continue as normal (unchanged)
- **At Stage 2/3/4:** Use new Stage 2 (architecture-designer)
  - Answer integrated questions once
  - Get complete architecture in one pass
- **Skip Stage 5:** Implementation roadmap already populated from Stage 1

**If starting fresh:**
- Follow new 2-stage process
- Expect ~40% faster generation
- Better architecture consistency guaranteed

**For developers:**
- Update invocations to use `architecture-designer` instead of separate skills
- Remove dependencies on deprecated skills
- Update any custom workflows

---

## References

- [PRD Generator SKILL.md](SKILL.md) - Main skill documentation
- [Architecture Designer](../architecture-designer/SKILL.md) - Stage 2 sub-skill
- [User Story Mapping](../user-story-mapping/SKILL.md) - Stage 1 sub-skill

---

**Document Version:** 3.0
**Last Updated:** 2026-01-21
**Status:** Production
**Author:** PRD Generator Team

