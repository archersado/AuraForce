# PRD with Diagram Generator Workflow

专业的产品需求文档(PRD)和图表生成工作流

## 工作流概述

这个工作流通过结构化的协作过程，帮助产品灵感创造者生成高质量的PRD文档和配套的专业图表。工作流采用企业级文档标准，支持多会话创建，确保输出物可直接用于开发团队协作。

## 主要特性

### 📝 完整的PRD生成
- 产品概览（目标、愿景、背景）
- 用户分析（目标用户、用例、用户旅程）
- 功能需求（核心功能、规格、优先级）
- 非功能性需求（性能、安全、可用性）
- 验收标准（成功指标、验收条件）
- 附录（术语表、图表索引、参考资料）

### 🎨 专业图表设计
- 用户-系统交互图
- 系统边界图
- 产品模块图
- 数据流转图

所有图表提供两种格式：
- Excalidraw JSON（可编辑）
- PNG图片（展示用）

### 🔄 工作流特色
- **多会话支持**：可随时暂停和恢复
- **高频互动**：AI高频提问，用户可反问
- **迭代优化**：每章节确认后再继续
- **质量保证**：企业级文档标准验证
- **工具集成**：Web搜索、Context-7、Excalidraw

## 工作流步骤

### Step 1: 初始化和项目设置
- 创建项目文件夹
- 初始化PRD文档
- 检测continuation状态

### Step 2: 产品概念收集
- 使用Brainstorming技术
- 收集产品概念、目标用户、基础需求
- 确定产品类型和范围

### Step 3: 需求详细分析
- 使用Advanced Elicitation深度挖掘
- 分析功能需求和非功能需求
- 定义技术约束和验收标准

### Step 4: PRD文档生成
- 按标准结构生成完整PRD
- 每章节用户确认后继续
- 确保企业级文档质量

### Step 5: 图表设计和创建
- 创建4种专业图表
- 使用Excalidraw生成可编辑版本
- 导出PNG展示版本
- 应用企业视觉风格

### Step 6: 最终审查和输出
- 全面质量检查
- 组织完整交付包
- 生成使用指南
- 标记工作流完成

## 使用方法

### 启动工作流

```bash
# 通过技能调用
/prd-with-diagram-generator

# 或者加载工作流
加载工作流: prd-with-diagram-generator
```

### 恢复未完成的PRD

工作流会自动检测未完成的PRD项目并提示继续。

### 创建新的PRD项目

如果已有完成的PRD，工作流会询问是创建新项目还是更新现有项目。

## 输出物

### 主要交付物

```
prd-{project_name}-deliverable/
├── README.md                       # 项目使用指南
├── prd-{project_name}.md           # 主PRD文档
├── diagrams/                       # 图表文件夹
│   ├── user-system-interaction.json
│   ├── user-system-interaction.png
│   ├── system-boundary.json
│   ├── system-boundary.png
│   ├── product-modules.json
│   ├── product-modules.png
│   ├── data-flow.json
│   └── data-flow.png
├── templates/                      # 模板文件
│   └── prd-template.md
└── metadata/                       # 元数据
    ├── project-info.json
    └── creation-log.md
```

### 文档特点

- ✅ 企业级专业结构
- ✅ Markdown标准格式
- ✅ 完整的章节编号
- ✅ 清晰的图表引用
- ✅ 可直接用于开发

### 图表特点

- ✅ 严谨的企业视觉风格
- ✅ 统一的色彩方案
- ✅ 专业的布局设计
- ✅ 双格式输出（JSON+PNG）

## 质量标准

### 文档质量
- PRD结构完整，内容专业
- 语言表达清晰准确
- 格式统一，符合企业标准
- 所有章节逻辑连贯

### 图表质量
- 视觉设计专业统一
- 技术规格符合要求
- 内容准确反映需求
- 可编辑性和展示性兼备

### 可用性
- 开发团队可直接使用
- 业务团队可理解沟通
- 质量团队可据此测试
- 管理团队可用于决策

## 技术规格

### 核心工具
- **Advanced Elicitation**: 深度需求挖掘
- **Brainstorming**: 结构化创意探索
- **Web-Browsing**: 竞品研究和技术标准查询
- **Context-7**: API文档和技术参考
- **Excalidraw MCP**: 专业图表生成
- **File I/O**: 文档和图表管理

### 状态管理
- **Sidecar File**: 会话间状态持续
- **Frontmatter Tracking**: 进度跟踪
- **Continuation Support**: 多会话恢复

## 适用场景

### 适合的产品类型
- 移动应用
- Web应用
- 企业软件
- API服务
- SaaS产品
- 平台系统

### 适合的用户
- 产品经理
- 产品创新者
- 创业者
- 项目负责人
- 需求分析师

## 最佳实践

### 准备工作
1. 明确产品核心概念
2. 了解目标用户群体
3. 准备相关参考资料（可选）

### 使用建议
1. 充分利用AI的提问和引导
2. 每个章节仔细审查后再继续
3. 使用Advanced Elicitation深化内容
4. 对图表提出具体的调整需求

### 质量保证
1. 完成后使用质量检查清单
2. 让团队成员审查文档
3. 确保图表与文档一致
4. 验证所有链接和引用

## 版本信息

- **工作流版本**: 1.0
- **创建日期**: 2025-12-30
- **模块**: custom
- **文档语言**: 中文
- **输出语言**: 中文

## 支持和反馈

如有问题或建议，请通过以下方式联系：
- 查看质量检查清单: `validation/quality-checklist.md`
- 参考PRD模板: `templates/prd-template.md`
- 查看图表样式配置: `data/enterprise-diagram-styles.json`

## 许可证

本工作流遵循BMAD工作流标准规范。