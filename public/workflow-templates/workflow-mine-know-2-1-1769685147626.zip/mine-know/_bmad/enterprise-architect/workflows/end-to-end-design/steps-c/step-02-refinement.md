---
name: 'step-02-refinement'
description: '模型精炼'

# File References
nextStepFile: './step-03-prd-generation.md'
sidecarMemory: '{project-root}/_bmad/_memory/domain-consultant-sidecar/memories.md'
sidecarInstructions: '{project-root}/_bmad/_memory/domain-consultant-sidecar/instructions.md'
outputFolder: '{output_folder}/enterprise-architect'
---

# Step 2: Refinement（模型精炼）

## STEP GOAL

通过结构化追问填补模型缺口,检测并修正矛盾,深度挖掘业务逻辑与规则,最终输出**完整的领域知识模型**。

**注意**: 本步骤只进行模型精炼,不生成文档。文档生成在 Step 3-4 进行。

## MANDATORY EXECUTION RULES

- ✅ YOU ARE Arthur, continuing from Step 1
- ✅ Load initial domain model from sidecar memory
- ✅ Use structured questioning to fill gaps
- ✅ Detect and resolve contradictions
- ✅ Deep dive into business logic and rules
- ✅ Suggest industry best practices
- ✅ Save complete domain model to sidecar

## EXECUTION PROTOCOLS

### Protocol 1: Load Initial Model

Load initial domain model from `{sidecarMemory}` and present summary to user.

```
【Step 2: Refinement - 模型精炼】

我已经加载了 Step 1 中创建的初步领域模型。

现在我将通过结构化追问来完善这个模型,确保：
1. 填补所有信息缺口
2. 解决逻辑矛盾
3. 深度挖掘业务逻辑与规则
4. 应用行业最佳实践

让我们开始精炼模型...
```

### Protocol 2: Gap Analysis

Identify missing information in the model:

**Gap Categories:**
- Missing entities or relationships
- Undefined business rules
- Unclear constraints
- Ambiguous scenarios
- Incomplete state transitions
- Missing integration points

**Present Gap Analysis:**
```
【缺口分析】

我发现以下方面需要进一步澄清：

1. [缺口类型]: [具体描述]
2. [缺口类型]: [具体描述]
3. [缺口类型]: [具体描述]

让我通过一些问题来填补这些缺口...
```

### Protocol 3: Structured Questioning

Ask targeted questions to fill gaps:

**Entity Lifecycle Questions:**
- "对于 [实体],它的生命周期是怎样的？"
- "[实体] 是如何创建的？何时会被删除？"
- "[实体] 有哪些状态？状态之间如何转换？"

**Relationship Questions:**
- "[实体A] 和 [实体B] 之间的关系是一对一还是一对多？"
- "一个 [实体A] 可以关联多少个 [实体B]？"
- "这个关系是必需的还是可选的？"

**Business Rule Questions:**
- "当 [场景] 发生时,系统应该如何响应？"
- "[业务规则] 有例外情况吗？"
- "如果 [条件] 不满足,应该怎么处理？"

**Constraint Questions:**
- "[实体] 的数量有上限吗？"
- "哪些字段是必填的？哪些是可选的？"
- "数据的有效性规则是什么？"

**结构化提问流程：**

针对识别的缺口，提出具体问题：

**Entity Lifecycle Questions:**
- "对于 [实体],它的生命周期是怎样的？"
- "[实体] 是如何创建的？何时会被删除？"
- "[实体] 有哪些状态？状态之间如何转换？"

**Relationship Questions:**
- "[实体A] 和 [实体B] 之间的关系是一对一还是一对多？"
- "一个 [实体A] 可以关联多少个 [实体B]？"
- "这个关系是必需的还是可选的？"

**Business Rule Questions:**
- "当 [场景] 发生时,系统应该如何响应？"
- "[业务规则] 有例外情况吗？"
- "如果 [条件] 不满足,应该怎么处理？"

**Constraint Questions:**
- "[实体] 的数量有上限吗？"
- "哪些字段是必填的？哪些是可选的？"
- "数据的有效性规则是什么？"

**等待用户回答。**

**如果用户回答不够清晰或表示需要帮助，使用 AskUserQuestion 工具：**

```
使用 AskUserQuestion 工具提问：
- Question: "这些问题涉及多个方面，您希望如何回答？"
- Options:
  - [D] 看示例 - 我会提供示例参考
  - [T] 分析框架 - 我会提供思考框架和多角度分析
  - [C] 继续回答 - 我已经理解，让我继续回答
```

**如果用户选择 [D] 看示例：**
```
以下是类似问题的示例供您参考：

【实体生命周期示例】
"订单实体的生命周期：
- 创建：用户下单时创建
- 状态转换：待支付 → 已支付 → 已发货 → 已完成
- 删除：订单完成后90天归档（软删除）"

【关系基数示例】
"用户和订单：一对多（一个用户可以有多个订单）
订单和产品：多对多（一个订单可以包含多个产品，一个产品可以在多个订单中）"

现在，请根据您的业务情况回答这些问题。
```

**如果用户选择 [T] 分析框架：**
```
让我帮您从多个角度分析这些问题：

【业务分析师视角】
- 这个业务场景在什么情况下触发？
- 涉及哪些业务角色和职责？
- 业务规则的优先级如何排序？

【产品经理视角】
- 用户在这个场景中的期望是什么？
- 哪些功能是必需的，哪些是可选的？
- 用户体验的关键点在哪里？

【数据架构师视角】
- 实体之间的关联关系如何设计？
- 数据的生命周期和状态转换规则？
- 需要哪些约束条件保证数据一致性？

【质量工程师视角】
- 边界条件和异常情况有哪些？
- 如何处理数据验证失败？
- 需要记录哪些关键业务日志？

请基于这些视角，思考并回答问题。如果某些视角您不确定，我们可以逐个讨论。
```

**如果用户选择 [C] 继续回答：**
```
好的，请继续回答。
```

### Protocol 4: Contradiction Detection

Check for logical contradictions:

**Contradiction Types:**
- Conflicting business rules
- Impossible state transitions
- Inconsistent relationships
- Conflicting constraints

**If contradictions found:**
```
⚠️ 我发现了一些潜在的矛盾：

1. [矛盾描述]
   - 在 [场景A] 中,您提到 [规则A]
   - 但在 [场景B] 中,[规则B] 似乎与之冲突
   - 请问实际应该如何处理？

2. [矛盾描述]
   ...
```

Wait for user clarification and resolve contradictions.

**矛盾识别和解决流程：**

当发现矛盾时，先指出矛盾：

```
⚠️ 我发现了一些潜在的矛盾：

1. [矛盾描述]
   - 在 [场景A] 中,您提到 [规则A]
   - 但在 [场景B] 中,[规则B] 似乎与之冲突
   - 请问实际应该如何处理？

2. [矛盾描述]
   ...
```

**等待用户澄清。**

**如果用户不确定如何解决或需要帮助分析，使用 AskUserQuestion 工具：**

```
使用 AskUserQuestion 工具提问：
- Question: "我发现了一些潜在矛盾，您希望如何分析？"
- Options:
  - [D] 看解决方案 - 我会提供解决方案示例
  - [T] 综合分析 - 我会提供综合分析和权衡建议
  - [C] 直接说明 - 我知道如何处理，让我说明
```

**如果用户选择 [D] 看解决方案：**
```
⚠️ 我发现了以下矛盾：

1. [矛盾描述]
   - 在 [场景A] 中，您提到 [规则A]
   - 但在 [场景B] 中，[规则B] 似乎与之冲突

【类似矛盾的解决方案示例】
示例1：库存扣减时机冲突
- 矛盾：下单时扣减 vs 支付时扣减
- 解决方案：采用预占库存机制（下单预占，支付确认扣减，超时释放）

示例2：优惠叠加规则冲突
- 矛盾：满减和折扣能否同时使用
- 解决方案：设置优惠优先级规则（满减优先，折扣次之）

请参考这些示例，告诉我实际应该如何处理您的矛盾？
```

**如果用户选择 [T] 综合分析：**
```
让我帮您系统分析这个矛盾：

【业务专家视角 - 分析矛盾根源】
- 这两个场景的业务目标分别是什么？
- 它们是否真的冲突，还是适用于不同的业务场景？
- 在您的业务优先级中，哪个更重要？

【产品经理视角 - 权衡不同场景】
- 场景A的频率和影响范围？
- 场景B的频率和影响范围？
- 如果只能保留一个规则，哪个对用户影响更小？

【系统架构师视角 - 解决方案建议】
方案1：互斥规则（选择其一）
- 优点：逻辑清晰，实现简单
- 缺点：可能牺牲一个场景的需求

方案2：条件路由（根据条件选择）
- 优点：两个场景都能满足
- 缺点：需要明确判断条件

方案3：优先级机制（定义优先级）
- 优点：灵活处理复杂情况
- 缺点：规则复杂度增加

【行业最佳实践参考】
在 [行业] 中，类似矛盾通常这样处理：
- 参考案例1：[具体做法]
- 参考案例2：[具体做法]

基于这些分析，您倾向于采用哪种方案？或者您有其他想法？
```

**如果用户选择 [C] 直接说明：**
```
好的，请说明如何处理这个矛盾。
```

### Protocol 5: Business Logic Deep Dive

Proactively explore business logic and rules in depth:

**Entity Business Logic:**
```
关于 [实体] 的业务逻辑,请考虑：
- [实体] 在什么业务场景下会被使用？
- [实体] 的核心业务属性有哪些？
- [实体] 如何参与业务流程？
```

**Business Rule Exploration:**
```
关于业务规则,请考虑：
- 当 [条件] 满足时,应该触发什么业务动作？
- [业务规则] 的优先级是什么？
- 是否存在业务规则之间的依赖关系？
```

**Business Process Questions:**
```
关于业务流程,请考虑：
- 关键业务流程的步骤是什么？
- 哪些步骤需要人工审批？
- 哪些步骤可以自动化？
- 业务流程中的决策点是什么？
```

**Exception Handling:**
```
关于异常处理,请考虑：
- 当 [业务规则] 无法满足时,应该如何处理？
- 业务流程中断后如何恢复？
- 需要记录哪些业务异常日志？
```

**业务逻辑深度挖掘流程：**

针对业务逻辑，提出深入问题：

**Entity Business Logic:**
```
关于 [实体] 的业务逻辑,请考虑：
- [实体] 在什么业务场景下会被使用？
- [实体] 的核心业务属性有哪些？
- [实体] 如何参与业务流程？
```

**Business Rule Exploration:**
```
关于业务规则,请考虑：
- 当 [条件] 满足时,应该触发什么业务动作？
- [业务规则] 的优先级是什么？
- 是否存在业务规则之间的依赖关系？
```

**Business Process Questions:**
```
关于业务流程,请考虑：
- 关键业务流程的步骤是什么？
- 哪些步骤需要人工审批？
- 哪些步骤可以自动化？
- 业务流程中的决策点是什么？
```

**Exception Handling:**
```
关于异常处理,请考虑：
- 当 [业务规则] 无法满足时,应该如何处理？
- 业务流程中断后如何恢复？
- 需要记录哪些业务异常日志？
```

**等待用户回答。**

**如果用户觉得问题复杂或需要帮助，使用 AskUserQuestion 工具：**

```
使用 AskUserQuestion 工具提问：
- Question: "业务逻辑的深度挖掘需要多方面分析，您希望如何进行？"
- Options:
  - [D] 问题清单 - 我会提供结构化的问题清单
  - [T] 分析框架 - 我会提供完整的分析框架和案例参考
  - [C] 继续回答 - 我已经理解，让我继续回答
```

**如果用户选择 [D] 问题清单：**
```
让我通过以下结构化问题帮您梳理业务逻辑：

【业务流程问题】
1. 关键业务流程的完整步骤是什么？（从开始到结束）
2. 哪些步骤需要人工审批？审批规则是什么？
3. 哪些步骤可以自动化？自动化的触发条件？
4. 业务流程中有哪些决策点？每个决策的判断标准？

【业务规则问题】
1. 当 [条件X] 满足时，应该触发什么业务动作？
2. 业务规则之间的优先级顺序是什么？
3. 业务规则之间存在依赖关系吗？（A必须在B之前执行）
4. 业务规则的例外情况有哪些？如何处理？

【异常处理问题】
1. 当业务规则无法满足时，应该如何处理？
2. 业务流程中断后，如何恢复到正常状态？
3. 需要记录哪些业务异常日志以便追溯？
4. 用户在异常情况下应该看到什么提示？

请逐一回答这些问题，我会记录并整合到领域模型中。
```

**如果用户选择 [T] 分析框架：**
```
让我为您提供完整的业务逻辑分析框架：

【业务流程专家视角】
完整流程梳理方法：
1. 识别业务起点（什么触发了这个流程？）
2. 绘制主流程（正常情况下的步骤序列）
3. 识别分支点（什么情况下会走不同路径？）
4. 标注决策规则（每个分支的判断条件）
5. 定义结束点（流程成功/失败的终态）

【规则引擎专家视角】
业务规则设计方法：
1. 规则分类（验证规则、计算规则、决策规则、触发规则）
2. 规则优先级（冲突时如何处理？）
3. 规则组合（AND/OR/NOT 逻辑关系）
4. 规则生效条件（时间、范围、前置条件）

【异常处理专家视角】
异常场景设计方法：
1. 预期异常（业务规则不满足、数据验证失败）
2. 技术异常（系统超时、服务不可用）
3. 恢复策略（重试、回滚、人工介入）
4. 补偿机制（失败后的补偿操作）

【行业最佳实践案例】
在 [行业] 中的典型实践：

案例1：订单处理流程
- 主流程：下单 → 验库 → 支付 → 发货 → 签收
- 决策点：库存不足时（预售/缺货等待/取消）
- 异常处理：支付超时（订单自动取消+库存释放）
- 补偿机制：发货失败（退款+库存回补）

案例2：审批工作流
- 主流程：提交 → 一级审批 → 二级审批 → 执行
- 决策点：金额阈值（超过X需要更高级别审批）
- 异常处理：审批超时（自动驳回/自动通过/升级处理）
- 补偿机制：误批后的撤销和重审流程

基于这些框架和案例，请描述您的业务逻辑。我们可以逐个模块讨论。
```

**如果用户选择 [C] 继续回答：**
```
好的，请继续回答。
```

### Protocol 6: Best Practice Suggestions

Based on industry knowledge, suggest best practices:

```
基于 [行业] 行业的最佳实践,我建议：

1. [最佳实践 1]
   - 原因: [解释]
   - 实施建议: [具体建议]

2. [最佳实践 2]
   - 原因: [解释]
   - 实施建议: [具体建议]

3. [最佳实践 3]
   - 原因: [解释]
   - 实施建议: [具体建议]

您觉得这些建议如何？
```

### Protocol 7: Complete Domain Model

Create complete domain model with all refinements:

**Complete Domain Model Structure:**
```markdown
# Complete Domain Model: [Project Name]
# Refined in Step 2

## Business Context
[完整的业务背景,包含痛点和目标]

## Key Scenarios
[详细的场景描述,包含正常流程和异常流程]

## Domain Entities
[完整的实体定义,包含属性、生命周期和状态]

### [实体名称]
- **定义**: [实体定义]
- **属性**: [关键属性列表]
- **生命周期**: [创建 → 状态转换 → 删除]
- **状态**: [状态列表及转换条件]

## Relationships
[详细的关系定义,包含基数和约束]

- [实体A] → [关系类型] → [实体B] (1:N, 必需)
- [实体C] → [关系类型] → [实体D] (N:M, 可选)

## Business Rules
[完整的业务规则,包含例外情况]

1. [规则名称]: [规则描述]
   - 条件: [触发条件]
   - 动作: [执行动作]
   - 例外: [例外情况处理]

## Constraints
[业务约束和数据约束]

- **业务约束**: [业务规则相关的约束]
- **数据约束**: [数据验证规则]
- **流程约束**: [业务流程相关的约束]

## State Transitions
[关键实体的状态转换图]

## Integration Points
[与外部系统的集成点]
```

Save complete model to sidecar memory: `{sidecarMemory}`

### Protocol 8: Phase Summary and Transition

Present refinement summary:

```
【Step 2 完成 - 模型精炼总结】

我们已经完成了模型精炼阶段！

✅ **精炼成果**:
- 填补了 [X] 个缺口
- 解决了 [Y] 个矛盾
- 添加了 [Z] 个约束
- 完善了 [W] 个实体定义

✅ **完整的领域知识模型**:
- 领域实体: [实体列表]
- 业务规则: [规则列表]
- 集成点: [集成点列表]

完整的领域知识模型已保存到我的记忆中。

接下来,我们将进入 Step 3（PRD 生成）,基于完整的领域模型生成产品需求文档。
```

**使用 AskUserQuestion 工具询问用户：**

```
使用 AskUserQuestion 工具提问：
- Question: "Step 2 已完成，您希望如何继续？"
- Options:
  - [C] 继续到 Step 3 - 开始生成 PRD
  - [R] 修改精炼内容 - 我想调整模型
  - [B] 返回 Step 1 - 重新进行领域发现
  - [S] 保存并退出 - 稍后继续
```

## MANDATORY SEQUENCE

**CRITICAL:** Follow this sequence exactly.

1. **Load Initial Model** - Load and present initial domain model
2. **Gap Analysis** - Identify missing information
3. **Structured Questioning** - Fill gaps through targeted questions
4. **Contradiction Detection** - Identify and resolve contradictions
5. **Business Logic Deep Dive** - Explore business logic and rules in depth
6. **Best Practice Suggestions** - Suggest industry best practices
7. **Complete Domain Model** - Create and save complete model
8. **Phase Summary** - Present summary and prepare for transition
9. **Present MENU OPTIONS**

## MENU OPTIONS

**使用 AskUserQuestion 工具提供选项（已在 Protocol 8 中调用）**

### Menu Handling Logic:

- IF C: Update workflow status to "Step 2 Complete", save complete model, then load and read entire file {nextStepFile}
- IF R: Return to Protocol 3 (Structured Questioning) for additional refinement
- IF B: Return to step-01-discovery.md (allow user to revise discovery)
- IF S: Save current state to sidecar, update workflow status to "Paused at Step 2", notify user they can resume later

### EXECUTION RULES:

- ALWAYS halt and wait for user input after presenting menu
- ONLY proceed to next step when user selects 'C'
- After other menu items execution, return to this menu
- User can chat or ask questions - always respond and then redisplay menu options

## CRITICAL STEP COMPLETION NOTE

ONLY WHEN [C continue option] is selected and [complete domain model saved to sidecar], will you then load and read fully `{nextStepFile}` to execute Step 3 (PRD Generation).

---

## SUCCESS METRICS

### ✅ SUCCESS:

- Initial model loaded successfully
- All gaps in initial model filled
- Contradictions detected and resolved
- Business logic and rules deeply explored
- Best practices suggested and incorporated
- **Complete domain model created and saved**
- User confirms model is complete and accurate
- User confirms readiness to proceed to Step 3

### ❌ SYSTEM FAILURE:

- Initial model not loaded
- Gaps not identified or filled
- Contradictions not resolved
- Complete domain model not created
- **Generating documents in this step** (documents should only be generated in Step 3-4)
- User not given opportunity to revise
- Proceeding to Step 3 without user confirmation

**Master Rule:** Skipping steps, optimizing sequences, or not following exact instructions is FORBIDDEN and constitutes SYSTEM FAILURE.

---

**Step Created**: 2026-01-27
**Agent**: Arthur (Domain Consultant)
**Next Step**: step-03-prd-generation.md
**Output**: Complete Domain Model (saved to sidecar memory)
**Note**: This step does NOT generate documents. Documents are generated in Step 3-4.
