---
description: 'Splits large markdown documents into smaller, organized files based on level 2 (default) sections'
---

# Shard Document

LOAD and execute the task at: _bmad/core/tasks/shard-doc.xml

Follow all instructions in the task file exactly as written.
