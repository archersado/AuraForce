---
name: end-to-end-design
description: 端到端产品设计工作流 V6.1 — 从对话到企业级设计文档（分步式文档生成）
web_bundle: true
version: 6.1.0
---

# End-to-End Product Design Workflow V6.1

**Goal:** 从用户对话到最终确认的两份企业级设计文档的端到端流程（分步式文档生成）

**Description:** 这是 Enterprise Architect AI 的核心工作流 V6.1 版本，采用 BMAD v6 step-file 架构。工作流协调 Arthur（领域顾问）和 Claude（设计协调者）两个代理，以及三个文档生成 skills，通过分步式方式生成产品说明书和详细设计。

---

## What's New in V6.1

### 架构升级
- ✅ 从 phase-file 架构升级到 BMAD v6 step-file 架构
- ✅ 标准化的 tri-modal 结构（steps-c/, steps-v/, steps-e/）
- ✅ 增强的 data/ 和 templates/ 支持
- ✅ **6步骤分离式设计**：Discovery, Refinement, PRD, Interaction, Architecture, Validation

### 文档生成逻辑变更
- ✅ **分步式文档生成**：先完成领域建模,再分步生成文档
- ✅ **Step 1-2: 领域建模**：Discovery + Refinement 完成完整的领域模型
- ✅ **Step 3-4: 文档生成**：PRD + Interaction 分步生成产品说明书
- ✅ **文档合并**：PRD + Interaction 合并为"产品说明书.md"
- ✅ **两份文档输出**：产品说明书 + 详细设计

### 新的工作流阶段
- **Step 1**: Discovery（领域发现）
- **Step 2**: Refinement（模型精炼）
- **Step 3**: PRD Generation（生成产品说明书第一部分）
- **Step 4**: Interaction Generation（追加产品说明书第二部分）
- **Step 5**: Architecture（生成独立的详细设计）
- **Step 6**: Validation（验证两份文档的一致性）

---

## Workflow Architecture

This workflow uses **BMAD v6 step-file architecture** for disciplined execution:

### Core Principles

- **Step-based Design**: Each step is a self-contained instruction file
- **Just-In-Time Loading**: Only the current step file is in memory
- **Sequential Enforcement**: Steps completed in order with validation
- **State Tracking**: Document progress in sidecar memory
- **Agent Handoff**: Clear handoff protocol between Arthur and Claude
- **Tri-Modal Support**: Create, Validate, and Edit modes

### Step Processing Rules

1. **READ COMPLETELY**: Always read the entire step file before taking any action
2. **FOLLOW SEQUENCE**: Execute numbered protocols in order
3. **WAIT FOR INPUT**: Halt at decision points and wait for user confirmation
4. **CHECK CONTINUATION**: Only proceed when user confirms readiness
5. **SAVE STATE**: Update sidecar memory before loading next step
6. **LOAD NEXT**: When directed, load and execute the next step file

### Critical Rules

- 🛑 **NEVER** load multiple step files simultaneously
- 📖 **ALWAYS** read entire step file before execution
- 🚫 **NEVER** skip steps unless explicitly optional
- 💾 **ALWAYS** save progress to sidecar memory
- 🎯 **ALWAYS** follow exact instructions in step files
- ⏸️ **ALWAYS** halt at decision points and wait for input
- 📋 **NEVER** pre-load future steps

---

## Workflow Steps (Create Mode)

| Step | Name | Agent | Goal | Output |
|------|------|-------|------|--------|
| 1 | Discovery | Arthur | 场景引导、行业识别、知识挖掘 | 初步领域模型 |
| 2 | Refinement | Arthur | 结构追问、矛盾检测、约束提醒 | 完整领域模型 |
| 3 | PRD Generation | Arthur | 生成产品说明书第一部分（需求） | 产品说明书.md (Part 1) |
| 4 | Interaction Generation | Arthur | 追加产品说明书第二部分（交互设计） | 产品说明书.md (Part 1+2) |
| 5 | Architecture | Claude | 生成独立的详细设计 | 详细设计.md |
| 6 | Validation | Arthur | 验证两份文档的一致性 | 最终确认的文档 |

---

## Initialization Sequence

### 1. Configuration Loading

Load and read full config from `{project-root}/_bmad/bmb/config.yaml`:

- `user_name`, `communication_language`, `document_output_language`, `output_folder`
- ✅ YOU MUST ALWAYS SPEAK OUTPUT in your Agent communication style with the config `{communication_language}`

### 2. Sidecar Memory Check

Check Arthur's sidecar for existing workflow state:

```
{project-root}/_bmad/_memory/domain-consultant-sidecar/instructions.md
```

- If active workflow exists → Ask user if they want to continue or start new
- If no active workflow → Proceed to Step 1

### 3. Welcome Message

Present workflow overview to user:

```
欢迎使用企业级端到端产品设计工作流！

这个工作流将帮助您：
1. 通过对话挖掘行业领域知识
2. 构建结构化的概念模型
3. 分步生成两份企业级设计文档：
   - 产品说明书（需求 + 交互设计）
   - 详细设计（技术架构设计）
4. 验证文档一致性并确认最终版本

工作流包含 6 个步骤：
- Step 1: Discovery（领域发现）— 由产品顾问引导
- Step 2: Refinement（模型精炼）— 由产品顾问引导
- Step 3: PRD Generation（产品需求生成）— 由产品顾问生成
- Step 4: Interaction Generation（交互设计生成）— 由产品顾问生成
- Step 5: Architecture（技术架构生成）— 由架构专家协调
- Step 6: Validation（验证闭环）— 由产品顾问验证

准备好开始了吗？
```

Wait for user confirmation before proceeding.

### 4. Route to Step 1

Load, read completely, then execute `steps-c/step-01-discovery.md`

---

## Phase Handoff Protocol

### Arthur → Claude (Step 2 → Step 3)

**Arthur completes:**
- Save complete domain model to sidecar memory
- Save 产品说明书.md (Part 1 + Part 2) to output folder
- Update workflow status: "Step 2 Complete, ready for Architecture"
- Notify user: "领域模型和产品说明书已完成，现在将交给 Claude 生成详细设计"

**Claude receives:**
- Load domain model from Arthur's sidecar
- Load 产品说明书.md from output folder
- Verify model and document completeness
- Begin Step 3 (Architecture)

### Claude → Arthur (Step 3 → Step 4)

**Claude completes:**
- Save 详细设计.md to output folder
- Update workflow status: "Step 3 Complete, architecture generated"
- Notify user: "详细设计已生成，现在将交给 Arthur 进行验证"

**Arthur receives:**
- Load 产品说明书.md from output folder
- Load 详细设计.md from output folder
- Load domain model from sidecar
- Begin Step 4 (Validation)

---

## Backtracking Mechanism

If Step 4 (Validation) identifies issues:

1. **Arthur identifies problem:**
   - 产品说明书内部不一致（需求 vs 交互）
   - 技术架构不满足产品说明书需求
   - Logical conflicts
   - Missing requirements

2. **User confirmation:**
   - Ask user if they want to fix the issue
   - If yes → Backtrack to Step 2 (Refinement + Interaction)
   - If no → Accept documents as-is

3. **Backtrack execution:**
   - Update workflow status: "Backtracking to Refinement"
   - Save issue context to sidecar
   - Load Step 2 file with context about identified issues
   - Re-execute Step 2 → Step 3 → Step 4
   - Repeat until user confirms satisfaction (max 3 times)

---

## State Management

### Workflow State (stored in Arthur's sidecar)

```yaml
workflow_state:
  name: end-to-end-design
  version: 6.0.0
  status: active | completed | backtracking
  current_step: 1 | 2 | 3 | 4
  step_history:
    - step: 1
      completed_at: "2026-01-27T10:00:00Z"
      status: completed
      output: "产品说明书.md (Part 1)"
    - step: 2
      completed_at: "2026-01-27T10:30:00Z"
      status: completed
      output: "产品说明书.md (Part 1+2)"
  domain_model_path: "{sidecar}/domain-models/current-model.md"
  documents_path: "{output_folder}/enterprise-architect/{project-name}/"
  backtrack_count: 0
  last_updated: "2026-01-27T10:30:00Z"
```

---

## Output Structure

```
{output_folder}/enterprise-architect/{project-name}/
├── 产品说明书.md              # 产品说明书（需求 + 交互设计）
│   ├── 第一部分：产品需求      # Step 1 生成
│   └── 第二部分：交互设计      # Step 2 追加
├── 详细设计.md            # 技术架构设计（Step 3 生成）
└── domain-model.md           # 领域知识模型（参考）
```

**Key Changes from V5:**
- ✅ 2 份文档（原来是 3 份）
- ✅ 产品说明书.md 合并了 PRD + Interaction
- ✅ 渐进式生成（Step 1 生成 Part 1，Step 2 追加 Part 2）

---

## Tri-Modal Structure

### Create Mode (steps-c/)
- **step-01-discovery-prd.md**: Discovery + PRD generation
- **step-02-refinement-interaction.md**: Refinement + Interaction appending
- **step-03-architecture.md**: Architecture generation
- **step-04-validation.md**: Document validation

### Validate Mode (steps-v/)
- **step-01-validate-workflow.md**: Validate workflow compliance with BMAD v6

### Edit Mode (steps-e/)
- **step-e-01-assess.md**: Assess existing documents
- **step-e-02-edit.md**: Edit documents based on user requests

---

## Critical Success Factors

✅ **Step Completion:**
- Each step must be fully completed before proceeding
- User confirmation required at key decision points
- State saved to sidecar after each step

✅ **Agent Handoff:**
- Clear handoff protocol between Arthur and Claude
- Domain model and documents properly transferred
- Workflow status accurately updated

✅ **Progressive Document Generation:**
- Step 1: Generate 产品说明书.md Part 1 (Requirements)
- Step 2: Append 产品说明书.md Part 2 (Interaction) - DO NOT overwrite Part 1
- Step 3: Generate 详细设计.md (independent document)

✅ **Backtracking:**
- Issues identified and communicated clearly
- User decides whether to backtrack or accept
- Backtracking loop prevents infinite iterations (max 3)

✅ **Output Quality:**
- Two documents generated and validated
- Documents are consistent and complete
- User confirms satisfaction with final output

---

## Error Handling

**If Step fails:**
- Save error state to sidecar
- Notify user of the issue
- Offer options: retry, skip, or abort workflow

**If Agent unavailable:**
- Notify user that agent is required
- Pause workflow until agent is available
- Resume from last saved state

**If User aborts:**
- Save current state to sidecar
- Mark workflow as "paused"
- Allow resume from last completed step

---

## Skills Required

This workflow requires three skills to be implemented:

1. **domain-prd-generator**: Generate PRD from domain model (Step 1)
2. **interaction-mapper**: Generate interaction design from domain model + PRD (Step 2)
3. **domain-arch-designer**: Generate architecture from domain model + 产品说明书 (Step 3)

---

## Next Steps

**To begin the workflow:**

Load and execute: `steps-c/step-01-discovery-prd.md`

**To resume an existing workflow:**

Check sidecar state and load the appropriate step file based on `current_step` value.

**To validate the workflow itself:**

Load and execute: `steps-v/step-01-validate-workflow.md`

**To edit existing documents:**

Load and execute: `steps-e/step-e-01-assess.md`

---

**Created**: 2026-01-27
**Version**: 6.0.0
**Module**: enterprise-architect
**Agents**: Arthur (domain-consultant), Claude (design-coordinator)
**Architecture**: BMAD v6 step-file
**Converted from**: phase-file architecture (v5)

