# Getting Started with Enterprise Architect AI

Welcome to Enterprise Architect AI! This guide will help you get up and running.

---

## What This Module Does

Enterprise Architect AI 是一个独立模块，它让企业业务专家能够将他们的行业知识转化为企业级应用产品设计文档。

**核心能力：**
- 通过深度对话挖掘用户需求
- 主动提供行业洞见和技术约束提醒
- 生成符合企业标准的三份设计文档：
  - PRD.md — 产品需求文档
  - Interaction.md — 用户旅途与交互说明文档
  - Architecture.md — 技术架构设计文档

**适用人群：**
- 企业业务专家（财务、运营、供应链等）
- 具备一定产品能力的企业用户
- 雇主和中高层决策者

---

## Installation

如果还没有安装模块：

```bash
bmad install enterprise-architect
```

模块使用核心配置，无需额外的自定义配置。

---

## First Steps

### 1. 启动领域顾问

调用 `domain-consultant` 代理（Arthur）：

```
请 Arthur 帮助我设计一个[你想要的产品]
```

### 2. 描述你的业务想法

告诉 Arthur：
- **背景** — 你想要解决什么问题？
- **痛点** — 现状有什么问题？
- **期望** — 什么样的使用体验？

### 3. 跟随场景引导

Arthur 会询问具体的业务场景，请详细描述。

### 4. 接收行业建议

Arthur 会：
- 识别你所在的行业
- 提供行业方案概览
- 主动提醒技术约束

### 5. 深度对话

Arthur 会通过结构化追问获取完整信息，期间会自动记录识别到的概念。

### 6. 获取文档

Claude 会协调生成三份设计文档。

### 7. 验证确认

Arthur 会检查文档一致性，与你确认最终版本。

---

## Example: 智能仓储调度系统

### 用户输入

> "我想做一个智能仓储调度系统。现在的仓储调度完全靠人工，效率低下..."

### Arthur 的引导

> "能否描述一个具体的业务场景？比如，订单来了之后，现在是怎么处理的？"

### 用户描述

> "每当有客户订单，仓库里的员工会拿着纸质单子，到处找货..."

### Arthur 的行业识别

> "我理解这是小微仓储调度场景。在仓储行业，这类系统通常涉及：订单、库位、货物、员工、调度规则..."

### Arthur 的主动建议

> "建议您考虑：
> - **容量约束**：每个库位都有最大容量
> - **优先级规则**：紧急订单应该优先调度
> - **人力调配规则**：考虑季节性波动

### 深度对话后

Arthur 继续追问细节，完成知识模型的建立。

### 文档生成

Claude 协调生成：
- PRD.md — 产品需求文档
- Interaction.md — 用户旅途与交互说明文档
- Architecture.md — 技术架构设计文档

### 验证确认

Arthur 检查文档一致性，用户确认最终版本。

---

## Common Use Cases

### 场景 1: 制造业 MES 系统

制造业专家想要一个制造执行系统，Arthur 会识别制造业行业，提供行业特定的概念和建议。

### 场景 2: 能源管理系统

能源行业专家想要储能调度系统，Arthur 会使用能源行业插件提供深度行业知识。

### 场景 3: 财务管理仪表板

财务专家想要一个财务管理仪表板，Arthur 会识别行业知识，建议合规性和标准的考虑。

---

## What's Next?

- Check out the [Agents Reference](agents.md) to meet your team
- Browse the [Workflows Reference](workflows.md) to see what you can do
- See [Examples](examples.md) for real-world usage

---

## Need Help?

If you run into issues:
1. Check the troubleshooting section in examples.md
2. Review your module configuration
3. Consult the broader BMAD documentation
