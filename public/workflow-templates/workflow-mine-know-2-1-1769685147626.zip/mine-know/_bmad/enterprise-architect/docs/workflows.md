# Workflows Reference

Enterprise Architect AI 包含 1 个核心工作流：

---

## End-to-End Product Design

**ID:** `end-to-end-design`

**类型：** 核心工作流

**描述：** 从用户对话到最终确认的三份企业级设计文档的端到端流程

### 什么时候使用？

这是模块的主要工作流，当你需要：
- 从零开始设计一个企业级应用
- 将业务想法转化为编码就绪的设计文档
- 生成符合企业架构标准的产品设计

### 工作流程

#### Phase 1: Discovery（领域发现）

**负责代理：** Arthur

**目标：**
- 引导用户描述具体的业务场景
- 识别用户所在的行业
- 通过联网搜索和知识库获取行业背景
- 自动学习并记录新的领域概念

**关键活动：**
- 场景引导提问
- 行业识别与检索
- 知识库查询
- 概念自动记录（通过 MCP）

**输出：** 初步的领域知识模型

#### Phase 2: Refinement（模型精炼）

**负责代理：** Arthur

**目标：**
- 结构化追问，填补模型缺口
- 检测矛盾并修正
- 主动提醒技术约束和最佳实践
- 完善领域知识模型

**关键活动：**
- 结构化提问
- 矛盾检测
- 缺口识别
- 技术约束提醒
- 行业最佳实践建议

**输出：** 完整的领域知识模型

#### Phase 3: Documentation（文档生成）

**负责代理：** Claude

**目标：**
- 协调 skills 按正确顺序生成三份文档
- 确保文档格式符合标准
- 维护文档间的一致性

**Skills 协调顺序：**
1. `domain-prd-generator` → `PRD.md`
2. `interaction-mapper` → `Interaction.md`（引用 PRD 的用户故事）
3. `domain-arch-designer` → `Architecture.md`（引用 PRD 的需求）

**关键活动：**
- Skill 顺序协调
- 依赖关系处理
- 文档格式标准化
- 一致性维护

**输出：** 三份设计文档（PRD.md, Interaction.md, Architecture.md）

#### Phase 4: Validation（验证闭环）

**负责代理：** Arthur

**目标：**
- 检测文档间的一致性
- 识别逻辑冲突
- 与用户确认关键设计决策

**关键活动：**
- 一致性检测
- 交叉引用检查
- 用户确认对话
- 问题识别和记录

**回溯机制：**
如果发现问题，回到 Phase 2（Refinement）重新精炼模型，然后重新生成文档，直到用户确认满意。

**输出：** 最终确认的三份设计文档

---

## 回溯机制

工作流支持完整的回溯：

```
正常路径：Discovery → Refinement → Documentation → Validation（确认）→ 完成

回溯路径：Validation（发现问题）→ 回溯 Refinement → ... → Validation（确认）→ 完成
```

回溯条件：
- 文档间逻辑冲突
- 交叉引用不一致
- 用户对关键设计不满意
- 模型完整性问题

---

## Workflow Trigger

工作流通过以下方式触发：

1. **通过 Arthur 的 `[DD]` 命令** — 开始完整的端到端流程
2. **通过 Arthur 的 `[RM]` 命令** — 从 Refinement 阶段开始
3. **通过 Claude 的 `[GD]` 命令** — 从 Documentation 阶段开始（需已有完整知识模型）

---

## Workflow Inputs

### Required Inputs

- 用户对产品想法的初步描述（背景、痛点、期望的使用方式）

### Optional Inputs

- 现有知识模型（用于迭代更新）
- 特定行业插件选择

---

## Workflow Outputs

### Output Files

- `PRD.md` — 产品需求文档
- `Interaction.md` — 用户旅途与交互说明文档
- `Architecture.md` — 技术架构设计文档

### Output Format

三份文档采用双视角格式（业务含义 + 技术实现），既服务于业务人员（可读），也服务于开发团队（编码就绪）。

---

## Integration with Skills

工作流与以下 skills 协作：

| Skill | 用途 | 由 Claude 调用 |
|-------|------|---------------|
| domain-prd-generator | 生成产品需求文档 | 是 |
| interaction-mapper | 生成交互说明文档 | 是 |
| domain-arch-designer | 生成架构设计文档 | 是 |
| user-story-mapping | 协助生成用户故事部分 | 由 interaction-mapper 引用 |

---

## Next Steps

要开始使用工作流，只需：

1. 调用 Arthur：`Arthur，帮我设计一个[你的产品]`
2. 跟随对话引导
3. 获取并确认三份文档
