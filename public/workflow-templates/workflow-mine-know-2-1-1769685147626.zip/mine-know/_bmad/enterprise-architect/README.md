# Enterprise Architect AI: 企业级应用智能设计引擎

企业级应用智能设计引擎 — 将领域知识转化为企业级产品设计文档

通过深度对话挖掘行业知识，生成符合企业标准的产品需求、交互说明和技术架构文档

---

## Overview

Enterprise Architect AI 是一个独立的 BMAD 模块，旨在赋能企业业务专家将他们的行业知识转化为企业级应用产品设计文档。模块采用"企业级应用建筑师"的主题，通过两位专业代理（Arthur 和 Claude）协作，从模糊的业务想法到严谨、编码就绪的设计文档。

### 核心价值

- **企业级严谨度** — 输出符合 TOGAF/4A 企业架构标准的文档
- **行业深度** — 插件化行业知识库，提供专业行业洞见
- **主动建议** — 代理主动提醒技术约束和最佳实践
- **验证闭环** — 文档一致性检测与用户确认机制

### 核心输出

三份企业级设计文档：
1. **PRD.md** — 产品需求文档
2. **Interaction.md** — 用户旅途与交互说明文档
3. **Architecture.md** — 技术架构设计文档

输出文档具有双视角格式（业务含义 + 技术实现），业务人员可读，开发团队可直接使用。

---

## Installation

```bash
bmad install enterprise-architect
```

模块使用核心配置，无需额外的自定义配置。

---

## Quick Start

1. **启动模块**：调用领域顾问代理 `domain-consultant` (Arthur)
2. **描述问题**：告诉 Arthur 你想要设计什么样的产品，描述业务背景、痛点和期望的使用方式
3. **场景引导**：Arthur 会引导你描述具体的业务场景
4. **行业识别**：Arthur 会识别行业并提供行业方案概览
5. **深度对话**：Arthur 通过结构化追问获取完整信息
6. **文档生成**：Claude 协调生成三份设计文档
7. **验证确认**：Arthur 检测文档一致性，与你确认最终版本

**For detailed documentation, see [docs/](docs/).**

---

## Components

### Agents

Enterprise Architect AI 包含 2 个专业代理：

#### Arthur (Domain Consultant) 🎯
**图标:** `🎯`
**状态:** ✅ **已部署** (2026-01-26)
**文件:** `agents/domain-consultant.agent.yaml`

**角色：** 领域顾问，负责对话挖掘、知识建模、行业洞见、验证闭环

**关键能力：**
- 场景引导：询问用户具体的业务场景
- 行业识别：通过联网搜索和知识库识别行业
- 主动建议：基于行业知识提供建议
- 模型精炼：结构化追问、矛盾检测
- 验证闭环：文档一致性检测、用户确认

**菜单触发：**
- `[DD]` Discovery Dialog — 开始领域发现对话
- `[RM]` Refine Model — 精炼领域模型
- `[VC]` Validate Complete — 验证模型完整性
- `[WS]` Workflow Status — 查看当前工作流状态

**Sidecar:** `agents/domain-consultant-sidecar/`
- `memories.md` — 领域知识、对话历史、业务场景
- `instructions.md` — 操作协议、工作流状态、行业引用

**详细文档:** 参见 `agents/domain-consultant.README.md`

---

#### Claude (Design Coordinator) 📐
**图标:** `📐`

**角色：** 设计协调者，负责文档生成、技能协调、一致性维护

**关键能力：**
- 技能协调：按正确顺序调用文档生成 skills
- 文档生成管理：确保三份文档的正确生成和整合
- 一致性检查：文档间交叉引用检查、逻辑冲突识别
- 状态报告：清晰地向用户报告文档生成进度

**菜单触发：**
- `[GD]` Generate Documents — 生成三份设计文档
- `[CC]` Check Consistency — 检查文档一致性

---

### Workflows

#### End-to-End Product Design (端到端产品设计)

**类型：** 核心工作流

**描述：** 从用户对话到最终确认的三份企业级设计文档的端到端流程

**四个阶段：**
1. **Discovery（领域发现）** — Arthur 引导用户描述业务场景，识别行业，挖掘领域知识
2. **Refinement（模型精炼）** — Arthur 结构化追问，精炼模型，主动提醒技术约束
3. **Documentation（文档生成）** — Claude 协调 skills 生成三份设计文档
4. **Validation（验证闭环）** — Arthur 检测文档一致性，与用户确认

**回溯机制：** 如果在 Validation 阶段发现问题，可回溯到 Refinement 阶段重新精炼

---

## Module Structure

```
enterprise-architect/
├── module.yaml
├── README.md
├── TODO.md
├── docs/
│   ├── getting-started.md
│   ├── agents.md
│   ├── workflows.md
│   └── examples.md
├── agents/
│   ├── domain-consultant.spec.md
│   ├── domain-consultant.agent.yaml          ✅ 已部署
│   ├── domain-consultant.README.md           ✅ 已部署
│   ├── domain-consultant-sidecar/            ✅ 已部署
│   │   ├── memories.md
│   │   └── instructions.md
│   └── design-coordinator.spec.md
├── workflows/
│   └── end-to-end-design/
│       └── end-to-end-design.spec.md
├── domain-templates/
│   ├── universal/
│   │   └── patterns/
│   └── energy/                    # 首个行业插件
│       ├── concepts.md
│       ├── patterns.md
│       ├── entity-templates.md
│       └── business-rules.md
└── _module-installer/
    ├── installer.js
    └── platform-specifics/
```

---

## Documentation

For detailed user guides and documentation, see the **[docs/](docs/)** folder:
- [Getting Started](docs/getting-started.md)
- [Agents Reference](docs/agents.md)
- [Workflows Reference](docs/workflows.md)
- [Examples](docs/examples.md)

---

## Development Status

This module is currently in development. The following components are planned:

- [x] **Arthur (Domain Consultant)** ✅ 已部署 (2026-01-26)
  - agent.yaml 文件已创建
  - Sidecar 已配置（memories.md, instructions.md）
  - 4 个菜单命令已实现（DD, RM, VC, WS）
  - 详细文档已完成
- [ ] **Claude (Design Coordinator)** - 待创建
- [ ] **End-to-End Product Design Workflow** - 待创建
- [ ] **Skills**: domain-prd-generator, interaction-mapper, domain-arch-designer - 待创建
- [ ] **Industry Plugins**: Energy (首个行业插件) - 待创建

See TODO.md for detailed status.

---

## Author

Created via BMAD Module workflow

---

## License

Part of the BMAD framework.
