---
name: domain-prd-generator
description: 基于领域知识模型生成产品需求文档（PRD）
skill_type: document-generator
---

# Domain PRD Generator

**Purpose**: 将领域知识模型转化为结构化的产品需求文档（PRD.md），包含业务含义和技术实现的双视角格式。

---

## Skill Goal

从完整的领域知识模型生成企业级产品需求文档，文档应：
- 符合 TOGAF/4A 企业架构标准
- 包含业务视角和技术视角
- 清晰定义功能需求和非功能需求
- 可直接用于开发团队实施

---

## Input Requirements

### Required Input

**Domain Model** (from Arthur's sidecar):
```markdown
# Complete Domain Model

## Business Context
[业务背景和痛点]

## Key Scenarios
[详细的业务场景]

## Domain Entities
[实体定义，包含属性和生命周期]

## Relationships
[实体间关系，包含基数和约束]

## Business Rules
[业务规则，包含例外情况]

## Constraints
[技术和业务约束]

## State Transitions
[关键实体的状态转换]

## Integration Points
[与外部系统的集成点]
```

### Optional Input

- Industry context (行业背景)
- Existing PRD template (现有 PRD 模板)
- Stakeholder requirements (利益相关者需求)

---

## Output Format

### PRD.md Structure

```markdown
# 产品需求文档 (PRD)
# Product Requirements Document

**项目名称**: [Project Name]
**版本**: 1.0
**创建日期**: [Date]
**创建者**: Enterprise Architect AI
**状态**: Draft

---

## 1. 产品概述 (Product Overview)

### 1.1 业务背景 (Business Context)
[从 Domain Model 的 Business Context 提取]

### 1.2 问题陈述 (Problem Statement)
[从业务背景中提炼核心问题]

### 1.3 目标用户 (Target Users)
[从 Key Scenarios 中识别用户角色]

### 1.4 产品目标 (Product Goals)
[基于业务背景和场景定义产品目标]

---

## 2. 功能需求 (Functional Requirements)

### 2.1 用户故事 (User Stories)

#### US-001: [用户故事标题]
**作为** [用户角色]
**我想要** [功能描述]
**以便** [业务价值]

**验收标准**:
- [ ] [标准 1]
- [ ] [标准 2]

**优先级**: High/Medium/Low
**估算**: [Story Points]

[为每个关键场景创建用户故事]

### 2.2 功能模块 (Functional Modules)

#### 模块 1: [模块名称]
**描述**: [模块功能描述]
**相关实体**: [Domain Entities]
**业务规则**: [Business Rules]

**功能列表**:
- F-001: [功能 1 描述]
- F-002: [功能 2 描述]

[为每个领域实体或业务流程创建功能模块]

---

## 3. 非功能需求 (Non-Functional Requirements)

### 3.1 性能要求 (Performance Requirements)
[从 Constraints 中提取性能相关约束]

### 3.2 安全要求 (Security Requirements)
[从 Constraints 中提取安全相关约束]

### 3.3 可用性要求 (Usability Requirements)
[基于用户角色和场景定义]

### 3.4 可扩展性要求 (Scalability Requirements)
[从业务规模和增长预期推导]

### 3.5 合规性要求 (Compliance Requirements)
[基于行业标准和法规要求]

---

## 4. 数据模型 (Data Model)

### 4.1 核心实体 (Core Entities)

#### 实体: [Entity Name]
**描述**: [从 Domain Entities 提取]
**属性**:
| 属性名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| [attr1] | [type] | Yes/No | [description] |

**生命周期**: [从 State Transitions 提取]

[为每个 Domain Entity 创建实体定义]

### 4.2 实体关系 (Entity Relationships)
[从 Relationships 转化为 ERD 描述]

---

## 5. 业务规则 (Business Rules)

### BR-001: [规则标题]
**描述**: [从 Business Rules 提取]
**触发条件**: [When]
**执行动作**: [Then]
**例外情况**: [Exceptions]

[为每个 Business Rule 创建规则定义]

---

## 6. 集成需求 (Integration Requirements)

### 6.1 外部系统集成
[从 Integration Points 提取]

### 6.2 API 需求
[基于集成点定义 API 接口]

### 6.3 数据交换格式
[定义数据交换的格式和协议]

---

## 7. 约束条件 (Constraints)

### 7.1 技术约束
[从 Constraints 中提取技术相关约束]

### 7.2 业务约束
[从 Constraints 中提取业务相关约束]

### 7.3 时间约束
[项目时间线和里程碑]

### 7.4 资源约束
[人力、预算等资源限制]

---

## 8. 假设与依赖 (Assumptions and Dependencies)

### 8.1 假设 (Assumptions)
[列出关键假设]

### 8.2 依赖 (Dependencies)
[列出外部依赖项]

---

## 9. 风险与缓解 (Risks and Mitigation)

### 风险 1: [风险描述]
**影响**: High/Medium/Low
**概率**: High/Medium/Low
**缓解措施**: [措施描述]

---

## 10. 成功指标 (Success Metrics)

### 10.1 业务指标
[定义业务成功的衡量标准]

### 10.2 技术指标
[定义技术成功的衡量标准]

---

## 附录 (Appendix)

### A. 术语表 (Glossary)
[定义关键术语]

### B. 参考文档 (References)
- Domain Model: [path]
- Industry Standards: [references]

---

**文档生成**: Enterprise Architect AI
**基于**: Domain Model v[version]
**生成时间**: [timestamp]
```

---

## Generation Instructions

### Step 1: Load Domain Model

Read complete domain model from Arthur's sidecar:
```
{project-root}/_bmad/_memory/domain-consultant-sidecar/memories.md
```

### Step 2: Extract Key Information

From Domain Model, extract:
- **Business Context** → Section 1.1
- **Key Scenarios** → Section 2.1 (User Stories)
- **Domain Entities** → Section 4.1 (Core Entities)
- **Relationships** → Section 4.2 (Entity Relationships)
- **Business Rules** → Section 5 (Business Rules)
- **Constraints** → Section 3 (Non-Functional Requirements) & Section 7 (Constraints)
- **State Transitions** → Section 4.1 (Entity Lifecycle)
- **Integration Points** → Section 6 (Integration Requirements)

### Step 3: Transform Scenarios to User Stories

For each scenario in Key Scenarios:
1. Identify user role (actor)
2. Extract desired action (what they want)
3. Identify business value (why they want it)
4. Define acceptance criteria
5. Assign priority based on business importance

**Template**:
```
#### US-XXX: [Scenario Title]
**作为** [User Role from scenario]
**我想要** [Action from scenario]
**以便** [Business value from scenario]

**验收标准**:
- [ ] [Criterion 1 from scenario details]
- [ ] [Criterion 2 from scenario details]

**优先级**: [High if core scenario, Medium/Low otherwise]
```

### Step 4: Transform Entities to Data Model

For each entity in Domain Entities:
1. Extract entity name and description
2. List all attributes with types
3. Mark required vs optional attributes
4. Include lifecycle states from State Transitions
5. Document relationships from Relationships section

### Step 5: Transform Business Rules

For each rule in Business Rules:
1. Assign unique ID (BR-001, BR-002, etc.)
2. Extract rule description
3. Define trigger conditions (When)
4. Define actions (Then)
5. Document exceptions

### Step 6: Define Non-Functional Requirements

From Constraints section, categorize into:
- **Performance**: Response time, throughput, capacity
- **Security**: Authentication, authorization, encryption
- **Usability**: User experience, accessibility
- **Scalability**: Growth capacity, load handling
- **Compliance**: Industry standards, regulations

### Step 7: Identify Integration Requirements

From Integration Points:
1. List external systems
2. Define integration type (API, File, Database, etc.)
3. Specify data exchange format
4. Document authentication/authorization

### Step 8: Add Metadata and Context

- Project name from domain model
- Version: 1.0 (initial)
- Creation date: current date
- Status: Draft
- Industry context (if available)

### Step 9: Generate Complete PRD

Assemble all sections into complete PRD.md following the structure above.

### Step 10: Validate Output

Check that:
- [ ] All domain entities are represented
- [ ] All business rules are documented
- [ ] All scenarios are converted to user stories
- [ ] All constraints are categorized
- [ ] All integration points are defined
- [ ] Document is complete and consistent

---

## Quality Standards

### Completeness
- ✅ Every entity from domain model has corresponding data model entry
- ✅ Every scenario has corresponding user story
- ✅ Every business rule is documented
- ✅ All constraints are categorized

### Clarity
- ✅ User stories follow standard format (As a... I want... So that...)
- ✅ Acceptance criteria are specific and testable
- ✅ Technical terms are defined in glossary
- ✅ Sections are well-organized and easy to navigate

### Consistency
- ✅ Entity names consistent across document
- ✅ Terminology consistent with domain model
- ✅ No conflicting requirements
- ✅ Cross-references are accurate

### Actionability
- ✅ Requirements are specific enough for implementation
- ✅ Acceptance criteria are testable
- ✅ Priorities are clearly defined
- ✅ Dependencies are identified

---

## Example Usage

```yaml
# Called by Claude in Phase 3

skill: domain-prd-generator
input:
  domain_model_path: "{project-root}/_bmad/_memory/domain-consultant-sidecar/memories.md"
  output_path: "{output_folder}/enterprise-architect/PRD.md"
  project_name: "Warehouse Management System"
  industry: "logistics"
```

---

## Error Handling

**If domain model incomplete:**
- Identify missing sections
- Return error with specific gaps
- Suggest returning to Phase 2 (Refinement)

**If entity definitions unclear:**
- Flag ambiguous entities
- Request clarification
- Provide suggestions for improvement

**If business rules conflict:**
- Identify conflicting rules
- Highlight conflicts in output
- Recommend resolution

---

**Skill Created**: 2026-01-26
**Module**: enterprise-architect
**Type**: Document Generator
**Output**: PRD.md
