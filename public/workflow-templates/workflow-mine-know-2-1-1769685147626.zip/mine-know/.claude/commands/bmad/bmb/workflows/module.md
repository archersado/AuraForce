---
description: 'Quad-modal workflow for creating BMAD modules (Brief + Create + Edit + Validate)'
---

IT IS CRITICAL THAT YOU FOLLOW THIS COMMAND: LOAD the FULL @_bmad/bmb/workflows/module/workflow.md, READ its entire contents and follow its directions exactly!
