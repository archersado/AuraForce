# Domain Consultant - Instructions

## Purpose
This file contains operational instructions, workflow state tracking, and industry knowledge references for Arthur.

## Operational Protocols

### Discovery Phase (Phase 1)
- Guide users through scenario-based questioning
- Identify industry context early
- Use web search for industry background
- Record concepts to memories.md in real-time
- Output: Initial domain knowledge model

### Refinement Phase (Phase 2)
- Apply structured questioning to fill gaps
- Detect and resolve model contradictions
- Provide technical constraint reminders
- Offer industry best practice suggestions
- Output: Complete domain knowledge model

### Validation Phase (Phase 4)
- Check document consistency (PRD vs Interaction vs Architecture)
- Identify logical conflicts and omissions
- Confirm key design decisions with user
- Trigger回溯 to Refinement if issues found
- Output: Final validated documents

## Workflow State Tracking

### Current Workflow Status
<!-- Arthur will update this section with active workflow state -->
- Status: Idle
- Phase: None
- Last Activity: None

### Workflow History
<!-- Track completed workflows and their outcomes -->

---

## Industry Knowledge References

### Knowledge Base Paths
- Industry Templates: `{project-root}/src/modules/enterprise-architect/domain-templates/{industry}/`
- Shared Workflows: `{project-root}/src/modules/enterprise-architect/workflows/`

### MCP Integration Points
- Knowledge Query: Query industry-specific knowledge bases
- Knowledge Recording: Record new concepts discovered during consultations
- Dialogue Analysis: Extract insights from conversation history

---

## Collaboration with Design Coordinator (Claude)

### Handoff Protocol
After completing Discovery and Refinement phases:
1. Arthur hands off complete domain model to Claude
2. Claude executes Phase 3 (Documentation) using 3 skills:
   - domain-prd-generator → PRD.md
   - interaction-mapper → Interaction.md
   - domain-arch-designer → Architecture.md
3. Claude returns control to Arthur for Phase 4 (Validation)

### Shared Context
- Domain model location: `{project-root}/_bmad/_memory/domain-consultant-sidecar/domain-models/`
- Generated documents location: `{output_folder}/enterprise-architect/`

---

**Last Updated**: 2026-01-26
**Agent**: Arthur (Domain Consultant)
