#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse
import json
import os
import uuid

import requests

env = os.getenv('ENV', 'fat').lower()

ENV_CONFIG = {
    "dev": {
        "url": "https://dt-biz-base.dev.ennew.com",
        "access_key": "",
        "metaPaperId": 13735
    },
    "fat": {
        "url": "https://rdfa-gateway.fat.ennew.com/dt-biz-base",
        "access_key": "Ksjt8LZgr7dgeBVQhkbS6pNYvdMS51R4",
        "metaPaperId": 13735
    },
    "uat": {
        "url": "https://rdfa-gateway.uat.ennew.com/dt-biz-base",
        "access_key": "TsKwADFuHBGYXdfUVi4t7A2fckOLReH8",
        "metaPaperId": 13735
    },
    "prod": {
        "url": "https://rdfa-gateway.ennew.com/dt-biz-base",
        "access_key": "9GeND2MF703TwYh3XQj1crMlz3Yp4eYi",
        "metaPaperId": 13735
    }
}

def call_data_twin(data):
    try:
        response = requests.post(
            url=f'{ENV_CONFIG[env]["url"]}/api/aiModel/meta/generateSubMetaModel',
            json=data,
            headers={
                "Content-Type": "application/json",
                "x-gw-accesskey": ENV_CONFIG[env]["access_key"],
            }
        )
        response_data = response.json()
        if response_data.get("code", "") != "0":
            raise Exception(response_data.get("message", "未知错误"))
        return response_data.get("data").get("paperId")
    except Exception as e:
        print(f"提交数据失败: {str(e)}")
        return None

# 获取脚本所在目录的路径
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(SCRIPT_DIR)

# 获取节点定义和边定义文件的路径
NODE_DEFINE_PATH = os.path.join(SKILL_DIR, 'references', 'node-define.json')
EDGE_DEFINE_PATH = os.path.join(SKILL_DIR, 'references', 'edge-define.json')

def load_json_file(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"文件 {filepath} 不存在")
        return None

def get_domain_name_by_type(node_type, node_define):
    """根据节点类型获取domainName"""
    for node in node_define:
        if node['type'] == node_type:
            return node.get('name', '')
    return ''


def get_edge_name_by_type(edge_type, edge_define):
    """根据边类型获取边名称"""
    for edge in edge_define:
        if edge['type'] == edge_type:
            return edge.get('name', edge_type)
    # 对于嵌套business-object的特殊情况，返回原始type
    return edge_type


def transform_properties(properties, node_type):
    """转换节点properties到接口调用格式

    对于预定义属性节点（name + value格式）：
        直接使用name和value生成新的properties

    对于business-object节点（name + code + dataType格式）：
        转换为modelFieldCode, modelFieldDataType, modelFieldName, modelFieldDefaultValue格式
    """
    transformed_props = []

    # 判断是否为business-object节点
    if node_type == "business-object":
        # business-object节点的properties格式: {"name": "xxx", "code": "xxx", "dataType": "xxx"}
        for prop in properties:
            transformed_props.append({
                "modelFieldCode": prop.get("code", ""),
                "modelFieldType": prop.get("dataType", ""),
                "modelFieldName": prop.get("name", "")
            })
    else:
        for prop in properties:
            prop_name = prop.get("name", "")
            prop_value = prop.get("value", "")
            if isinstance(prop_value, list) or isinstance(prop_value, dict):
                prop_value = json.dumps(prop_value, ensure_ascii=False)
            transformed_props.append({
                "modelFieldName": prop_name,
                "modelFieldDefaultValue": prop_value
            })

    return transformed_props


def transform_node(node, node_define, uuid_map):
    """转换单个节点数据"""
    node_type = node.get('type', '')
    properties = node.get('properties', [])
    uuid_map[node.get('id')] = str(uuid.uuid4())
    return {
        "uuid": uuid_map[node.get('id')],
        "name": node.get('name', ''),
        "domainName": get_domain_name_by_type(node_type, node_define),
        "nodeType": "common",
        "description": node.get('description', ''),
        "properties": transform_properties(properties, node_type)
    }


def transform_edge(edge, edge_define,uuid_map):
    """转换单个边数据"""
    return {
        "sourceId": uuid_map[edge.get('sourceId')],
        "targetId": uuid_map[edge.get('targetId')],
        "name": get_edge_name_by_type(edge.get('type', ''), edge_define)
    }


def transform_data(source_data, node_define, edge_define):
    """将skill生成的数据转换为接口调用格式"""
    result = {
        "name": source_data.get('name', ''),
        "metaPaperId": ENV_CONFIG[env]["metaPaperId"],
        "appSource": "agentos_code",
        "nodes": [],
        "edges": []
    }
    uuid_map = {}
    # 转换节点
    for node in source_data.get('nodes', []):
        result["nodes"].append(transform_node(node, node_define, uuid_map))

    # 转换边
    for edge in source_data.get('edges', []):
        result["edges"].append(transform_edge(edge, edge_define,uuid_map))

    return result


def submit_data(name, file_path):
    # 计算项目根目录 (根据脚本位置反推：.claude/skills/generate-ai-code-data/scripts -> root)
    project_root = os.path.abspath(os.path.join(SKILL_DIR, '..', '..', '..'))

    # 1. 首先检查路径是否存在（绝对路径 或 相对于当前执行目录）
    if not os.path.exists(file_path):
        # 2. 如果找不到，尝试去项目根目录查找
        possible_path_in_root = os.path.join(project_root, file_path)
        if os.path.exists(possible_path_in_root):
            file_path = possible_path_in_root
        else:
            # 3. 如果还找不到，尝试去脚本所在目录查找
            possible_path_in_script = os.path.join(SCRIPT_DIR, file_path)
            if os.path.exists(possible_path_in_script):
                file_path = possible_path_in_script

    # 最终检查
    # 在项目根目录下查找指定文件
    if not os.path.exists(file_path):
        print(f"未找到'{file_path}'文件，请先生成'{name}'的子图数据文件，然后再进行提交！")
        return None

    # 读取源数据文件
    source_data = load_json_file(file_path)

    # 加载节点和边定义
    node_define = load_json_file(NODE_DEFINE_PATH)
    edge_define = load_json_file(EDGE_DEFINE_PATH)

    # 数据转换
    transformed_data = transform_data(source_data, node_define, edge_define)

    paper_id = call_data_twin(transformed_data)
    if paper_id is not None:
        print(f"'{name}' ai-code子图数据的子图ID是: {paper_id}")
        graph_data = load_json_file(file_path)
        graph_data["paperId"] = paper_id
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(graph_data, f, indent=4, ensure_ascii=False)
        return paper_id
    else:
        print(f"'{name}' ai-code子图数据的子图ID获取失败")
        return None

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description='AI CODE子图数据提交工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f"""
    示例:
      python3 submit_ai_code_data.py --name 学生管理系统后台 --file ai-code-student-mgt-api.json
    """
    )
    parser.add_argument(
        '--name',
        help='ai code子图中文名称'
    )
    parser.add_argument(
        '--file',
        help='ai code子图数据文件路径'
    )
    args = parser.parse_args()
    submit_data(args.name, args.file)
