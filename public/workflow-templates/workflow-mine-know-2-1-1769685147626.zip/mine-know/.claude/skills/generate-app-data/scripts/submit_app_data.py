#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import os
import uuid

import requests

env = os.getenv('ENV', 'fat').lower()

ENV_CONFIG = {
    "dev": {
        "url": "https://dt-biz-base.dev.ennew.com",
        "access_key": "",
        "metaPaperId": 13915
    },
    "fat": {
        "url": "https://rdfa-gateway.fat.ennew.com/dt-biz-base",
        "access_key": "Ksjt8LZgr7dgeBVQhkbS6pNYvdMS51R4",
        "metaPaperId": 13915
    },
    "uat": {
        "url": "https://rdfa-gateway.uat.ennew.com/dt-biz-base",
        "access_key": "TsKwADFuHBGYXdfUVi4t7A2fckOLReH8",
        "metaPaperId": 13915
    },
    "prod": {
        "url": "https://rdfa-gateway.ennew.com/dt-biz-base",
        "access_key": "9GeND2MF703TwYh3XQj1crMlz3Yp4eYi",
        "metaPaperId": 13915
    }
}

def call_data_twin(data):
    try:
        response = requests.post(
            url=f'{ENV_CONFIG[env]["url"]}/api/aiModel/meta/generateSubMetaModel',
            json=data,
            headers={
                "Content-Type": "application/json",
                "x-gw-accesskey": ENV_CONFIG[env]["access_key"]
            }
        )
        response_data = response.json()
        if response_data.get("code", "") != "0":
            raise Exception(response_data.get("message", "未知错误"))
        return response_data.get("data").get("paperId")
    except Exception as e:
        print(f"提交数据失败: {str(e)}")
        return None

# 加载定义文件
def load_json_file(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"文件 {filepath} 不存在")
        return None


# 通过type获取node定义的name
def get_node_name_by_type(node_define, node_type):
    for node in node_define:
        if node['type'] == node_type:
            return node['name']
    return None


# 通过type获取node定义的scene
def get_node_scene_by_type(node_define, node_type):
    for node in node_define:
        if node['type'] == node_type:
            return node['scene']
    return None


# 通过type获取edge定义的name
def get_edge_name_by_type(edge_define, edge_type):
    for edge in edge_define:
        if edge['type'] == edge_type:
            return edge['name']
    return None

# 转换节点数据
def transform_nodes(nodes, node_define):
    transformed_nodes = []
    node_uuid_map = {}

    for node in nodes:
        generated_uuid = uuid.uuid4().hex
        node_uuid_map[node.get("id")] = generated_uuid

        # 获取节点类型对应的domainName (name字段)
        node_type = node.get('type', '')
        domain_name = get_node_name_by_type(node_define, node_type)

        # 获取节点类型对应的nodeType (scene字段)
        node_type_scene = get_node_scene_by_type(node_define, node_type)

        # 构建基础转换后的节点
        transformed_node = {
            'uuid': generated_uuid,
            'name': node.get('name', ''),
            'domainName': domain_name if domain_name else '',
            'nodeType': node_type_scene if node_type_scene else 'common'
        }

        # 处理description
        if 'description' in node:
            transformed_node['description'] = node['description']
        else:
            transformed_node['description'] = ''

        # 特殊处理：如果nodeType是paper，添加childPaperId
        if transformed_node['nodeType'] == 'paper':
            transformed_node['childPaperId'] = node.get('paperId')
            # paper类型节点只需要这3个字段，不需要properties
            transformed_nodes.append(transformed_node)
            continue

        # 特殊处理：如果nodeType是logic，添加logicType字段并赋值为function
        if transformed_node['nodeType'] == 'logic':
            transformed_node['logicType'] = 'function'

        # 处理properties映射：name -> modelFieldName, dataType -> modelFieldDataType, code -> modelFieldCode
        if 'properties' in node and node['properties']:
            transformed_properties = []
            for prop in node['properties']:
                transformed_prop = {}
                # 映射规则
                if 'name' in prop:
                    transformed_prop['modelFieldName'] = prop['name']
                if 'dataType' in prop:
                    transformed_prop['modelFieldDataType'] = prop['dataType']
                if 'code' in prop:
                    transformed_prop['modelFieldCode'] = prop['code']
                if 'value' in prop:
                    prop_value = prop['value']
                    if isinstance(prop_value, list) or isinstance(prop_value, dict):
                        prop_value = json.dumps(prop_value, ensure_ascii=False)
                    transformed_prop['modelFieldDefaultValue'] = prop_value
                transformed_properties.append(transformed_prop)
            transformed_node['properties'] = transformed_properties
        else:
            transformed_node['properties'] = []

        transformed_nodes.append(transformed_node)

    return transformed_nodes, node_uuid_map


# 转换边数据
def transform_edges(edges, edge_define, node_uuid_map):
    transformed_edges = []

    for edge in edges:
        edge_type = edge.get('type', '')
        edge_name = get_edge_name_by_type(edge_define, edge_type)

        transformed_edge = {
            'sourceId': node_uuid_map[edge.get('sourceId', '')],
            'targetId': node_uuid_map[edge.get('targetId', '')],
            'name': edge_name if edge_name else ''
        }

        transformed_edges.append(transformed_edge)

    return transformed_edges


# 主转换函数
def convert_app_to_data():
    # 获取脚本所在目录
    SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
    SKILL_DIR = os.path.dirname(SCRIPT_DIR)

    # 定义文件路径
    node_define_path = os.path.join(SKILL_DIR, 'references', 'node-define.json')
    edge_define_path = os.path.join(SKILL_DIR, 'references', 'edge-define.json')

    # 检查app.json是否存在
    if not os.path.exists("app.json"):
        print("未找到app.json文件，请先生成应用图数据文件，然后再进行提交！")
        return None

    # 读取JSON文件
    app_data = load_json_file("app.json")
    node_define = load_json_file(node_define_path)
    edge_define = load_json_file(edge_define_path)

    if not app_data or not node_define or not edge_define:
        print("读取文件失败")
        return None

    # 转换节点数据
    transformed_nodes, node_uuid_map = transform_nodes(
        app_data.get('nodes', []),
        node_define
    )

    # 转换边数据
    transformed_edges = transform_edges(
        app_data.get('edges', []),
        edge_define,
        node_uuid_map
    )

    # 构建最终数据
    result = {
        'name': app_data.get('name', ''),
        'metaPaperId': ENV_CONFIG[env]["metaPaperId"],
        'appSource': "agentos_app",
        'nodes': transformed_nodes,
        'edges': transformed_edges
    }

    return call_data_twin(result)

def submit_data():
    # 执行转换
    graph_id = convert_app_to_data()

    if graph_id:
        print(f"应用图数据的图ID是: {graph_id}")
        graph_data = load_json_file("app.json")
        graph_data["paperId"] = graph_id
        with open("app.json", 'w', encoding='utf-8') as f:
            json.dump(graph_data, f, indent=4, ensure_ascii=False)
    else:
        print("应用图数据的图ID获取失败")

    return graph_id

if __name__ == "__main__":
    submit_data()
