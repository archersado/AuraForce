# TODO: Enterprise Architect AI

Development roadmap for enterprise-architect module.

---

## Agents to Build

- [ ] **Arthur (domain-consultant)** — Domain Consultant
  - Use: `bmad:bmb:agents:agent-builder`
  - Spec: `agents/domain-consultant.spec.md`
  - Key features: 场景引导、行业识别、主动建议、模型精炼、验证闭环

- [ ] **Claude (design-coordinator)** — Design Coordinator
  - Use: `bmad:bmb:agents:agent-builder`
  - Spec: `agents/design-coordinator.spec.md`
  - Key features: 技能协调、文档生成管理、一致性检查、状态报告

---

## Workflows to Build

- [ ] **End-to-End Product Design** (end-to-end-design)
  - Use: `bmad:bmb:workflows:workflow` or `/workflow`
  - Spec: `workflows/end-to-end-design/end-to-end-design.spec.md`
  - Key features: 4个阶段（Discovery、Refinement、Documentation、Validation）、回溯机制

---

## Skills to Build

基于现有 skills 创建增强版：

- [ ] **domain-prd-generator** — 增强版 PRD 生成器
  - Use: `.claude/skills/skill-creator`
  - 参考: `.claude/skills/prd-generator/SKILL.md`
  - 增强：与企业级标准对齐、用户故事集成、业务规则提取

- [ ] **interaction-mapper** — 交互映射生成器（新建）
  - Use: `.claude/skills/skill-creator`
  - 参考: `.claude/skills/user-story-mapping/SKILL.md`
  - 功能：生成用户旅途与交互说明文档、双视角格式

- [ ] **domain-arch-designer** — 增强版架构设计器
  - Use: `.claude/skills/skill-creator`
  - 参考: `.claude/skills/architecture-designer/SKILL.md`
  - 增强：分离交互部分、增强业务对象建模、TOGAF/4A 兼容

---

## Industry Plugin Development

- [ ] **Energy Industry Plugin** （能源行业插件）
  - 目录: `domain-templates/energy/`
  - 文件:
    - [ ] `concepts.md` — 核心概念词典（电厂、储能站、调度、SOC、并网等）
    - [ ] `patterns.md` — 典型业务模式（微电网运行、储能充放电调度）
    - [ ] `entity-templates.md` — 预定义对象模板
    - [ ] `business-rules.md` — 行业典型规则（SOC 控制规则、并网安全约束）

---

## MCP Integration

需要集成以下 MCP 服务（后续提供）：

- [ ] **知识库查询** — 查询行业知识库
- [ ] **知识记录** — 实时记录对话中学习到的新概念
- [ ] **对话分析** — 挖掘历史对话中的知识

**存储策略：**
- 优先：图数据库（通过 MCP 集成）
- 后备：文件系统（JSON/YAML）

---

## Installation Testing

- [ ] Test installation with `bmad install enterprise-architect`
- [ ] Verify module.yaml works with core configuration
- [ ] Test agent access via menu
- [ ] Test workflow execution

---

## Documentation

- [x] README.md with module overview and navigation
- [ ] Enhance docs/ folder with more guides
- [ ] Add troubleshooting section
- [ ] Document configuration options
- [ ] Create user examples for common scenarios

---

## Integration Testing

- [ ] Test agent-to-agent collaboration (Arthur → Claude → Arthur)
- [ ] Test workflow backtracking mechanism
- [ ] Test skills coordination sequence
- [ ] Test MCP integration (when available)

---

## Next Steps

1. Build agents using create-agent workflow
2. Build workflows using create-workflow workflow
3. Build skills using skill-creator
4. Develop energy industry plugin
5. Integrate MCP services
6. Test installation and functionality
7. Iterate based on testing

---

_Last updated: 2026-01-26_
