---
name: user-story-mapping
description: "Jeff Patton's User Story Mapping technique. ⚠️ CRITICAL: IMMEDIATELY execute without waiting: 0) Read template file ./.claude/skills/user-story-mapping/references/requirement_template.md FIRST 1) IMMEDIATELY use AskUserQuestion ask 3 questions in order (核心业务流程→用户群体→核心价值) 2) After answers, show doc structure 3) Use Bash echo to append to 产品需求.md 4) After each section, IMMEDIATELY output progress 5) 🔴🔴🔴 MUST use ONLY 4 sections: # 产品定义, # 用户旅程, # 功能清单, # 核心功能说明 (NO numbering like 1. 2. 3., NO extra sections like 产品概述/用户画像/非功能需求) 6) PROHIBIT Write tool one-time write 7) PROHIBIT generate all then write 8)🔴 After doc complete, IMMEDIATELY use AskUserQuestion ask if continue stage2 9) After confirmation, call architecture-designer skill. ⚠️ All user interactions MUST use AskUserQuestion, NO conversational text."
allowed-tools: Read, Write, Glob, Grep, Task, AskUserQuestion, Bash, Skill
keywords:
  - 需求分析
  - 用户故事
  - 故事地图
  - 用户旅程
  - MVP
  - 产品规划
  - 功能优先级
  - 用户场景
---

# 🔴🔴🔴 文档结构铁律(绝对不能违反！) 🔴🔴🔴

## 📋 必须严格遵循的4个部分(不得增加、减少或改变！)

**⚠️⚠️⚠️ 这是最重要的规则！生成文档时必须严格按照以下结构，一个字都不能错！**

### ✅ 正确的文档结构(必须使用)

```markdown
# 产品定义

## 背景

[基于用户第1个问题的详细回答生成内容]

## 产品定位

[基于用户第2个问题的回答生成内容]

## 核心业务逻辑

[⚠️ 最关键 - 完整保留并展开用户提供的详细业务流程步骤]

## 目标用户

[基于用户第2个问题的回答生成内容]

# 用户旅程

### 旅程1：[场景名称]

步骤1：[基于用户第1个问题的详细流程步骤生成]
步骤2：[基于用户第1个问题的详细流程步骤生成]
步骤3：[基于用户第1个问题的详细流程步骤生成]
...

# 功能清单

| 功能名称 | 功能描述                     | 优先级 | 依赖关系说明 | 备注   |
| -------- | ---------------------------- | ------ | ------------ | ------ |
| [功能1]  | [基于用户业务流程提取的功能] | P0     | [依赖]       | [备注] |
| [功能2]  | [基于用户业务流程提取的功能] | P1     | [依赖]       | [备注] |

# 核心功能说明

## [功能名称1]

### 功能详细描述

[详细描述功能流程和逻辑，包括各种判断条件和分支情况]

### 输入输出

**输入条件：**

- [具体字段和类型]
- [具体字段和类型]

**输出结果：**

- [具体字段和类型]
- [具体字段和类型]

### 业务逻辑

[⚠️⚠️⚠️ 最关键 - 详细的步骤、规则、算法]

步骤1：[具体操作和逻辑]
步骤2：[具体操作和逻辑]
步骤3：[具体操作和逻辑]
...

### 界面交互说明

[简洁的界面描述，包含主要区域和操作]
```

### 🔴 再次强调

**生成文档时，必须：**

1. ✅ 只使用4个一级标题：`# 产品定义`、`# 用户旅程`、`# 功能清单`、`# 核心功能说明`
2. ✅ 不添加任何额外章节(如非功能需求、技术架构等)
3. ✅ 严格按照上面"正确的文档结构"生成

**如果生成的文档不符合上述结构，视为严重错误！**

---

# 🔴🔴🔴 CRITICAL - 禁止行为(绝对不能违反！) 🔴🔴🔴

## 🚨🚨🚨 最关键的禁止规则(必须遵守！)

### ❌ 文档生成方面的禁止

- ❌ **绝对禁止** 使用 `Write` 工具一次性写入整个产品需求.md文件
- ❌ **绝对禁止** 先生成所有内容再写入文件
- ❌ **绝对禁止** 使用产品名称作为文件名前缀,文件名必须是 `产品需求.md`
- ❌ **绝对禁止** 在生成过程中不输出进度提示
- ❌ **绝对禁止** 不分段直接写入完整内容

### ❌ 问题提问方面的禁止

- ❌ **绝对禁止** 使用普通对话向用户提问(必须使用AskUserQuestion工具)
- ❌ **绝对禁止** 问超过3个问题
- ❌ **绝对禁止** 在问题之间说任何话(如"好的"、"下一个问题")
- ❌ **绝对禁止** 收集完3个答案后继续追问
- ❌ **绝对禁止** 跳过第1个问题(核心业务流程)

### ❌ 文档结构方面的禁止

- ❌ **绝对禁止** 使用模板 `./.claude/skills/user-story-mapping/references/requirement_template.md` 之外的任何结构
- ❌ **绝对禁止** 生成超过4个章节的文档
- ❌ **绝对禁止** 添加模板要求之外的内容(如技术架构、数据模型、发布计划等)

## ✅ 必须执行的行为

### ⚡ 执行流程步骤

1. ✅ 技能启动后 **立即**(≤0.1秒) 使用 AskUserQuestion 问第1个问题
2. ✅ 收到第1题答案后 **立即** 问第2个问题,不说任何话
3. ✅ 收到第2题答案后 **立即** 问第3个问题,不说任何话
4. ✅ 收到第3题答案后 **立即** 显示文档结构预告
5. ✅ 使用 `Bash` 工具的 `echo >> 产品需求.md` 命令追加写入
6. ✅ 每生成一个部分, **立即** 输出进度提示
7. ✅ 所有部分完成后,显示完成总结
8. ✅ **🔴🔴🔴 CRITICAL - 显示完成总结后,立即使用 AskUserQuestion 询问用户是否继续阶段2 🔴🔴🔴**
9. ✅ 根据用户选择执行:继续生成详细设计 或 仅查看需求文档

### ⚡ 必须使用的工具

- ✅ 提问: 必须使用 `AskUserQuestion` 工具
- ✅ 写文件: 必须使用 `Bash` 工具的 `echo >> 产品需求.md` 命令
- ✅ 清空文件: 必须使用 `Bash` 工具的 `> 产品需求.md` 命令

### ⚡ 必须遵循的结构

- ✅ 文件名必须严格为: `产品需求.md`
- ✅ 文档结构必须为4个部分:
  1. 产品定义(背景、定位、核心业务逻辑、目标用户)
  2. 用户旅程
  3. 功能清单(表格格式)
  4. 核心功能说明(最关键,包含详细业务逻辑)

---

# 🔴🔴🔴 CRITICAL - 3个问题的固定顺序(绝对不能改变！) 🔴🔴🔴

```
┌─────────────────────────────────────────────────────────┐
│  问题1: 核心业务流程 (必须先问这个!)                       │
│  question: "请描述核心业务流程：用户输入什么              │
│             → 系统如何智能处理 → 输出什么结果"           │
└─────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────┐
│  问题2: 主要用户群体                                       │
│  question: "这个能力主要服务哪些用户群体?                 │
│             他们在什么业务场景下使用?"                    │
└─────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────┐
│  问题3: 核心价值                                         │
│  question: "相比现有方式,这个智能能力带来的               │
│             核心价值是什么?"                             │
└─────────────────────────────────────────────────────────┘
                         ↓
              立即生成产品需求文档
```

🚨 **严格遵守顺序:** 必须按 Q1 → Q2 → Q3 的顺序提问,不得跳过或改变!

---

# 🔴🔴🔴 CRITICAL - 当此skill启动时，立即使用AskUserQuestion按顺序问以下3个问题，没有任何延迟！🔴🔴🔴

## ⚡ 执行流程（必须立即执行，不等待任何输入）

### 🚨 第1个问题：核心业务流程（必须先问这个问题）

**问题固定，选项需要根据应用的AI能力类型动态生成**

```
tool: AskUserQuestion
parameters:
  questions:
    - question: "请描述核心业务流程：用户输入什么 → 系统如何智能处理 → 输出什么结果"
      header: "核心业务流程"
      multiSelect: false
      options:
        # ⚠️ 动态生成选项规则：
        # 1. 从用户输入的应用名称和要求中识别AI能力类型
        # 2. 根据识别的能力生成1-2个典型业务流程示例
        # 3. 始终保留"自定义详细说明"作为最后一个选项

        # 示例选项（根据应用类型动态调整）：
        - label: "需求分析场景"
          description: "输入客户信息 → AI识别需求特征 → 智能匹配解决方案 → 输出推荐报告"
        - label: "决策辅助场景"
          description: "提交业务数据 → AI评估多种因素 → 计算最优决策建议 → 输出决策依据"
        - label: "数据处理场景"
          description: "上传原始数据 → AI自动化处理分析 → 生成结构化结果 → 可视化展示"
        - label: "自定义详细说明"
          description: "我会完整描述我的业务流程细节"
```

**🔥 注意：** 必须先问第1个问题（核心业务流程），这是最重要的信息！

### 第2个问题：主要用户群体

```
tool: AskUserQuestion
parameters:
  questions:
    - question: "这个能力主要服务哪些用户群体?他们在什么业务场景下使用?"
      header: "用户与场景"
      multiSelect: false
      options:
        - label: "客户经理"
          description: "负责客户关系维护，需要快速了解客户需求并制定方案"
        - label: "销售代表"
          description: "负责客户开发和成单，需要线索筛选和跟进辅助"
        - label: "市场运营"
          description: "负责市场推广和用户增长，需要数据分析和策略支持"
        - label: "其他角色"
          description: "我会说明具体的用户群体和使用场景"
```

**🚨 执行要求：**

- 收到第1个问题答案后立即问第2个问题
- 不要说"好的"、"下一个问题"等任何文字

### 第3个问题：核心价值

```
tool: AskUserQuestion
parameters:
  questions:
    - question: "相比现有方式，这个智能能力带来的核心价值是什么?"
      header: "核心价值"
      multiSelect: false
      options:
        - label: "大幅提效"
          description: "从小时级缩短到分钟级，工作效率提升5-10倍"
        - label: "质量提升"
          description: "减少人为错误，提升分析的准确性和专业性"
        - label: "成本降低"
          description: "替代或减少专家人工投入，显著降低运营成本"
        - label: "能力创新"
          description: "实现传统方式无法做到的深度分析和智能决策"
```

**🚨 执行要求：**

- 收到第2个问题答案后立即问第3个问题
- 不要说"好的"、"最后一个问题"等任何文字

### 第4步：收到第3个问题答案后，立即生成文档 ⚠️⚠️⚠️ CRITICAL 🔴🔴🔴

**🔴🔴🔴 文档生成必须遵循以下流程(按顺序执行,不得跳步！): 📍🔴🔴🔴**

**第0步：读取模版文件(必须先执行！)** 🔴🔴🔴

⚠️ **这是最关键的一步！必须先读取模版文件，确保生成的文档结构完全符合模版要求！**

```
使用 Read 工具读取模版文件:
file_path: .claude/skills/user-story-mapping/references/requirement_template.md
```

**读取完成后，立即输出确认信息:**

```
✓ 已读取模版文件
✓ 文档将严格按照以下4个部分生成:
  1. # 产品定义
  2. # 用户旅程
  3. # 功能清单
  4. # 核心功能说明
```

**🚨 重要提醒:**

- ❌ 不使用数字编号(如 1. 2. 3.)
- ❌ 不添加"产品概述"、"用户画像"、"非功能需求"等额外章节
- ✅ 只生成4个一级标题,严格按照模版结构

---

**第1步：立即显示文档结构预告**

```
📍 正在生成产品需求文档...

📋 文档结构将包含:
1. 产品定义(背景、定位、核心业务逻辑、目标用户)
2. 用户旅程
3. 功能清单
4. 核心功能说明

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

准备开始生成,每完成一个部分会立即提示...
```

**第2步：使用Bash清空文件**

```
> 产品需求.md
```

**第3步：生成第1部分(产品定义),立即追加写入并输出提示**

⚠️ **注意**: 必须使用 Bash 工具的 echo 命令,禁止使用 Write 工具！

```bash
echo '# 产品定义' >> 产品需求.md
echo '' >> 产品需求.md
echo '## 背景' >> 产品需求.md
echo '[基于用户第1个问题的详细回答生成内容]' >> 产品需求.md
echo '' >> 产品需求.md
echo '## 产品定位' >> 产品需求.md
echo '[基于用户第2个问题的回答生成内容]' >> 产品需求.md
echo '' >> 产品需求.md
echo '## 核心业务逻辑' >> 产品需求.md
echo '[⚠️ 最关键 - 完整保留并展开用户提供的详细业务流程步骤]' >> 产品需求.md
echo '' >> 产品需求.md
echo '## 目标用户' >> 产品需求.md
echo '[基于用户第2个问题的回答生成内容]' >> 产品需求.md
```

**然后立即输出提示:**

```
✓ 产品定义部分已生成
```

**第4步：生成第2部分(用户旅程),立即追加写入并输出提示**

```bash
echo '' >> 产品需求.md
echo '# 用户旅程' >> 产品需求.md
echo '' >> 产品需求.md
echo '### 旅程1：[场景名称]' >> 产品需求.md
echo '步骤1：[基于用户第1个问题的详细流程步骤生成]' >> 产品需求.md
echo '步骤2：[基于用户第1个问题的详细流程步骤生成]' >> 产品需求.md
echo '...' >> 产品需求.md
```

**然后立即输出提示:**

```
✓ 用户旅程部分已生成,开始生成功能清单
```

**第5步：生成第3部分(功能清单),立即追加写入并输出提示**

```bash
echo '' >> 产品需求.md
echo '# 功能清单' >> 产品需求.md
echo '' >> 产品需求.md
echo '| 功能名称 | 功能描述 | 优先级 | 依赖关系说明 | 备注 |' >> 产品需求.md
echo '| -------- | -------- | ------ | ------------ | ---- |' >> 产品需求.md
echo '| [功能1]  | [基于用户业务流程提取的功能] | P0 | [依赖] | [备注] |' >> 产品需求.md
echo '| [功能2]  | [基于用户业务流程提取的功能] | P1 | [依赖] | [备注] |' >> 产品需求.md
```

**然后立即输出提示:**

```
✓ 功能清单部分已生成,开始生成核心功能说明
```

**第6步：生成第4部分(核心功能说明),立即追加写入并输出提示**

```bash
echo '' >> 产品需求.md
echo '# 核心功能说明' >> 产品需求.md
echo '' >> 产品需求.md
echo '## [功能名称1]' >> 产品需求.md
echo '' >> 产品需求.md
echo '### 功能详细描述' >> 产品需求.md
echo '[详细描述功能流程和逻辑]' >> 产品需求.md
echo '' >> 产品需求.md
echo '### 输入输出' >> 产品需求.md
echo '- 输入条件：' >> 产品需求.md
echo '  - [具体字段和类型]' >> 产品需求.md
echo '- 输出结果：' >> 产品需求.md
echo '  - [具体字段和类型]' >> 产品需求.md
echo '' >> 产品需求.md
echo '### 业务逻辑' >> 产品需求.md
echo '[⚠️⚠️⚠️ 最关键 - 详细的步骤、规则、算法]' >> 产品需求.md
echo '步骤1：[具体操作和逻辑]' >> 产品需求.md
echo '步骤2：[具体操作和逻辑]' >> 产品需求.md
echo '...' >> 产品需求.md
echo '' >> 产品需求.md
echo '### 界面交互说明' >> 产品需求.md
echo '[简洁的界面描述,包含主要区域和操作]' >> 产品需求.md
echo '' >> 产品需求.md
echo '## [功能名称2]' >> 产品需求.md
echo '[重复上述结构]' >> 产品需求.md
```

**然后立即输出提示:**

```
✓ 核心功能说明部分已生成
```

**第6.5步：验证文档结构(必须执行！)** 🔴🔴🔴

⚠️ **这是质量保证的关键步骤！必须验证生成的文档是否符合模版要求！**

```
使用 Grep 工具验证文档结构:
pattern: "^# "
file_path: 产品需求.md
output_mode: content
```

**验证规则:**

1. ✅ 必须包含且仅包含4个一级标题(以 `# ` 开头)
2. ✅ 第1个一级标题必须是: `# 产品定义`
3. ✅ 第2个一级标题必须是: `# 用户旅程`
4. ✅ 第3个一级标题必须是: `# 功能清单`
5. ✅ 第4个一级标题必须是: `# 核心功能说明`
6. ❌ 不能包含: `# 产品概述`、`# 用户画像`、`# 非功能需求`、`# 技术架构` 等其他一级标题

**如果验证失败:**

```
🚨 错误：文档结构不符合模版要求！
检测到的一级标题：[列出所有一级标题]
期望的一级标题：
  1. # 产品定义
  2. # 用户旅程
  3. # 功能清单
  4. # 核心功能说明

请立即修正文档结构！
```

**如果验证通过:**

```
✓ 文档结构验证通过
✓ 确认包含4个一级标题，符合模版要求
```

---

**第7步：显示完成总结**

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ 产品需求文档生成完成！

📄 文档：产品需求.md

📊 内容摘要：
• 产品定义：包含背景、产品定位、核心业务逻辑、目标用户
• 用户旅程：[X]个完整使用流程
• 功能清单：[X]个功能(P0: [X]个, P1: [X]个, P2: [X]个)
• 核心功能说明：[X]个核心功能详细说明

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎉 文档已保存到硬盘,您可以随时查看！
```

**第8步：询问用户是否继续阶段2（等待用户确认） ⚠️⚠️⚠️ CRITICAL 🔴🔴🔴**

**🔴🔴🔴 CRITICAL - 文档生成完成后,必须立即使用 AskUserQuestion 工具询问用户是否继续阶段2,不得直接结束！ 🔴🔴🔴**

```
tool: AskUserQuestion
parameters:
  questions:
    - question: "产品需求文档已生成完成！请选择接下来的操作："
      header: "下一步操作"
      multiSelect: false
      options:
        - label: "继续生成详细设计"
          description: "基于产品需求文档生成系统架构和详细设计文档"
        - label: "仅查看需求文档"
          description: "暂时不生成详细设计,稍后手动启动"
```

**🚨 执行要求：**

- 显示完成总结后立即使用 AskUserQuestion 工具询问
- 不要说"请等待"、"下一步"等任何连接文字
- 严格使用上述格式的问题和选项

**第9步：根据用户选择执行** 🔴🔴🔴

- 如果用户选择"继续生成详细设计" → 使用 `Skill('architecture-designer')` 工具调用 architecture-designer skill
- 如果用户选择"仅查看需求文档" → 显示提示信息,结束流程

---

**🔴🔴🔴 再次强调 CRITICAL 规则: 🔴🔴🔴**

**关于命令工具的使用:**

- ✅ **必须使用 Bash 工具执行**: `echo '内容' >> 产品需求.md`
- ❌ **绝对禁止使用 Write 工具写入文件**
- ✅ **必须使用 Bash 工具清空**: `> 产品需求.md`

**关于执行顺序:**

- ✅ **必须按照第1步→第2步→...→第8步的顺序执行**
- ✅ **每完成一个步骤,立即输出进度提示**
- ❌ **绝对禁止跳过任何步骤**
- ❌ **绝对禁止在生成过程中不输出提示**

**关于文档内容:**

- ✅ **必须基于用户在 AskUserQuestion 中提供的详细答案生成**
- ❌ **绝对禁止使用模板的简单示例**
- ✅ **必须完整保留用户提供的业务规则、推导规则等详细内容**

---

**⚠️⚠️⚠️ CRITICAL - 文档内容必须基于用户在 AskUserQuestion 中提供的详细答案生成，而不是使用模板的简单示例！** 🔴🔴🔴

**生成逻辑与输出格式**:

**整体结构**：严格遵循 `./.claude/skills/user-story-mapping/references/requirement_template.md` 模板，包含以下章节：

1. 产品定义（背景、定位、核心业务逻辑、目标用户）
2. 用户旅程
3. 功能清单（表格格式）
4. 核心功能说明

---

## 📋 各章节生成规则

### 5. 补充说明部分

⚠️ **已删除**：此章节已从文档结构中移除，不再生成。

### 1. 产品定义部分

- **背景**: 基于用户对第1个问题(核心业务流程)的详细回答，描述产品产生的背景和痛点
- **产品定位**: 基于用户对第2个问题(用户群体)的回答，描述产品是什么、面向谁、主要用途
- **核心业务逻辑**: ⚠️ **最关键** - 完整保留并展开用户提供的详细业务流程步骤，包括：
  - 用户提到的每一步流程
  - 用户提供的所有规则、算法、判断逻辑
  - 用户提供的排序规则、匹配规则、推导规则等
- **目标用户**: 引用用户指定的用户群体和使用场景

### 2. 用户旅程部分

- 如果用户在第1个问题中提供了详细的业务流程步骤(如需智的3个步骤)，**完整保留并展开这些步骤**
- 每个步骤都要包含用户描述的具体内容
- 不要缩减或简化用户的详细描述
- 以"步骤1、步骤2..."的形式清晰呈现

### 3. 功能清单部分

- 根据用户的业务流程步骤，提取对应的功能
- 每个功能的描述要基于用户的具体业务场景
- 表格包含：功能名称、功能描述、优先级(P0/P1/P2)、依赖关系说明、备注

### 4. 核心功能说明部分 ⚠️ 最关键

这是文档质量的关键！必须包含以下结构：

#### 4.1 功能详细描述

- 详细描述该功能的完整流程和逻辑，包括各种判断条件和分支情况
- 要具体到每个步骤做什么，遇到什么情况如何处理

#### 4.2 输入输出

**格式示例**：

```
输入条件：
- 客户需求名称（字符串，不超过20字）
- 需求描述（字符串，客户视角的生产经营痛点）
- 推荐理由（字符串，分析客户生产工艺后的需求推导）
- 客户所属行业（字符串）

输出结果：
- 排序后的需求列表（数组，包含需求名称、需求描述、推荐理由、相似案例）
- 相似案例链接（字符串）
```

#### 4.3 业务逻辑 ⚠️⚠️⚠️ **这是最关键的部分**

**格式要求**：

- 必须以步骤形式呈现（步骤1、步骤2、步骤3...）
- 每个步骤要描述具体的操作、判断逻辑、算法规则
- **如果用户在回答中提供了详细的业务规则、需求推导规则、排序规则等内容，必须完整写入**

**高质量示例**（基于需智用户提供的详细规则）：

```
业务逻辑：

步骤1：需求提取和解析
- 判断客户输入是否包含明确的需求内容
- 提取客户主观意愿中的核心痛点关键词
- 如果客户输入不完整，提示客户补充必要信息

步骤2：规则匹配和推导
- 应用规则1：分析客户主观意图，提取核心痛点
- 应用规则2：在专家沉淀的规则库中进行模糊匹配，找出相关推导规则
- 应用规则3：根据客户所在地和行业，联网搜索政府网站（如发改委、环保局等），提取强制性政策要求，生成新增需求（标注"AI生成"）
- 应用规则4：联网搜索行业资讯网站（如行业门户网站、专业论坛等），提取热门项目关键词，推导潜在需求（标注"AI生成"）
- 对比新增需求与已推荐需求，过滤重复项

步骤3：需求优先级排序
- 识别客户主观意图表达强烈的需求：通过关键词匹配（如"必须"、"急"、"痛点"等）和需求描述的详细程度判断
- 识别已有案例的需求：在案例知识库中按行业类别、需求类型进行匹配，命中则提升优先级
- 识别普适性问题需求：通过政策法规关键词（如"环保"、"补贴"、"合规"等）和联网搜索结果中的行业共性项目判断
- 按优先级1 > 优先级2 > 优先级3进行排序

步骤4：相似案例匹配
- 从案例知识库中筛选与客户行业类别相同的案例
- 在相同行业类别中，按需求类型进行二次筛选
- 在匹配的案例中，按价值贡献（如降本金额、增效比例等）从高到低排序
- 选择排名第一的案例作为相似案例推荐
- 提取案例信息：客户基本情况（企业类型、规模）、解决的痛点问题、大致解决方案、客户价值（用具体数字表达）

步骤5：调研报告生成
- 将需求诊断结果、相似案例推荐、排序结果整合成结构化报告
- 报告包含：需求列表（名称、描述、理由）、相似案例（基本情况、解决方案、价值）、优先级排序
```

**关键点**：

- 每个步骤都要有明确的操作逻辑
- 如果用户提供了具体的规则（如需智的4类需求推导规则、3类排序规则、相似案例推荐规则），必须完整写入
- 要描述具体的计算逻辑、判断条件、匹配算法
- 要包含兜底策略和异常处理

#### 4.4 界面交互说明

**格式示例**：

```
界面交互说明：

用户在"需求诊断"界面输入客户需求信息，点击"开始诊断"按钮后，系统显示"正在进行需求分析..."的提示。约5-10秒后，页面自动刷新，显示需求诊断结果：

- 需求列表以卡片形式展示，每个卡片包含需求名称、需求描述、推荐理由、相似案例摘要
- 卡片按优先级从高到低排序
- AI生成的需求标注"AI推荐"标签
- 每个需求卡片有"查看案例详情"按钮，点击后跳转到案例详情页
- 底部有"生成调研报告"按钮，点击后下载PDF格式的调研报告

界面包含以下部分：
1. 左侧区域：需求输入表单，包含需求名称、需求描述、推荐理由三个输入框
2. 右侧区域：需求诊断结果展示区
3. 顶部区域：客户基本信息展示（客户名称、所属行业、所在地）

支持的操作：
- 输入完成后点击"开始诊断"按钮
- 点击"重新诊断"按钮重新执行诊断流程
- 点击需求卡片上的"查看案例详情"查看案例完整信息
```

**关键点**：

- 描述界面布局（主要区域）
- 描述用户操作流程
- 描述系统反馈和提示
- **⚠️ 简洁描述，不要写过于详细的UI细节（颜色、动画、字体大小等）**

---

# 以下是详细的技术文档

## When to Use This Skill

**Keywords:** story map, user story map, backbone, walking skeleton, MVP, release planning, user journey, story slicing, Jeff Patton, Agile discovery

**Use this skill when:**

- Organizing elicited requirements into deliverable increments
- Defining MVP scope from a large set of requirements
- Visualizing the user journey across features
- Planning releases with clear user value
- Slicing large epics into shippable stories
- Communicating product vision to stakeholders

## Core Concepts

### The Map Structure

```text
TIME / USER JOURNEY →
─────────────────────────────────────────────────────────────────
BACKBONE (Activities)   │  Search   │  Browse   │  Purchase  │  Track
                        │           │           │            │
─────────────────────────────────────────────────────────────────
WALKING SKELETON        │  Basic    │  List     │  Cart +    │  Order
(Minimum Path)          │  Search   │  View     │  Checkout  │  Status
─────────────────────────────────────────────────────────────────
Release 1               │  Filters  │  Details  │  Payment   │  Email
                        │           │  Page     │  Options   │  Notify
─────────────────────────────────────────────────────────────────
Release 2               │  Saved    │  Compare  │  Wishlist  │  Tracking
                        │  Searches │  Items    │            │  Map
─────────────────────────────────────────────────────────────────
Release 3 (Nice-to-have)│  AI       │  AR       │  One-Click │  Delivery
                        │  Suggest  │  Preview  │  Buy       │  Photos
```

### Key Elements

| Element              | Description                                                      |
| -------------------- | ---------------------------------------------------------------- |
| **Backbone**         | High-level user activities in sequence (left-to-right = time)    |
| **Walking Skeleton** | Minimum functionality for each activity (first viable path)      |
| **User Tasks**       | Stories under each activity, ordered by priority (top-to-bottom) |
| **Release Slices**   | Horizontal lines grouping stories into releases                  |
| **Personas**         | Different user types may have different paths                    |

## Creating a Story Map

### Step 1: Define the Backbone

Identify high-level activities the user performs:

```yaml
backbone_questions:
  - "What does the user do first?"
  - "What happens next in their journey?"
  - "What are all the major activities?"
  - "Is there a natural sequence or flow?"
```

### Step 2: Identify the Walking Skeleton

For each backbone activity, what's the minimum viable implementation?

```yaml
walking_skeleton_criteria:
  - Enables the user to complete the activity (barely)
  - End-to-end slice through the system
  - Testable and demonstrable
  - Foundation for incremental enhancement
```

### Step 3: Fill in User Tasks

Under each activity, list user tasks/stories:

```yaml
task_placement:
  vertical_order: "Priority (most important at top)"
  horizontal_alignment: "Which activity does this belong to?"
  dependencies: "Does this need something from another column?"
```

### Step 4: Draw Release Slices

Group stories into releases with clear user value:

```yaml
release_criteria:
  release_1_mvp:
    - Walking skeleton + minimal enhancements
    - "What can we build and ship first?"
    - Validates core value proposition

  release_2:
    - Improves on MVP based on feedback
    - Adds important but not critical features

  future_releases:
    - Nice-to-have features
    - Competitive differentiation
    - Edge cases and polish
```

## Output Formats

### Mermaid Diagram (Default)

The `/story-map` command generates Mermaid flowcharts:

```mermaid
%%{init: {'theme': 'base', 'themeVariables': { 'primaryColor': '#e1f5fe'}}}%%
flowchart LR
    subgraph Backbone["User Journey (Backbone)"]
        A1[Search] --> A2[Browse] --> A3[Purchase] --> A4[Track]
    end

    subgraph R0["Walking Skeleton"]
        A1 --- S1[Basic Search]
        A2 --- S2[List View]
        A3 --- S3[Cart + Checkout]
        A4 --- S4[Order Status]
    end

    subgraph R1["Release 1"]
        S1 --- R1S1[Filters]
        S2 --- R1S2[Details Page]
        S3 --- R1S3[Payment Options]
        S4 --- R1S4[Email Notify]
    end
```

### YAML Export

```yaml
story_map:
  title: "E-commerce Platform"
  personas: ["shopper", "power-user"]

  backbone:
    - id: search
      name: "Search Products"
      walking_skeleton: "Basic keyword search"

    - id: browse
      name: "Browse Catalog"
      walking_skeleton: "List view with thumbnails"

  releases:
    - name: "MVP"
      stories:
        - activity: search
          stories: ["Basic Search", "Filters"]
        - activity: browse
          stories: ["List View", "Details Page"]
```

## Integration with Elicitation

### From Elicited Requirements

```text
1. Load synthesized requirements from /discover
2. Identify user activities from functional requirements
3. Map requirements to backbone activities
4. Prioritize within each activity
5. Slice into releases
```

### Workflow

```bash
# Elicit requirements first
/requirements-elicitation:discover "e-commerce platform"

# Create story map from requirements
/requirements-elicitation:story-map --domain "e-commerce"

# Export map to visualization
/requirements-elicitation:story-map --domain "e-commerce" --format mermaid
```

## Best Practices

### DO

- Include stakeholders in mapping sessions
- Keep backbone at 5-10 activities
- Make walking skeleton truly minimal
- Slice releases for user value, not technical convenience
- Revisit and update as you learn

### DON'T

- Over-detail the map initially
- Organize by technical layer (UI, API, DB)
- Skip the walking skeleton (it's the foundation)
- Make releases too large
- Treat the map as immutable

## Related Commands

- `/story-map` - Generate story maps from elicited requirements
- `/journey-map` - Customer journey visualization (complementary)
- `/discover` - Elicit requirements before mapping
- `/gaps` - Check for missing coverage

## References

**For detailed guidance:**

- [Mapping Techniques](references/mapping-techniques.md) - Detailed mapping workflows
- [Release Planning](references/release-planning.md) - Slicing strategies and MVP definition
- [Guided Approach](references/guided-approach.md) - Interactive questioning framework with smart analysis

**External:**

- Jeff Patton's "User Story Mapping" book
- [jpattonassociates.com](https://jpattonassociates.com)

## Version History

- v1.12.0 (2026-01-26): 🔴🔴🔴 CRITICAL 根本性修复 - 彻底解决文档结构不符合模版的问题
  - 🐛 **根本问题**: LLM 生成的文档使用了传统PRD结构(产品概述、用户画像、用户故事映射、功能需求、非功能需求等11个章节),而不是模版要求的4个部分
  - 🐛 **问题表现**: 生成的文档包含数字编号(1. 2. 3.)和错误的章节名称,完全不符合 requirement_template.md 的结构
  - ✅ **修复1**: 在文档开头(第16行后)添加"文档结构铁律"章节,用超级醒目的标记展示正确和错误的结构对比
  - ✅ **修复2**: 在执行流程中添加"第0步:读取模版文件",强制要求先读取 requirement_template.md
  - ✅ **修复3**: 在 description 中强化结构要求,明确列出4个一级标题,禁止使用数字编号和额外章节
  - ✅ **修复4**: 添加"第6.5步:验证文档结构",使用 Grep 工具验证生成的文档是否包含正确的4个一级标题
  - ✅ **修复5**: 提供详细的结构对比表格,清晰展示正确结构 vs 错误结构
  - 🔧 **核心原理**: 使用多层防护机制(开头铁律 + 读取模版 + description强化 + 结构验证),确保LLM无法忽略结构要求
  - 💡 **设计思路**: 将结构要求从文档中间提升到最开头,并用醒目的标记(🔴🔴🔴、❌、✅)强化视觉冲击力
  - 📊 **预期效果**: 生成的文档将严格包含4个一级标题(# 产品定义、# 用户旅程、# 功能清单、# 核心功能说明),不再出现错误结构
- v1.11.0 (2026-01-26): 🚨🚨🚨 CRITICAL 修复 - 添加阶段2调用机制,解决流程断点问题
  - 🐛 **根本问题**: 产品需求文档生成后直接结束,缺少暂停和用户确认,无法触发 architecture-designer skill
  - 🐛 **问题表现**: 生成产品需求.md 后流程终止,不符合 prd-generator 设计的两阶段流程
  - ✅ **修复1**: 在"第8步"后新增"第9步",使用 AskUserQuestion 询问用户是否继续生成详细设计
  - ✅ **修复2**: 新增"第10步",根据用户选择执行:调用 architecture-designer skill 或仅查看需求文档
  - ✅ **修复3**: 在 description 中添加第8和第9步的说明,强调文档完成后必须询问用户确认
  - ✅ **修复4**: 在"必须执行的行为"中更新步骤,从7步增加到9步(包含询问和调用步骤)
  - ✅ **修复5**: 在 allowed-tools 中添加 Skill 工具,支持调用 architecture-designer skill
  - 🔧 **核心原理**: 将 user-story-mapping 改为 prd-generator 流程的阶段1子技能,完成阶段1后必须等待确认
  - 💡 **设计思路**: 符合 prd-generator 的两阶段设计(需求→设计),确保流程完整可执行
- v1.10.0 (2026-01-26): 🚨🚨🚨 CRITICAL 根本性修复 - 解决文档生成和进度输出的严重Bug
  - 🐛 **Bug1**: 文档结构不符合模板,使用了常规PRD结构(11个章节)而非模板要求的5个章节
  - 🐛 **Bug2**: 未使用分段生成和进度提示,直接用 Write 工具一次性写入完整内容
  - 🐛 **Bug3**: allowed-tools 缺少 Bash 工具,无法执行 echo 命令
  - ✅ **修复1**: 在文档开头添加 🔴🔴🔴 禁止行为章节,明确禁止使用 Write 工具一次性写入
  - ✅ **修复2**: 在 description 中详细列出7个必须步骤,强调 Bash echo 命令分段写入
  - ✅ **修复3**: 将 allowed-tools 中的 Write 改为 Bash (Write 在禁止列表中,不应出现)
  - ✅ **修复4**: 重构"第4步"的执行流程,提供8个详细的 bash echo 命令示例
  - ✅ **修复5**: 在每一步之后明确要求"然后立即输出提示"
  - ✅ **修复6**: 添加"🔴🔴🔴 再次强调 CRITICAL 规则"章节,强化关键规则
  - 🔧 **核心原理**: 将分散的禁止规则和执行步骤整合到文档开头,确保执行者第一时间看到
  - 💡 **设计思路**: 使用多层防护机制(description + 开头禁止章节 + 执行流程示例 + 再次强调章节)
- v1.9.0 (2026-01-26): ⚡ 重大优化 - 分段生成和实时反馈机制
  - 🎯 **用户体验痛点**: 生成文档时长时间无响应导致用户焦虑
  - ✅ **新增分段生成**: 将文档生成拆分为5个部分(产品定义、用户旅程、功能清单、核心功能说明、补充说明)
  - ✅ **新增实时写入**: 使用 Bash 的 echo >> 命令每生成一个部分立即追加写入文件
  - ✅ **新增进度提示**: 每完成一个部分立即输出"✓ xxx部分已生成，开始生成xxx"的提示
  - ✅ **新增结构预览**: 生成前先显示文档结构，让用户了解将要生成的内容
  - ✅ **新增完成总结**: 生成完成后显示详细的总结信息，包含各部分的数量统计
  - 🔧 **核心原理**: 改变"先生成后写入"的模式为"边生成边写入"的模式，减少用户等待焦虑
  - 💡 **设计思路**: 模仿 CI/CD 的进度显示机制，让用户实时看到生成进度
- v1.8.0 (2026-01-26): 🔧 CRITICAL 修复 - 恢复高质量文档生成能力
  - 🐛 **根本原因**: 缺少 `requirements_template.md` 模板文件，且 SKILL.md 中的"生成逻辑"说明过于抽象，LLM 无法生成高质量的业务逻辑部分
  - ✅ **恢复模板文件**: 在 `references/` 目录下创建 `requirement_template.md` 模板文件（与 prd-generator 一致）
  - ✅ **重构生成逻辑**: 完全重写"第4-2步"的文档生成指导，新增详细的输出格式示例和标准
  - ✅ **新增业务逻辑格式示例**: 提供基于需智实际案例的高质量业务逻辑示例（包含步骤1-5，每步都有具体规则和算法）
  - ✅ **新增输入输出格式示例**: 提供具体的字段结构和数据类型示例
  - ✅ **新增界面交互示例**: 提供详细的界面布局和操作流程示例
  - 🔧 **核心修复**: 确保 LLM 能够理解"业务逻辑"部分的具体要求，生成可直接用于开发的详细规范
  - 💡 **设计原理**: 参考 b256077 提交中的高质量文档，恢复那时的详细指导内容
- v1.7.0 (2026-01-26): 🐛 CRITICAL BUG修复 - 文档生成逻辑问题
  - 🐛 **修复问题**: 生成的产品需求文档内容过于简单，没有充分利用用户在 AskUserQuestion 中提供的详细信息
  - ✅ **解决方案**: 在"第4步"添加明确的生成逻辑，要求基于用户答案生成详细文档
  - ✅ 新增"生成逻辑"章节，指导 LLM 如何从用户答案中提取详细信息
  - ✅ 强调"核心功能说明部分"必须包含用户提供的业务规则、推导规则等内容
  - 🔧 **核心修复**: 确保用户提供的详细内容(如需智的4类需求推导规则、排序规则等)完整写入文档的"业务逻辑"部分
  - 💡 **设计原理**: 之前的版本只写"基于模板生成"，但没有强调要使用用户的详细答案，导致生成的内容过于简单
- v1.6.0 (2026-01-26): 🎯 重大优化 - 核心业务逻辑问题动态化
  - ✅ 修复问题1：固定问核心业务流程问题（最重要）
  - ✅ 支持第1个问题的推荐选项动态生成（根据应用AI能力类型）
  - ✅ 明确3个问题的顺序：1.核心业务流程 → 2.用户与场景 → 3.核心价值
  - ✅ 优化问题2和问题3的选项，更贴近业务实际
  - ✅ 添加"动态生成选项规则"说明，指导LLM如何生成合适选项
  - 🔧 核心改进：第1个问题的选项示例根据应用类型智能调整，不写死
- v1.5.0 (2026-01-26): 🚨 CRITICAL修复 - 解决技能启动后不自动提问的问题
  - ✅ 修改description，明确要求"IMMEDIATELY use AskUserQuestion"
  - ✅ 简化执行流程，移除第1步的"判断是否需要提问"逻辑
  - ✅ 改为"立即使用AskUserQuestion问第1个问题"
  - ✅ 添加具体的YAML代码示例，明确告诉LLM要执行的代码
  - ✅ 在禁止行为中增加"禁止启动后不立即提问，停留在任何中间状态"
  - ✅ 强化"立即执行"的要求，使用更强烈的标记
  - 🔧 核心修复：确保技能启动后立即执行AskUserQuestion，不做任何判断或前置对话
- v1.4.0 (2026-01-25): 🎯 重大修复 - 文档生成方式优化
  - ✅ 修改为生成文档文件，而不是直接输出文档内容到对话中
  - ✅ 添加进度信息显示，避免用户等待时无反馈
  - ✅ 生成完成后显示文档路径和内容摘要
  - ✅ 优化用户体验，减少对话中的内容长度
- v1.3.0 (2026-01-24): 🎯 重大修复 - 问题提问逻辑优化
  - ✅ 添加 `AskUserQuestion` 工具到 `allowed-tools`
  - ✅ 明确要求 "最多3个问题,每个问题必须提供3-4个参考答案"
  - ✅ 增强执行流程说明,添加完整的使用示例代码
  - ✅ 添加标准问题模板和参考答案示例
  - ✅ 强制要求使用 `AskUserQuestion` 工具,不允许普通对话提问
  - ✅ 强制设置 `multiSelect: false`,单选即可
  - ✅ 明确 "收集完3个答案后立即进入Phase 2,不许再提问" 的规则
  - ✅ 添加中文关键词支持
- v1.2.0 (2025-01-23): Updated output format to match new PRD template structure
  - Changed to simpler format: 产品定义、用户旅程、功能清单、核心功能说明、补充说明
  - Removed User Personas, detailed journey table, and core business logic summary sections
  - Added detailed core feature descriptions (logic and interaction)
  - Emphasized that core business logic comes from user answers
- v1.1.0 (2025-01-21): Added strict execution workflow - exactly 3 questions, ask once only
- v1.0.0 (2025-12-26): Initial release - User Story Mapping skill

---

**Last Updated:** 2026-01-26
