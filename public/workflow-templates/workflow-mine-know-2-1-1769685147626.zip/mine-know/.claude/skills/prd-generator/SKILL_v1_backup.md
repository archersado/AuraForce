---
name: prd-generator
description: Generate comprehensive Product Requirements Documents (PRD) through structured role-based interviews. Use when users want to create PRDs, define product specifications, or document agent-based application architectures. Triggered by /create-prd command or when users explicitly request PRD creation or product documentation.
---

# PRD Generator

Generate comprehensive Product Requirements Documents through a structured, role-based interview process. This skill guides you through creating detailed PRDs for agent-based applications, covering user journeys, feature lists, business objects, logic, interaction cards, and event configurations.

## Workflow

Follow this sequential workflow, adopting different roles at each stage:

### Stage 1: Product Manager - User Journey & Features

**Objective:** Understand the product vision, user needs, and core features.

**Process:**

1. **Invoke user-story-mapping skill** to gather:
   - User personas and journeys
   - Core feature list with priorities
   - User value propositions

2. The user-story-mapping skill will handle the interview and mapping process. Capture its outputs for the PRD.

### Stage 2: Architect & Designer - Technical Design

**Objective:** Design the agent architecture, data models, logic, interactions, and events.

**Role:** Adopt the perspective of both a system architect and UX designer.

**Process:**

Ask up to 3 critical questions to understand:

1. **Agent & Domain Understanding:**
   - "What user roles will interact with this product? (Each role may need a separate agent)"
   - "What are the key business domain concepts/entities in this product?"

2. **Interaction Patterns:**
   - "How will users primarily interact with the system? (Chat, forms, buttons, voice, etc.)"

3. **Automation & Events:**
   - "What user actions or keywords should trigger automatic responses or workflows?"

**After gathering responses, generate:**

#### Business Objects

For each core domain entity:
- Object name and description
- Attributes with data types, required/optional, defaults
- Validation rules
- Relationships with other objects

**Guidelines:**
- Start with nouns from feature descriptions (e.g., "User", "Order", "Product")
- Include common attributes: id, created_at, updated_at, status
- Consider data that needs to persist or be shared between interactions

#### Business Logic

For each significant operation or workflow:
- Logic name and description
- Input parameters (what the logic needs)
- Output parameters (what the logic returns)
- Step-by-step logic description
- Business rules and constraints
- Error handling approach

**Guidelines:**
- Start with verbs from feature descriptions (e.g., "CreateOrder", "ValidatePayment")
- Consider CRUD operations for each business object
- Think about validation, calculations, and state transitions
- Each logic should have a single, clear responsibility

#### Interaction Cards

For each user-facing interaction:
- Card name and description
- Input parameters (data needed to render the card)
- Events emitted (what user actions trigger)
- UI/UX requirements:
  - Layout structure
  - UI elements (buttons, forms, displays)
  - Interaction behaviors
  - Visual design notes
  - Accessibility requirements

**Guidelines:**
- Each feature may need one or more cards
- Consider: info display cards, form input cards, confirmation cards, error cards
- Define clear visual hierarchy and user affordances
- Specify button labels, form fields, error messages

#### Event Configuration

For each triggerable event:
- Event name and description
- Trigger conditions:
  - Keywords (specific words/phrases)
  - Context conditions (user state, app state)
  - Priority level
- Actions when triggered:
  - Business logic to invoke (with parameter mapping)
  - Cards to display (with parameter mapping)
- Conflict resolution (if multiple events could trigger)

**Guidelines:**
- Map natural language user intents to system actions
- Consider greeting events, help requests, core feature triggers
- Define fallback/default events
- Think about conversational flow and context awareness

### Stage 3: Project Manager - Implementation Planning

**Objective:** Create actionable implementation roadmap.

**Role:** Adopt project manager perspective.

**Process:**

Generate implementation phases with:
- Phase name and timeline estimate
- Objectives and deliverables (as checkboxes)
- Dependencies between phases
- Success criteria

**Guidelines:**
- Start with foundational work (data models, core logic)
- Progress to user-facing features (cards, interactions)
- Consider MVP vs. future enhancements
- Account for testing and iteration phases
- Typical phases:
  1. Foundation (business objects, core logic)
  2. Core Features (primary user flows and cards)
  3. Enhanced Interactions (events, automation)
  4. Polish & Testing

## Generating the PRD Document

After completing all interview stages:

1. **Read the PRD template:**
   ```
   Read references/prd_template.md
   ```

2. **Populate the template** with all gathered information:
   - User Journey section (from Stage 1)
   - Product Feature List (from Stage 1)
   - Single Agent Architecture sections (from Stage 2):
     - Business Objects
     - Business Logic
     - Interaction Cards
     - Event Configuration
   - Implementation Roadmap (from Stage 3)

3. **Write the completed PRD** to a file:
   - Filename: `PRD_[ProductName]_v1.0.md`
   - Include all sections with complete details
   - Format tables properly
   - Use clear, professional language

4. **Review and refine:**
   - Ensure consistency across sections
   - Check that events reference defined logic/cards
   - Verify business logic references correct objects
   - Confirm feature list aligns with implementation plan

## Best Practices

**Interview Approach:**
- Keep questions focused and specific (max 3 per role)
- Use gathered context to make informed assumptions
- Apply product management best practices
- Don't over-interview - balance questions with expert judgment

**Content Generation:**
- Be comprehensive but concise
- Use tables for structured data
- Provide realistic examples in descriptions
- Maintain professional PRD tone
- Consider edge cases and error scenarios

**Multi-Agent Products:**
- If the product involves multiple user roles (e.g., buyer and seller, teacher and student), create separate "Single Agent Architecture" sections for each role
- Clearly label each agent's purpose and responsibilities
- Define how agents interact or share data

**Technical Depth:**
- Balance business requirements with technical feasibility
- Consider integration points and system constraints
- Include performance and security considerations where relevant
- Don't over-specify implementation details - focus on requirements

## Example Usage

**User triggers skill:**
```
/create-prd
```

**You respond:**
```
I'll help you create a comprehensive PRD through a structured interview process.

Let me start by understanding the user journey and features...

[Invoke user-story-mapping skill]
```

After user-story-mapping completes, transition to architect role:
```
Now let me design the technical architecture. I have a few questions:

1. What user roles will interact with this product?
2. How will users primarily interact with the system?
3. What user actions should trigger automatic responses?
```

Continue through all stages, then generate the final PRD document.

## Resources

### references/prd_template.md

Complete PRD template with all sections structured according to the target format. Read this file before generating the final PRD to ensure proper formatting and completeness.
