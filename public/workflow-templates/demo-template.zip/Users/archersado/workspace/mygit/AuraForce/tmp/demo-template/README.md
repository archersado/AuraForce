# Demo Workflow Template

This is a demo workflow template that can be loaded into any project.

## Features

- Simple and easy to understand
- Ready to use
- Fully documented

## Usage

1. Select this template
2. Enter a project name
3. Click "Load Template"
4. Start building your workflow!

## File Structure

This template contains a basic workflow structure with a README.md file.

## Getting Started

To use this template, simply load it into your workspace using the template selection panel.
