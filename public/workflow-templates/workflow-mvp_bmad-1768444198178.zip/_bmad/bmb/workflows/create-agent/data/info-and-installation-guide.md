# {agent_name} Agent

## Installation

Create a `custom.yaml` file in the agent folder:

```yaml
code: { agent_code }
name: '{agent_name}'
default_selected: true
```

Then run:

```bash
npx bmad-method install
```

Or if you have bmad-cli installed globally:

```bash
bmad install
```

## About This Agent

{agent_description}

_Generated with BMAD Builder workflow_
