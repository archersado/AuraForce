---
name: 'step-05-diagram-creation'
description: 'Create comprehensive diagrams for the workflow using Excalidraw MCP'

# Path Definitions
workflow_path: '{project-root}/_bmad/bmb/workflows/edit-workflow'

# File References
thisStepFile: '{workflow_path}/steps/step-05-diagram-creation.md'
workflowFile: '{workflow_path}/workflow.md'
editedWorkflowPath: '{target_workflow_path}'
outputFile: '{output_folder}/workflow-edit-{target_workflow_name}.md'
diagramsFolder: '{project-root}/diagrams'

# Task References
---

# Step 5: Diagram Creation

## STEP GOAL:

Create comprehensive workflow diagrams using Excalidraw MCP to visualize the workflow structure, interactions, and key components. Export each diagram to the /diagrams folder and clear the canvas before creating the next diagram.

## MANDATORY EXECUTION RULES (READ FIRST):

### Universal Rules:

- 🛑 NEVER generate content without user input
- 📖 CRITICAL: Read the complete step file before taking any action
- 📋 YOU ARE A FACILITATOR, not a content generator

### Role Reinforcement:

- ✅ You are a workflow visualization specialist and diagram creation expert
- ✅ If you already have been given a name, communication_style, and persona, continue to use those while playing this new role
- ✅ We engage in collaborative dialogue, not command-response
- ✅ You bring expertise in Excalidraw MCP and workflow visualization
- ✅ User brings their workflow context and diagramming needs

### Step-Specific Rules:

- 🎯 Focus only on creating workflow diagrams using Excalidraw MCP
- 🚫 FORBIDDEN to use layout engine or any other diagramming tools
- 💬 Approach: Visual thinking, clear, and methodical
- 📋 Ensure each diagram is exported before creating the next one

## EXECUTION PROTOCOLS:

- 🎯 Create 5 workflow diagrams using Excalidraw MCP
- 💾 Export each diagram to /diagrams folder before creating the next
- 📖 Clear the canvas after each export to ensure clean workspace
- 🚫 FORBIDDEN to proceed without proper export and canvas clearing

## CONTEXT BOUNDARIES:

- Available context: Edited workflow files from previous improve step
- Focus: Diagram creation using Excalidraw MCP only
- Limits: Create exactly 5 diagrams, no more, no less
- Dependencies: Successful workflow improvements in previous step

## Sequence of Instructions (Do not deviate, skip, or optimize)

### 1. Initialize Diagram Creation Process

"**Workflow Visualization: Creating Comprehensive Diagrams**

Now that your workflow has been edited and improved, let's create comprehensive diagrams to visualize its structure and interactions.

We will create 5 essential diagrams using Excalidraw MCP:

1. **User-System Interaction Diagram** - Shows how users interact with the system
2. **Process Flow Diagram** - Illustrates the main process flow and decision points
3. **Component Architecture Diagram** - Displays system components and their relationships
4. **Data Flow Diagram** - Shows how data moves through the system
5. **State Transition Diagram** - Illustrates system states and transitions

Each diagram will be exported to the /diagrams folder and the canvas will be cleared before creating the next one."

### 2. Prepare Diagram Environment

**A. Verify Diagrams Folder:**

"Preparing the diagram creation environment...

Checking if the /diagrams folder exists and creating it if needed..."

Use the command: `mkdir -p {diagramsFolder}`

**B. Initialize Excalidraw:**

"Initializing Excalidraw MCP for diagram creation.

Let's start by clearing the canvas to ensure we have a clean workspace."

### 3. Diagram 1: User-System Interaction Diagram

**A. Create User-System Interaction Diagram:**

"**Creating Diagram 1: User-System Interaction**

This diagram will show:
- User roles and actors
- System boundaries
- Interaction points and touchpoints
- Input/output flows
- External system integrations

Let's create this diagram using Excalidraw MCP..."

**B. Excalidraw Instructions:**

1. Create stick figures for different user roles using the Excalidraw MCP
2. Draw system boundary as a large rectangle
3. Add interaction points as circles along the boundary
4. Draw arrows showing interaction flows
5. Label all components clearly
6. Add a title "User-System Interaction Diagram"

**C. Export Diagram 1:**

"Exporting User-System Interaction Diagram to /diagrams/user-system-interaction.png"

Use Excalidraw MCP to export the canvas with these parameters:
- filepath: "{diagramsFolder}/user-system-interaction.png"
- format: "png"

**D. Clear Canvas:**

"Clearing the canvas for the next diagram..."

### 4. Diagram 2: Process Flow Diagram

**A. Create Process Flow Diagram:**

"**Creating Diagram 2: Process Flow**

This diagram will illustrate:
- Main process steps
- Decision points and branches
- Process start and end points
- Parallel processes
- Feedback loops

Let's create this diagram..."

**B. Excalidraw Instructions:**

1. Draw oval shapes for start/end points
2. Use rectangles for process steps
3. Use diamonds for decision points
4. Connect with arrows showing flow direction
5. Add swim lanes if multiple actors involved
6. Label each step and decision clearly
7. Add title "Process Flow Diagram"

**C. Export Diagram 2:**

"Exporting Process Flow Diagram to /diagrams/process-flow.png"

Use Excalidraw MCP to export:
- filepath: "{diagramsFolder}/process-flow.png"
- format: "png"

**D. Clear Canvas:**

"Clearing the canvas for the next diagram..."

### 5. Diagram 3: Component Architecture Diagram

**A. Create Component Architecture Diagram:**

"**Creating Diagram 3: Component Architecture**

This diagram will display:
- System components and modules
- Component relationships
- APIs and interfaces
- External dependencies
- Technology layers

Let's create this diagram..."

**B. Excalidraw Instructions:**

1. Draw rectangles for each component
2. Group related components together
3. Use different colors for different layers
4. Draw lines showing dependencies
5. Add symbols for APIs and databases
6. Label all components clearly
7. Add title "Component Architecture Diagram"

**C. Export Diagram 3:**

"Exporting Component Architecture Diagram to /diagrams/component-architecture.png"

Use Excalidraw MCP to export:
- filepath: "{diagramsFolder}/component-architecture.png"
- format: "png"

**D. Clear Canvas:**

"Clearing the canvas for the next diagram..."

### 6. Diagram 4: Data Flow Diagram

**A. Create Data Flow Diagram:**

"**Creating Diagram 4: Data Flow**

This diagram will show:
- Data sources and sinks
- Data stores
- Data transformation processes
- Data flows and directions
- Data entities

Let's create this diagram..."

**B. Excalidraw Instructions:**

1. Use rounded rectangles for data stores
2. Use circles for external entities
3. Use rectangles for processes
4. Draw arrows with labels for data flows
5. Show data transformation points
6. Add title "Data Flow Diagram"

**C. Export Diagram 4:**

"Exporting Data Flow Diagram to /diagrams/data-flow.png"

Use Excalidraw MCP to export:
- filepath: "{diagramsFolder}/data-flow.png"
- format: "png"

**D. Clear Canvas:**

"Clearing the canvas for the final diagram..."

### 7. Diagram 5: State Transition Diagram

**A. Create State Transition Diagram:**

"**Creating Diagram 5: State Transition**

This diagram will illustrate:
- System states
- Transitions between states
- Events causing transitions
- Initial and final states
- Concurrent states if applicable

Let's create this diagram..."

**B. Excalidraw Instructions:**

1. Draw circles for each state
2. Use double circle for initial state
3. Use circle with border for final state
4. Draw arrows labeled with events
5. Add conditions for guarded transitions
6. Label all states clearly
7. Add title "State Transition Diagram"

**C. Export Diagram 5:**

"Exporting State Transition Diagram to /diagrams/state-transition.png"

Use Excalidraw MCP to export:
- filepath: "{diagramsFolder}/state-transition.png"
- format: "png"

### 8. Diagram Completion Summary

**A. Review Created Diagrams:**

"**Diagram Creation Complete!**

All 5 workflow diagrams have been successfully created and exported:

1. ✅ User-System Interaction Diagram - /diagrams/user-system-interaction.png
2. ✅ Process Flow Diagram - /diagrams/process-flow.png
3. ✅ Component Architecture Diagram - /diagrams/component-architecture.png
4. ✅ Data Flow Diagram - /diagrams/data-flow.png
5. ✅ State Transition Diagram - /diagrams/state-transition.png

These diagrams provide a comprehensive visual representation of your workflow."

**B. Documentation Update:**

Update the {outputFile} with diagram references:

"## Workflow Diagrams

The following diagrams have been created to visualize this workflow:

- **User-System Interaction**: Shows how users interact with the system
- **Process Flow**: Illustrates the main process flow and decision points
- **Component Architecture**: Displays system components and their relationships
- **Data Flow**: Shows how data moves through the system
- **State Transition**: Illustrates system states and transitions

All diagrams are available in the /diagrams folder."

### 9. Final Menu Options

"**Diagram Creation Complete!**

**Select an Option:**

- [C] Complete - Finish with all diagrams created
- [R] Review Diagrams - Check each diagram individually
- [M] Modify Diagram - Redraw any specific diagram
- [E] Export Additional Format - Export diagrams as SVG or other formats"

## Menu Handling Logic:

- IF C: End diagram creation successfully with summary
- IF R: Show each diagram and provide review options
- IF M: Allow selection of specific diagram to recreate
- IF E: Provide options for exporting in different formats
- IF Any other comments or queries: respond and redisplay options

## CRITICAL STEP COMPLETION NOTE

ONLY WHEN all 5 diagrams have been created, exported to /diagrams folder, and the canvas cleared after each export, will this step be considered successfully completed.

---

## 🚨 SYSTEM SUCCESS/FAILURE METRICS

### ✅ SUCCESS:

- All 5 workflow diagrams created using Excalidraw MCP
- Each diagram exported to /diagrams folder in PNG format
- Canvas properly cleared between diagram creations
- Diagrams are clearly labeled and understandable
- User provided with comprehensive visual documentation
- Documentation updated with diagram references

### ❌ SYSTEM FAILURE:

- Using any tool other than Excalidraw MCP for diagram creation
- Not exporting diagrams to /diagrams folder
- Not clearing canvas between diagrams
- Creating fewer or more than 5 diagrams
- Not following the specific diagram types and requirements
- Skipping any diagram in the sequence

**Master Rule:** Skipping steps, optimizing sequences, or not following exact instructions is FORBIDDEN and constitutes SYSTEM FAILURE.
