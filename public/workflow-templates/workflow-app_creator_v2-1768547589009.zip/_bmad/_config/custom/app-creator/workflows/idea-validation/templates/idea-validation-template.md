---
stepsCompleted: []
lastStep: ''
date: '创建日期'
user_name: '用户名'
projectName: '项目名称'
ideaStatus: 'draft'
validationScore: 0
confidenceLevel: 0
---

# 产品创意验证报告

## 项目概述

**项目名称**: [待填写]
**创建日期**: [待填写]
**验证状态**: 进行中

*此报告记录了从创意到可执行产品方向的完整验证过程。*

---

## 📋 工作流进度

- [ ] Step 1: 初始化
- [ ] Step 2: 创意捕获
- [ ] Step 3: 价值主张定义
- [ ] Step 4: 可行性评估
- [ ] Step 5: 市场验证
- [ ] Step 6: MVP范围定义

---

*验证内容将在此处逐步积累...*