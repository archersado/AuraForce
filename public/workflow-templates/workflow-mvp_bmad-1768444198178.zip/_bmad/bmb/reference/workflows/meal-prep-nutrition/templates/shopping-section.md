## Weekly Shopping List

### Check Pantry First

- [List of common staples to verify]

### Produce Section

- [Item] - [Quantity] - [Used in]

### Protein

- [Item] - [Quantity] - [Used in]

### Dairy/Alternatives

- [Item] - [Quantity] - [Used in]

### Grains/Starches

- [Item] - [Quantity] - [Used in]

### Frozen

- [Item] - [Quantity] - [Used in]

### Pantry

- [Item] - [Quantity] - [Used in]

### Money-Saving Tips

- [Personalized savings strategies]

### Flexible Swaps

- [Alternative options if items unavailable]
