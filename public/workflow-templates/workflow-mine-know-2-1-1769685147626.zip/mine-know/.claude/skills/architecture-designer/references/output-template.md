# 详细设计

This document provides the complete Single Agent Architecture design, covering business objects, business logic, and interaction design.

---

# Architecture Design Output Template

This template defines the standard output format for the architecture-designer skill, covering all three layers: business objects, business logic, and interaction design.

---

## Single Agent Architecture

### Agent Overview

**Agent Role:** [Role name, e.g., Library Management Agent, E-commerce Assistant]

**Agent Purpose:** [Brief description of the agent's primary function and responsibilities]

**Agent Identity (Persona):**
- [Description of the agent's character, personality, and professional identity]
- [Tone and style - e.g., professional and empathetic, friendly and casual, authoritative and precise]
- [Behavioral traits - e.g., proactive listener, solution-oriented, patient]

**Core Capabilities:**
- [Capability 1]: [Brief description]
- [Capability 2]: [Brief description]
- [Capability 3]: [Brief description]

---

## Layer 1: Business Objects (Data Model)

### [Business Object Name 1]

**Description:** [What this object represents in the business domain]

**Attributes:**

| Attribute Name | Data Type | Required | Default Value | Description |
|----------------|-----------|----------|---------------|-------------|
| id | string | Yes | auto-generated | Unique identifier |
| createdAt | date | Yes | current timestamp | Creation timestamp |
| updatedAt | date | Yes | current timestamp | Last update timestamp |
| status | string | Yes | "active" | Object lifecycle status |
| [attribute1] | [type] | [Yes/No] | [value or N/A] | [Description] |
| [attribute2] | [type] | [Yes/No] | [value or N/A] | [Description] |

**Validation Rules:**
- [Rule 1: e.g., email must be unique and match email format]
- [Rule 2: e.g., quantity must be >= 1]
- [Rule 3: e.g., status must be one of: "active", "inactive", "deleted"]

**Relationships:**
- [Relationship 1: e.g., One User has many Orders (one-to-many)]
- [Relationship 2: e.g., Order belongs to one User (many-to-one)]

**Example Data:**
```json
{
  "id": "obj_001",
  "attribute1": "example value"
}
```

---

### [Business Object Name 2]

[Repeat structure for each business object]

---

## Layer 2: Business Logic (Operations)

### [Logic Name 1]

**Description:** [What this logic does and when it's invoked]

**Input Parameters:**

| Parameter Name | Data Type | Required | Description |
|----------------|-----------|----------|-------------|
| [param1] | [type] | [Yes/No] | [Description] |
| [param2] | [type] | [Yes/No] | [Description] |

**Output Parameters:**

| Parameter Name | Data Type | Description |
|----------------|-----------|-------------|
| [output1] | [type] | [Description] |
| [output2] | [type] | [Description] |
| success | boolean | Whether operation succeeded |
| message | string | Result message |

**Execution Steps:**

1. **[Step 1 Name]**
   - Action: [What it does]
   - Judgment: [Condition to check]
   - Result: [What it produces]

2. **[Step 2 Name]**
   - Action: [What it does]
   - Judgment: [Condition to check]
   - Result: [What it produces]

**Business Rules:**
- **Rule 1:** [Rule description and scenario]
- **Rule 2:** [Rule description and scenario]

**Exception Handling:**

| Exception Type | Trigger Condition | Handling | Error Code |
|----------------|-------------------|----------|------------|
| [Error 1] | [Condition] | [Handling] | [ERR_CODE] |

**Called Operations:**
- [Logic Name]: [Usage scenario]

**Modified Objects:**
- [Object Name]: [How it's modified]

---

### [Logic Name 2]

[Repeat structure for each business logic operation]

---

## Layer 3: Interaction Design

### Interaction Cards

#### [Card Name 1]

**Description:** [What this card displays and its purpose]

**Usage Scenario:** [When this card is displayed]

**Input Parameters:**

| Parameter Name | Data Type | Required | Description |
|----------------|-----------|----------|-------------|
| [param1] | [type] | [Yes/No] | [Description] |
| [param2] | [type] | [Yes/No] | [Description] |

**Events Emitted:**

| Event Name | Trigger Condition | Payload |
|------------|-------------------|---------|
| [event_name] | [User action/condition] | [Payload] |

**UI Layout:**

```
┌─────────────────────────────────┐
│  [Title Area]                    │
├─────────────────────────────────┤
│  [Main Content Area]             │
│  - Element 1: [Description]      │
│  - Element 2: [Description]      │
├─────────────────────────────────┤
│  [Action Buttons Area]           │
│  [Button 1] [Button 2]           │
└─────────────────────────────────┘
```

**UI Element Description:**

| Element Name | Type | Content/Value | Interaction Behavior |
|--------------|------|---------------|---------------------|
| [Element 1] | [text/button/input] | [What it shows] | [Behavior] |
| [Element 2] | [text/button/input] | [What it shows] | [Behavior] |

**Interaction Behaviors:**
- **[Behavior 1]:** [User action] → [System response] → [Trigger event/business logic]
- **[Behavior 2]:** [User action] → [System response] → [Trigger event/business logic]

**Card Events:**

This section documents card lifecycle and interaction events that trigger business logic.

| Event Name | Trigger Timing | Triggered Business Logic | Description |
|------------|----------------|-------------------------|-------------|
| [event_name_1] | [When triggered] | [Logic Name] | [Event description] |
| [event_name_2] | [When triggered] | [Logic Name] | [Event description] |

Common event examples:
- `onInit`: Triggered when card initializes (e.g., load initial data)
- `onSubmit`: Triggered when form is submitted (e.g., save data)
- `onClick[ButtonName]`: Triggered when specific button is clicked
- `onChange[FieldName]`: Triggered when field value changes
- Custom domain-specific events

**Visual Design Requirements:**
- [Design requirement 1]
- [Design requirement 2]

**Accessibility Requirements:**
- [Accessibility requirement 1]
- [Accessibility requirement 2]

**Example:**
```
[Card display example]
```

---

#### [Card Name 2]

[Repeat structure for each interaction card]

---

### Intent Configuration

This section defines the Agent's intent recognition capabilities.

Enabling the Agent to understand natural language and execute corresponding operations.

---

#### [Intent Name 1]

**Intent Description:** [Description of the user's purpose and scenario, e.g., User wants to borrow a book]

**Matching Keywords:** [Comma-separated list of keywords that directly trigger the intent]

Example: `borrow, reserve, lend`

**Similar Questions:** [Natural language variations users might ask, one per line]

Example:
```
I want to borrow this book
Can I borrow it?
How do I borrow books
Help me reserve a book
```

**Triggered Business Logic:**

This section documents business logic triggered by this user intent.

| Business Logic Name | Description |
|---------------------|-------------|
| [Logic Name 1] | [What this logic does when triggered by this intent] |
| [Logic Name 2] | [What this logic does when triggered by this intent] |

**Parameter Mapping:**
```
input.param1 = extracted from keyword context
input.param2 = provided by user input
```

**Displayed Interaction Cards:**

| Card Name | Description |
|-----------|-------------|
| [Card Name 1] | [Display description] |
| [Card Name 2] | [Display description, if multiple] |

**Priority:** [High/Medium/Low]

---

#### [Intent Name 2]

[Repeat structure for each intent]

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    PRESENTATION LAYER                        │
│                   (Interaction Cards)                        │
├─────────────────────────────────────────────────────────────┤
│  [Card1]  │  [Card2]  │  [Card3]                             │
│                │                  │                          │
│  [Events]     └──────────────────┴────> Events               │
└──────────────────────────┬──────────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────────┐
│                     LOGIC LAYER                              │
│                  (Business Logic)                            │
├─────────────────────────────────────────────────────────────┤
│  [Logic1]  │  [Logic2]  │  [Logic3]                          │
│       │              │               │                        │
│       └──────────────┴───────────────┴                        │
│                           ▼                                  │
└──────────────────────────┬──────────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────────┐
│                     DATA LAYER                               │
│                  (Business Objects)                          │
├─────────────────────────────────────────────────────────────┤
│  [Object1]  │  [Object2]  │  [Object3]                       │
└─────────────────────────────────────────────────────────────┘
```

---

## Technical Considerations

### Performance Requirements
- [Performance metric 1]
- [Performance metric 2]

### Data Storage
- [Storage solution and persistence strategy]

### Integration Interfaces
- **[Interface 1]:** [Description, call method, data format]
- **[Interface 2]:** [Description, call method, data format]

### Security
- [Security measure 1]
- [Security measure 2]

### Scalability
- [How to extend new features]
- [Extensibility points]

---

## Appendix

### Object Relationship Diagram

```
[Object1] ──1:N── [Object2]
    │
    └──1:1── [Object3]
```

### State Machine Diagram

```
[State1] --event1--> [State2] --event2--> [State3]
```

### API Interface List

| Interface | Method | Path | Description |
|-----------|--------|------|-------------|
| [API1] | POST | /api/xxx | [Description] |

### Completeness Checklist

**Intent Configuration Validation:**
- [ ] All P0 features have corresponding intents
- [ ] Each intent has matching keywords
- [ ] Similar questions include commands, questions, and implicit requests
- [ ] All user intents from user journey are covered
- [ ] Synonyms and variations are included

---

**Generated:** [date]
**Version:** 1.0
