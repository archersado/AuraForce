---
name: domain-arch-designer
description: "Generate enterprise-grade technical architecture documents (Architecture.md) from domain knowledge models and PRD. Strictly follows architecture-designer's three-layer design (Business Objects, Business Logic, Interaction Design) with enterprise enhancements. Use when: (1) Claude (Design Coordinator) needs to generate Architecture.md in Phase 3 (Documentation), (2) User requests technical architecture design based on domain model and PRD, (3) Working within enterprise-architect module's end-to-end-design workflow. Compatible with and extends the base architecture-designer skill for enterprise scenarios."
allowed-tools: Read, Write, Edit, Glob, Grep
---

# Domain Architecture Designer

Generate enterprise-grade technical architecture documents (Architecture.md) from domain knowledge models and PRD, following architecture-designer's three-layer design approach.

## Overview

This skill transforms domain knowledge models and PRD documents into structured technical architecture documents suitable for enterprise development teams. It **fully integrates** the base `architecture-designer` skill's three-layer architecture with enterprise enhancements:

- **Domain model integration**: Reads from Arthur's sidecar memory
- **PRD integration**: Reads functional and non-functional requirements from PRD.md
- **Three-layer architecture**: Business Objects (Data Model), Business Logic (Operations), Interaction Design (UI & Intent)
- **Business logic triggering**: User Intent Triggering + Card Event Triggering
- **Intent configuration**: Complete intent recognition with keywords and similar questions
- **Enterprise quality**: Security architecture, quality attributes, and comprehensive validation

**When to use**: Called by Claude (Design Coordinator) in Phase 3 (Documentation) of the end-to-end-design workflow, after PRD.md and Interaction.md are generated.

**Key principle**: This skill MUST include ALL core concepts from architecture-designer. It can add enterprise features but CANNOT remove any architecture-designer functionality.

## Workflow

### Step 1: Validate Inputs

Before generating architecture, verify required inputs exist and are complete:

```bash
# Check domain model
Read: {project-root}/_bmad/_memory/domain-consultant-sidecar/memories.md

# Check PRD
Read: {output_folder}/PRD.md
```

**Required from Domain Model**:
- Business Context
- Domain Entities (with attributes and relationships)
- Business Rules
- Constraints (technical, business, regulatory)
- State Transitions
- Integration Points

**Required from PRD**:
- Functional Requirements (User Stories, Functional Modules)
- Non-Functional Requirements (Performance, Security, Scalability, etc.)
- Data Model (Core Entities)
- Business Rules
- Integration Requirements
- Constraints

**If incomplete**: Return error with specific gaps and suggest completing missing inputs.

### Step 2: Analyze Requirements

Extract and analyze key requirements that drive architecture decisions:

**Functional Drivers**:
- Core business capabilities (from PRD functional modules)
- User interaction patterns (from PRD user stories)
- Data complexity (from domain entities and relationships)
- Integration needs (from integration points)

**Non-Functional Drivers**:
- Performance requirements (response time, throughput)
- Scalability requirements (expected load, growth)
- Security requirements (authentication, authorization, compliance)
- Availability requirements (uptime, disaster recovery)
- Maintainability requirements (team size, skills, timeline)

**Constraints**:
- Technical constraints (existing systems, technology standards)
- Business constraints (budget, timeline, resources)
- Regulatory constraints (compliance, data residency)

### Step 3: Design Architecture (Three Layers)

This step integrates architecture-designer's three-layer design.

#### Layer 1: Business Objects (Data Model)

Extract business objects from domain entities and PRD data model.

For each business object, define:

**Object Structure:**
- **Name**: Singular noun (e.g., "User", not "Users")
- **Description**: What this object represents in the business domain
- **Attributes**: name, data type, required, default, description
  - Always include: id, createdAt, updatedAt, status
- **Validation Rules**: Format, range, business constraints
- **Relationships**: How this object relates to others (one-to-one, one-to-many, many-to-many)

**Design Guidelines:**
- ✅ Include standard metadata (id, timestamps, status)
- ✅ Define clear data types and validation rules
- ✅ Document relationships with cardinality
- ✅ Map from domain entities in domain model
- ❌ Don't over-engineer with unnecessary attributes
- ❌ Don't include UI-specific fields

**Output Format:**
```markdown
## Layer 1: Business Objects (Data Model)

### [Business Object Name]

**Description:** [What this object represents]

**Attributes:**

| Attribute Name | Data Type | Required | Default Value | Description |
|----------------|-----------|----------|---------------|-------------|
| id | string | Yes | auto-generated | Unique identifier |
| createdAt | date | Yes | current timestamp | Creation timestamp |
| updatedAt | date | Yes | current timestamp | Last update timestamp |
| status | string | Yes | "active" | Object lifecycle status |
| [attribute] | [type] | [Yes/No] | [value or N/A] | [Description] |

**Validation Rules:**
- [Rule 1: e.g., email must be unique and match email format]
- [Rule 2: e.g., quantity must be >= 1]

**Relationships:**
- [Relationship 1: e.g., One User has many Orders (one-to-many)]

**Example Data:**
```json
{
  "id": "obj_001",
  "attribute1": "example value"
}
```
```

#### Layer 2: Business Logic (Operations)

Extract business logic from PRD functional requirements and domain model business rules.

**Business Logic Triggering Mechanisms:**

Business logic can be triggered in two ways:

1. **User Intent Triggering**: Through natural language interaction
   - Keywords define what users can say to trigger actions
   - The Agent uses keywords to recognize user requests
   - Intent Configuration maps user input to business logic

2. **Card Event Triggering**: Through UI interactions
   - Card initialization events (onInit) - e.g., loading data when card displays
   - Card submission events (onSubmit) - e.g., processing form data
   - Custom card events - e.g., button clicks, field changes

Both triggering mechanisms must be clearly documented.

For each business operation, define:

**Logic Structure:**
- **Name**: Verb-based (e.g., "CreateOrder", "ProcessPayment")
- **Description**: What it does and when invoked
- **Trigger Source**: User Intent or Card Event (specify which)
- **Input Parameters**: name, type, required, description
- **Output Parameters**: name, type, description
- **Logic Steps**: Step-by-step workflow (validate → check rules → perform operations → update state → return)
- **Business Rules**: Constraints that must be satisfied
- **Error Handling**: Validation errors, business rule violations, system errors

**Output Format:**
```markdown
## Layer 2: Business Logic (Operations)

### [Logic Name]

**Description:** [What this logic does]

**Trigger Source:** [User Intent: IntentName] or [Card Event: CardName.eventName]

**Input Parameters:**

| Parameter Name | Data Type | Required | Description |
|----------------|-----------|----------|-------------|
| [param] | [type] | [Yes/No] | [Description] |

**Output Parameters:**

| Parameter Name | Data Type | Description |
|----------------|-----------|-------------|
| [output] | [type] | [Description] |
| success | boolean | Whether operation succeeded |
| message | string | Result message |

**Execution Steps:**

1. **[Step 1 Name]**
   - Action: [What it does]
   - Judgment: [Condition to check]
   - Result: [What it produces]

2. **[Step 2 Name]**
   - Action: [What it does]
   - Judgment: [Condition to check]
   - Result: [What it produces]

**Business Rules:**
- **Rule 1:** [Rule description and scenario]
- **Rule 2:** [Rule description and scenario]

**Exception Handling:**

| Exception Type | Trigger Condition | Handling | Error Code |
|----------------|-------------------|----------|------------|
| [Error 1] | [Condition] | [Handling] | [ERR_CODE] |

**Called Operations:**
- [Logic Name]: [Usage scenario]

**Modified Objects:**
- [Object Name]: [How it's modified]
```

**Design Guidelines:**
- ✅ Name with clear action verbs
- ✅ Define explicit input/output contracts
- ✅ Reference business objects by name
- ✅ Consider state transitions
- ✅ Document error scenarios
- ✅ Specify trigger source (User Intent or Card Event)
- ❌ Don't include implementation details (code, SQL)
- ❌ Don't mix multiple responsibilities

#### Layer 3: Interaction Design (UI & Intent)

Extract interaction patterns from PRD user journey and Interaction.md.

For each user-facing interaction, define:

**Interaction Cards:**
- **Name**: Descriptive (e.g., "OrderSummaryCard")
- **Description**: Purpose and functionality
- **Usage Scenario**: When this card is displayed
- **Input Parameters**: Data needed to render
- **Events Emitted**: User actions (button clicks, form submits)
- **Card Events**: Lifecycle and interaction events that trigger business logic
  - onInit: Triggered when card initializes
  - onSubmit: Triggered when form is submitted
  - Custom events: Domain-specific events (e.g., onItemSelected, onRefresh)
- **UI Layout**: Visual structure with elements
- **UI Element Description**: Detailed element specifications
- **Interaction Behaviors**: User action → System response → Trigger event/business logic
- **Visual Design Requirements**: Design specifications
- **Accessibility Requirements**: Accessibility specifications

**Intent Configuration:**

For each intent, define:
- **Intent Name**: Clear intent name (e.g., "OnCreateOrder", "OnSearchProducts")
- **Intent Description**: User's purpose and scenario
- **Matching Keywords**: Keywords that directly trigger the intent (comma-separated)
  - Example: `borrow, reserve, lend`
- **Similar Questions**: Natural language variations (one per line)
  - Example:
    ```
    I want to borrow this book
    Can I borrow it?
    How do I borrow books
    Help me reserve a book
    ```
- **Triggered Business Logic**: Operations to call with parameters
- **Displayed Interaction Cards**: Cards to show with parameters
- **Priority**: High/Medium/Low

**Output Format:**
```markdown
## Layer 3: Interaction Design

### Interaction Cards

#### [Card Name]

**Description:** [What this card displays and its purpose]

**Usage Scenario:** [When this card is displayed]

**Input Parameters:**

| Parameter Name | Data Type | Required | Description |
|----------------|-----------|----------|-------------|
| [param] | [type] | [Yes/No] | [Description] |

**Events Emitted:**

| Event Name | Trigger Condition | Payload |
|------------|-------------------|---------|
| [event_name] | [User action/condition] | [Payload] |

**UI Layout:**

```
┌─────────────────────────────────┐
│  [Title Area]                    │
├─────────────────────────────────┤
│  [Main Content Area]             │
│  - Element 1: [Description]      │
│  - Element 2: [Description]      │
├─────────────────────────────────┤
│  [Action Buttons Area]           │
│  [Button 1] [Button 2]           │
└─────────────────────────────────┘
```

**UI Element Description:**

| Element Name | Type | Content/Value | Interaction Behavior |
|--------------|------|---------------|---------------------|
| [Element 1] | [text/button/input] | [What it shows] | [Behavior] |

**Interaction Behaviors:**
- **[Behavior 1]:** [User action] → [System response] → [Trigger event/business logic]

**Card Events:**

| Event Name | Trigger Timing | Triggered Business Logic | Description |
|------------|----------------|-------------------------|-------------|
| onInit | When card initializes | [Logic Name] | [Event description] |
| onSubmit | When form is submitted | [Logic Name] | [Event description] |
| [custom_event] | [When triggered] | [Logic Name] | [Event description] |

**Visual Design Requirements:**
- [Design requirement 1]

**Accessibility Requirements:**
- [Accessibility requirement 1]

### Intent Configuration

#### [Intent Name]

**Intent Description:** [Description of the user's purpose and scenario]

**Matching Keywords:** [Comma-separated list of keywords]

Example: `borrow, reserve, lend`

**Similar Questions:** [Natural language variations, one per line]

Example:
```
I want to borrow this book
Can I borrow it?
How do I borrow books
Help me reserve a book
```

**Triggered Business Logic:**

| Business Logic Name | Description |
|---------------------|-------------|
| [Logic Name] | [What this logic does when triggered by this intent] |

**Parameter Mapping:**
```
input.param1 = extracted from keyword context
input.param2 = provided by user input
```

**Displayed Interaction Cards:**

| Card Name | Description |
|-----------|-------------|
| [Card Name] | [Display description] |

**Priority:** [High/Medium/Low]
```

**Intent Configuration Best Practices:**
- ✅ Define clear matching keywords for each intent
- ✅ Map intents to business logic operations or card display
- ✅ Specify trigger source for each business logic (User Intent or Card Event)
- ✅ Document card events (onInit, onSubmit, custom events) that trigger logic
- ✅ Cover ALL user intents from feature list
- ✅ Include similar questions with various natural language patterns
- ✅ Consider both UI-triggered and conversational intents
- ❌ Don't miss any user intents - incomplete events mean Agent won't understand requests

### Step 4: Validate Consistency

Follow architecture-designer's validation approach:

**Data Flow Validation:**
- Every business logic operation references valid business objects
- Every interaction card displays data from business objects
- Every intent triggers valid operations
- Logic outputs match card input parameters

**Naming Consistency:**
- Use consistent naming conventions across layers
- Business objects referenced by same name everywhere
- Logic operations referenced by events use exact names

**Completeness Check:**
- All P0 features have corresponding logic and UI
- All business objects have CRUD operations (if applicable)
- All user actions have event handlers
- All user intents from feature list have corresponding events with keywords and similar questions

**Intent Configuration Validation:**
- All P0 features have corresponding intents
- Each intent has matching keywords
- Similar questions include commands, questions, and implicit requests
- All user intents from user journey are covered
- Synonyms and variations are included
- Both User Intent and Card Event triggering mechanisms documented

### Step 5: Add Enterprise Quality Attributes

Extend architecture-designer with enterprise-specific concerns:

#### Security Architecture

**Authentication & Authorization**:
- Choose authentication method (OAuth, SAML, JWT)
- Define authorization model (RBAC, ABAC)
- Specify identity provider integration

**Data Security**:
- Define encryption at rest and in transit
- Specify data masking for sensitive data
- Document key management strategy

**Compliance**:
- Identify applicable regulations (GDPR, HIPAA, PCI-DSS) from domain model constraints
- Document compliance controls
- Specify audit and logging requirements

#### Quality Attributes

**Performance**:
- Define performance targets (response time, throughput) from PRD non-functional requirements
- Identify performance bottlenecks from Layer 2 business logic
- Specify performance optimization strategies

**Scalability**:
- Define scalability targets (concurrent users, data volume) from PRD non-functional requirements
- Document capacity planning considerations

**Availability**:
- Define availability targets (uptime percentage) from PRD non-functional requirements
- Design for fault tolerance (redundancy, failover)

**Maintainability**:
- Define code quality standards
- Specify monitoring and observability strategy
- Document operational procedures

### Step 6: Generate Architecture Document

Generate structured output following architecture-designer's template structure with enterprise enhancements.

**Output File Name:** `Architecture.md` (or `详细设计.md` for compatibility)

**Document Structure:**

1. **Single Agent Architecture** (if applicable)
   - Agent Overview
   - Agent Role, Purpose, Identity (Persona)
   - Core Capabilities

2. **Layer 1: Business Objects (Data Model)**
   - Complete business object definitions from Step 3
   - Attributes, validation rules, relationships
   - Example data

3. **Layer 2: Business Logic (Operations)**
   - Complete business logic operations from Step 3
   - Input/output parameters, execution steps
   - Business rules, exception handling
   - Trigger sources (User Intent or Card Event)
   - Called operations, modified objects

4. **Layer 3: Interaction Design**
   - Interaction Cards with UI layouts and events
   - Card Events (onInit, onSubmit, custom events)
   - Intent Configuration with keywords and similar questions
   - Triggered business logic and displayed cards

5. **Architecture Diagram**
   - Three-layer architecture diagram
   - Data flow between layers

6. **Technical Considerations** (Enterprise additions)
   - Performance Requirements
   - Data Storage
   - Integration Interfaces
   - Security (from Step 5)
   - Scalability

7. **Appendix**
   - Object Relationship Diagram
   - State Machine Diagram
   - API Interface List
   - Completeness Checklist

**Metadata to include:**
```markdown
# 详细设计

**项目名称**: [From PRD]
**版本**: 1.0
**创建日期**: [Current date]
**创建者**: Enterprise Architect AI
**状态**: Draft
**基于**: Domain Model v[version], PRD v[version]
**生成时间**: [timestamp]
```

Write to: `{output_folder}/Architecture.md`

## Quality Standards

### Completeness
- ✅ All three layers documented (Business Objects, Business Logic, Interaction Design)
- ✅ All PRD requirements addressed
- ✅ All domain entities mapped to business objects
- ✅ All business rules mapped to business logic
- ✅ All user intents have intent configuration
- ✅ Security architecture defined
- ✅ Quality attributes documented

### Clarity
- ✅ Business objects clearly defined with attributes and relationships
- ✅ Business logic operations have clear execution steps
- ✅ Interaction cards have detailed UI layouts
- ✅ Intent configuration includes keywords and similar questions
- ✅ Diagrams included for complex concepts
- ✅ Technical terms defined
- ✅ Sections well-organized

### Consistency
- ✅ Business logic references valid business objects
- ✅ Interaction cards display data from business objects
- ✅ Intent configuration triggers valid business logic
- ✅ Card events trigger valid business logic
- ✅ Data model consistent with domain entities
- ✅ Terminology consistent across document
- ✅ Naming conventions consistent across all three layers

### Actionability
- ✅ Business objects have complete attribute definitions
- ✅ Business logic has explicit input/output contracts
- ✅ Interaction cards have detailed UI specifications
- ✅ Intent configuration covers all user intents
- ✅ All P0 features have corresponding architecture elements
- ✅ Error handling documented for all operations

## Error Handling

### Inputs Incomplete

If domain model or PRD incomplete:

```markdown
⚠️ Inputs Incomplete

Missing from Domain Model:
- [Section 1]
- [Section 2]

Missing from PRD:
- [Section 1]
- [Section 2]

Cannot generate architecture without complete inputs.

**Recommendation**: Complete domain model and PRD before generating architecture.
```

### Requirements Unclear

If requirements ambiguous or conflicting:

```markdown
⚠️ Requirements Unclear

Ambiguous requirements:
- [Requirement 1]: [What's unclear]
- [Requirement 2]: [What's unclear]

Conflicting requirements:
- [Requirement A] vs [Requirement B]: [Description of conflict]

**Recommendation**: Clarify requirements before proceeding.
```

## Integration with Base architecture-designer

This skill **fully integrates** the base `architecture-designer` skill:

**Core Compatibility**:
- ✅ Uses exact same three-layer architecture (Business Objects, Business Logic, Interaction Design)
- ✅ Follows same output structure and template format
- ✅ Includes all architecture-designer core concepts (intent configuration, card events, business logic triggering)
- ✅ Can be used as drop-in replacement when domain model and PRD available

**Enterprise Enhancements**:
- ✅ Reads from domain model and PRD (not interactive questions)
- ✅ Adds security architecture section
- ✅ Adds quality attributes section (performance, scalability, availability, maintainability)
- ✅ Provides enterprise-grade validation and completeness checks
- ✅ Maintains traceability to domain model and PRD

**Key Differences**:
- ❌ No interactive questions (reads from pre-built domain model and PRD)
- ❌ No AskUserQuestion interactions
- ✅ Same three-layer design approach
- ✅ Same intent configuration with keywords and similar questions
- ✅ Same business logic triggering mechanisms (User Intent + Card Event)

**When to use which**:
- Use `architecture-designer`: Interactive design, single agent architecture, need user clarification
- Use `domain-arch-designer`: Enterprise projects, domain model and PRD exist, part of end-to-end workflow

## Example Usage

```yaml
# Called by Claude (Design Coordinator) in Phase 3

skill: domain-arch-designer
input:
  domain_model_path: "{project-root}/_bmad/_memory/domain-consultant-sidecar/memories.md"
  prd_path: "{output_folder}/PRD.md"
  output_path: "{output_folder}/Architecture.md"
  project_name: "Warehouse Management System"
```

**Expected output**: `Architecture.md` (or `详细设计.md`) with complete three-layer architecture:
- Layer 1: Business Objects (Data Model)
- Layer 2: Business Logic (Operations) with trigger sources
- Layer 3: Interaction Design (Cards + Intent Configuration)
- Technical Considerations (Security, Performance, Scalability)
- Architecture Diagram and Appendix

## Resources

### references/output-template.md
Complete architecture output template from architecture-designer. Load when assembling final architecture document to ensure correct structure and format.

---

**Skill Type**: Document Generator
**Module**: enterprise-architect
**Phase**: Documentation (Phase 3)
**Input**: Domain Model (from Arthur's sidecar), PRD.md
**Output**: Architecture.md (Three-layer architecture with enterprise quality attributes)
**Compatible with**: architecture-designer (same three-layer design)
