---
name: 'step-e-01-assess'
description: '评估现有文档状态'
---

# Edit Mode - Step 1: Assess Existing Documents

## STEP GOAL

评估现有的产品说明书和详细设计，识别需要编辑的内容，为后续编辑做准备。

## EXECUTION PROTOCOLS

### Protocol 1: Load Existing Documents

**Load documents from output folder:**

1. **Load 产品说明书.md:**
   - Path: `{output_folder}/enterprise-architect/{project-name}/产品说明书.md`
   - Verify document exists
   - Check document structure (Part 1 + Part 2)

2. **Load 详细设计.md:**
   - Path: `{output_folder}/enterprise-architect/{project-name}/详细设计.md`
   - Verify document exists
   - Check document structure (three-layer architecture)

3. **Load domain model (optional):**
   - Path: `{project-root}/_bmad/_memory/domain-consultant-sidecar/memories.md`
   - For reference if needed

**Present document summary:**
```
【文档评估 - 现有文档】

已找到以下文档：

✅ 产品说明书.md
   - 第一部分：产品需求 ([X] 字)
   - 第二部分：交互设计 ([Y] 字)
   - 总计: [Z] 字

✅ 详细设计.md
   - 总计: [W] 字

准备进行文档评估...
```

### Protocol 2: Document Structure Analysis

**Analyze 产品说明书.md:**

Check for:
- [ ] Part 1 (Requirements) completeness
- [ ] Part 2 (Interaction) completeness
- [ ] Section consistency
- [ ] Missing sections
- [ ] Formatting issues

**Analyze 详细设计.md:**

Check for:
- [ ] Business Objects Layer completeness
- [ ] Business Logic Layer completeness
- [ ] Interaction Design Layer completeness
- [ ] Technical decisions documented
- [ ] Missing sections
- [ ] Formatting issues

**Present analysis results:**
```
【文档结构分析】

产品说明书.md:
✅ 完整的部分: [列表]
⚠️ 不完整的部分: [列表]
❌ 缺失的部分: [列表]

详细设计.md:
✅ 完整的部分: [列表]
⚠️ 不完整的部分: [列表]
❌ 缺失的部分: [列表]
```

### Protocol 3: Content Quality Assessment

**Assess content quality:**

**产品说明书.md:**
- Clarity: [评分 1-5]
- Completeness: [评分 1-5]
- Consistency: [评分 1-5]
- Issues found: [问题列表]

**详细设计.md:**
- Clarity: [评分 1-5]
- Completeness: [评分 1-5]
- Technical depth: [评分 1-5]
- Issues found: [问题列表]

### Protocol 4: Identify Edit Opportunities

**Based on assessment, identify what can be edited:**

**产品说明书.md:**
- [ ] Add missing requirements
- [ ] Clarify ambiguous descriptions
- [ ] Update user stories
- [ ] Enhance interaction design
- [ ] Fix formatting issues
- [ ] Other: [specify]

**详细设计.md:**
- [ ] Add missing architecture details
- [ ] Update technical decisions
- [ ] Enhance API documentation
- [ ] Add deployment details
- [ ] Fix formatting issues
- [ ] Other: [specify]

**Present edit opportunities:**
```
【可编辑内容】

我发现以下内容可以编辑或改进：

产品说明书.md:
1. [编辑机会 1]
2. [编辑机会 2]
3. [编辑机会 3]

详细设计.md:
1. [编辑机会 1]
2. [编辑机会 2]
3. [编辑机会 3]

您想编辑哪些内容？
```

### Protocol 5: User Input

**Ask user what they want to edit:**

```
请告诉我您想要：

1. 编辑产品说明书的哪个部分？
   - 第一部分：产品需求
   - 第二部分：交互设计
   - 两部分都编辑

2. 编辑详细设计的哪个部分？
   - 业务对象层
   - 业务逻辑层
   - 交互设计层
   - 其他部分

3. 具体要做什么修改？
   - 添加新内容
   - 修改现有内容
   - 删除内容
   - 重组结构

请描述您的编辑需求...
```

Wait for user input.

### Protocol 6: Prepare Edit Context

**Based on user input, prepare edit context:**

```yaml
edit_context:
  target_document: "产品说明书.md" | "详细设计.md"
  target_section: "[section name]"
  edit_type: "add" | "modify" | "delete" | "restructure"
  user_requirements: "[user description]"
  current_content: "[current content of target section]"
```

Save edit context to sidecar for next step.

### Protocol 7: Summary and Transition

**Present assessment summary:**

```
【评估完成】

目标文档: [文档名称]
目标部分: [部分名称]
编辑类型: [编辑类型]

我已经准备好进行编辑。接下来我将：
1. 根据您的需求修改文档
2. 保持文档格式和结构
3. 确保修改后的内容与其他部分一致

准备好继续了吗？
```

Wait for user confirmation.

## MENU OPTIONS

Display: "**Select an Option:** [C] Continue to Edit | [R] Re-assess | [S] Save and Exit"

- IF C: Load step-e-02-edit.md with edit context
- IF R: Return to Protocol 2 for re-assessment
- IF S: Save assessment results and exit

## SUCCESS METRICS

✅ Both documents loaded successfully
✅ Document structure analyzed
✅ Content quality assessed
✅ Edit opportunities identified
✅ User input collected
✅ Edit context prepared
✅ Ready to proceed to editing

---

**Step Created**: 2026-01-27
**Mode**: Edit
**Next Step**: step-e-02-edit.md
