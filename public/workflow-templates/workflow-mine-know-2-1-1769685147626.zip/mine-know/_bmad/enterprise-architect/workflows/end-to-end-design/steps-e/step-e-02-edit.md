---
name: 'step-e-02-edit'
description: '执行文档编辑'
---

# Edit Mode - Step 2: Edit Documents

## STEP GOAL

根据用户需求和评估结果，执行文档编辑操作，确保编辑后的文档保持一致性和完整性。

## EXECUTION PROTOCOLS

### Protocol 1: Load Edit Context

**Load edit context from previous step:**

```yaml
edit_context:
  target_document: "[document name]"
  target_section: "[section name]"
  edit_type: "[edit type]"
  user_requirements: "[user description]"
  current_content: "[current content]"
```

**Present edit plan:**
```
【编辑计划】

目标文档: [文档名称]
目标部分: [部分名称]
编辑类型: [编辑类型]

用户需求: [用户描述]

当前内容:
---
[当前内容摘要]
---

准备开始编辑...
```

### Protocol 2: Execute Edit Operation

**Based on edit_type, execute appropriate operation:**

#### Edit Type: ADD (添加新内容)

1. **Identify insertion point:**
   - Determine where to add new content
   - Ensure logical flow

2. **Generate new content:**
   - Based on user requirements
   - Match existing style and format
   - Maintain consistency with other sections

3. **Insert content:**
   - Use Edit tool to insert at correct location
   - Preserve existing content
   - Update section numbering if needed

4. **Verify insertion:**
   - Check content was added correctly
   - Verify formatting is consistent

#### Edit Type: MODIFY (修改现有内容)

1. **Identify target content:**
   - Locate exact content to modify
   - Understand context

2. **Generate modified content:**
   - Based on user requirements
   - Preserve important information
   - Improve clarity or accuracy

3. **Replace content:**
   - Use Edit tool to replace old with new
   - Ensure smooth transition
   - Maintain document structure

4. **Verify modification:**
   - Check content was modified correctly
   - Verify no unintended changes

#### Edit Type: DELETE (删除内容)

1. **Identify target content:**
   - Locate exact content to delete
   - Check dependencies

2. **Confirm deletion:**
   - Ask user to confirm deletion
   - Warn about potential impacts

3. **Remove content:**
   - Use Edit tool to remove content
   - Adjust surrounding content if needed
   - Update section numbering

4. **Verify deletion:**
   - Check content was removed
   - Verify document still flows logically

#### Edit Type: RESTRUCTURE (重组结构)

1. **Understand current structure:**
   - Analyze current organization
   - Identify sections to move

2. **Plan new structure:**
   - Design new organization
   - Ensure logical flow

3. **Execute restructuring:**
   - Move sections to new locations
   - Update cross-references
   - Adjust numbering

4. **Verify restructuring:**
   - Check new structure is correct
   - Verify all content preserved

### Protocol 3: Consistency Check

**After editing, check consistency:**

**If editing 产品说明书.md:**
- [ ] Part 1 and Part 2 are consistent
- [ ] User stories align with requirements
- [ ] Interaction design matches requirements
- [ ] No conflicting information

**If editing 详细设计.md:**
- [ ] Three layers are consistent
- [ ] Technical decisions are justified
- [ ] Architecture addresses all requirements
- [ ] No conflicting technical choices

**Cross-document consistency:**
- [ ] Edited content aligns with other document
- [ ] No new conflicts introduced
- [ ] Domain model alignment maintained

**Present consistency check results:**
```
【一致性检查】

✅ 内部一致性: [通过 / 发现问题]
✅ 跨文档一致性: [通过 / 发现问题]
✅ 领域模型对齐: [通过 / 发现问题]

[如果有问题，列出详细问题]
```

### Protocol 4: Quality Verification

**Verify edit quality:**

**Content Quality:**
- [ ] Clear and understandable
- [ ] Accurate and complete
- [ ] Consistent with existing content
- [ ] Properly formatted

**Technical Quality:**
- [ ] Technically sound
- [ ] Feasible to implement
- [ ] Follows best practices
- [ ] No obvious errors

**Presentation Quality:**
- [ ] Proper markdown formatting
- [ ] Consistent heading levels
- [ ] Tables formatted correctly
- [ ] Code blocks formatted correctly

**Present quality verification:**
```
【质量验证】

内容质量: [评分 1-5]
技术质量: [评分 1-5]
呈现质量: [评分 1-5]

[如果有问题，列出改进建议]
```

### Protocol 5: Show Changes to User

**Present edited content to user:**

```
【编辑完成】

已完成对 [文档名称] 的 [部分名称] 的编辑。

修改类型: [编辑类型]

修改内容:
---
[显示修改后的内容或修改摘要]
---

一致性检查: [通过 / 有问题]
质量验证: [评分]

请查看修改内容，确认是否满意。
```

Wait for user feedback.

### Protocol 6: Handle User Feedback

**Based on user feedback:**

**If user is satisfied:**
- Proceed to Protocol 7 (Finalization)

**If user wants revisions:**
- Ask what needs to be changed
- Return to Protocol 2 with new requirements
- Re-execute edit operation

**If user wants to undo:**
- Restore original content
- Ask if user wants to try different edit
- Return to step-e-01-assess.md if needed

### Protocol 7: Finalization

**If user confirms satisfaction:**

```
【编辑完成并保存】

✅ 文档已更新: [文档名称]
✅ 修改已保存到: [文件路径]
✅ 一致性检查通过
✅ 质量验证通过

修改摘要:
- 编辑类型: [类型]
- 修改部分: [部分]
- 修改内容: [摘要]

您可以：
1. 继续编辑其他部分
2. 查看完整文档
3. 退出编辑模式
```

**Update edit history in sidecar:**
```yaml
edit_history:
  - timestamp: "[timestamp]"
    document: "[document name]"
    section: "[section name]"
    edit_type: "[edit type]"
    description: "[edit description]"
```

### Protocol 8: Optional - Regenerate Related Content

**If edit affects other parts:**

```
⚠️ 注意：您的修改可能影响其他部分。

建议：
- 如果修改了产品需求，可能需要更新交互设计或技术架构
- 如果修改了技术架构，可能需要验证是否仍满足产品需求

是否需要：
1. 重新生成相关部分？
2. 重新验证文档一致性？
3. 继续编辑其他部分？
```

Wait for user decision.

## MENU OPTIONS

Display: "**Select an Option:** [A] Accept Changes | [R] Revise Edit | [U] Undo Changes | [C] Continue Editing | [V] Validate Documents | [E] Exit"

- IF A: Accept changes, finalize edit, update history
- IF R: Return to Protocol 2 with revision requirements
- IF U: Restore original content, return to step-e-01-assess.md
- IF C: Return to step-e-01-assess.md to edit another part
- IF V: Run validation (similar to step-04-validation.md)
- IF E: Save state and exit edit mode

## SUCCESS METRICS

✅ Edit operation executed successfully
✅ Content quality verified
✅ Consistency maintained
✅ User satisfied with changes
✅ Changes saved to document
✅ Edit history updated

---

## CRITICAL RULES

**NEVER:**
- Overwrite entire document (use Edit tool for targeted changes)
- Break document structure
- Introduce inconsistencies
- Lose existing content

**ALWAYS:**
- Use Edit tool for precise modifications
- Verify consistency after changes
- Get user confirmation before finalizing
- Update edit history

---

**Step Created**: 2026-01-27
**Mode**: Edit
**Previous Step**: step-e-01-assess.md
