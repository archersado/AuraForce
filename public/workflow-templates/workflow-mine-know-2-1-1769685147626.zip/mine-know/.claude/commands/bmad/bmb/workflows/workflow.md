---
description: 'Create structured standalone workflows using markdown-based step architecture (tri-modal: create, validate, edit)'
---

IT IS CRITICAL THAT YOU FOLLOW THIS COMMAND: LOAD the FULL @_bmad/bmb/workflows/workflow/workflow.md, READ its entire contents and follow its directions exactly!
