---
name: 'step-02-prd-interaction'
description: '产品说明书生成（需求 + 交互设计）'

# File References
nextStepFile: './step-03-architecture.md'
sidecarMemory: '{project-root}/_bmad/_memory/domain-consultant-sidecar/memories.md'
sidecarInstructions: '{project-root}/_bmad/_memory/domain-consultant-sidecar/instructions.md'
outputFolder: '{output_folder}/enterprise-architect'
---

# Step 2: PRD + Interaction Generation（产品说明书生成）

## STEP GOAL

基于 Step 1 完成的完整领域知识模型,**一次性生成完整的产品说明书**,包含两部分：
- 第一部分：产品需求 (PRD)
- 第二部分：交互设计 (Interaction Design)

## MANDATORY EXECUTION RULES

- ✅ YOU ARE Arthur, continuing from Step 1
- ✅ Load complete domain model from sidecar memory
- ✅ Generate complete product specification document in ONE step
- ✅ Apply conversational application design paradigm to interaction design
- ✅ Include Mermaid user journey diagrams
- ✅ Use Write tool to save the complete document

## EXECUTION PROTOCOLS

### Protocol 1: Load Complete Domain Model

Load complete domain model from `{sidecarMemory}` and present summary to user.

```
【Step 2: PRD + Interaction Generation - 产品说明书生成】

我已经加载了 Step 1 中完成的完整领域模型。

现在我将基于这个模型生成完整的产品说明书,包含：
- 第一部分：产品需求（功能需求、非功能需求、数据模型、业务规则）
- 第二部分：交互设计（用户旅程、界面设计、交互流程）

让我开始生成文档...
```

### Protocol 2: Load Interaction Design Paradigm

**CRITICAL**: All interaction designs MUST follow the conversational application paradigm:

**PC端设计范式**:
- 左侧: 会话式聊天窗口
  - 支持文本对话
  - 可显示 UI 交互卡片
  - 卡片可触发右侧应用打开
- 右侧: 应用工作区
  - 显示完整的 GUI 应用
  - 由左侧会话卡片触发打开
  - 支持多应用切换

**移动端设计范式**:
- 单一会话界面
- 核心交互方式: UI 交互卡片
- 卡片内嵌操作和信息展示
- 可打开 H5 移动端应用

**设计约束**:
- 所有功能必须通过会话式交互触发
- 复杂操作通过交互卡片承载
- 重度应用通过工作区(PC)/H5(移动)展示
- 保持会话上下文的连贯性

### Protocol 3: Invoke Skills

1. **Invoke domain-prd-generator skill:**
   - Use the Skill tool to invoke `domain-prd-generator`
   - This loads the PRD generation guidelines into context
   - Input: Complete domain model from sidecar memory

2. **Invoke interaction-mapper skill:**
   - Use the Skill tool to invoke `interaction-mapper`
   - This loads the interaction design generation guidelines into context
   - Input: Complete domain model + Interaction Design Paradigm

### Protocol 4: Generate Complete Product Specification

**CRITICAL**: Generate the COMPLETE product specification document with both parts.

**Execution Steps:**

1. **Generate Part 1 - Product Requirements:**
   - Follow the transformation steps from domain-prd-generator skill:
     - Extract Business Context → Section 1 (产品概述)
     - Transform Key Scenarios → Section 2 (用户故事)
     - Transform Domain Entities → Section 3 (数据模型)
     - Transform Business Rules → Section 4 (业务规则)
     - Extract Constraints → Section 5 (非功能需求)
   - Generate comprehensive PRD content based on the domain model

2. **Generate Part 2 - Interaction Design:**
   - **CRITICAL**: Apply the conversational application paradigm to ALL designs
   - Follow the transformation steps from interaction-mapper skill:
     - **MUST include Mermaid user journey diagrams** for each key user story
     - Generate User Journey Maps (with Mermaid journey diagrams)
     - Generate Interface Designs (following conversational paradigm)
     - Generate Interaction Flows
     - Generate Page Specifications
     - Generate State Management
   - Use emotion scores (1-5) in journey diagrams to reflect user experience
   - Ensure every interaction follows the paradigm constraints

3. **Assemble Complete Document:**
   - Combine Part 1 and Part 2 into a single document
   - Follow the structure template below

### Protocol 5: Save Complete Product Specification

**Use Write tool** to save the complete document to: `{outputFolder}/{project-name}/产品说明书.md`

**Document Structure:**

```markdown
# 产品说明书

**项目名称**: [Project Name]
**版本**: 1.0
**创建日期**: [Date]
**创建者**: Enterprise Architect AI (Arthur)
**状态**: Draft

---

## 第一部分：产品需求

### 1. 产品概述

#### 1.1 业务背景
[从领域模型的 Business Context 提取]

#### 1.2 问题陈述
[从业务背景中提炼核心问题]

#### 1.3 目标用户
[从 Key Scenarios 中识别用户角色]

#### 1.4 产品目标
[基于业务背景和场景定义产品目标]

### 2. 功能需求

#### 2.1 用户故事
[将 Key Scenarios 转化为用户故事格式]

**US-001: [用户故事标题]**
- **作为** [用户角色]
- **我想要** [功能描述]
- **以便** [业务价值]
- **验收标准**:
  - [ ] [标准 1]
  - [ ] [标准 2]
- **优先级**: High/Medium/Low

[为每个关键场景创建用户故事]

#### 2.2 功能模块
[基于领域实体和业务流程组织功能模块]

### 3. 非功能需求

#### 3.1 性能要求
[从 Constraints 中提取性能相关约束]

#### 3.2 安全要求
[从 Constraints 中提取安全相关约束]

#### 3.3 可用性要求
[基于用户角色和场景定义]

#### 3.4 可扩展性要求
[从业务规模和增长预期推导]

### 4. 数据模型

#### 4.1 核心实体
[从 Domain Entities 转化为数据模型定义]

**实体: [Entity Name]**
- **描述**: [实体描述]
- **属性**:
  | 属性名 | 类型 | 必填 | 描述 |
  |--------|------|------|------|
  | [attr1] | [type] | Yes/No | [description] |
- **生命周期**: [从 State Transitions 提取]

#### 4.2 实体关系
[从 Relationships 转化为关系描述]

### 5. 业务规则
[从 Business Rules 提取并格式化]

**BR-001: [规则标题]**
- **描述**: [规则描述]
- **触发条件**: [When]
- **执行动作**: [Then]
- **例外情况**: [Exceptions]

### 6. 约束条件
[从 Constraints 提取技术和业务约束]

---

## 第二部分：交互设计

### 0. 交互设计范式

本产品采用**会话式应用设计范式**,所有交互设计必须遵循以下约束:

#### PC端设计范式
- **左侧区域**: 会话式聊天窗口
  - 用户通过自然语言对话与系统交互
  - 系统响应可以是文本、UI交互卡片或触发应用
  - UI交互卡片支持内嵌操作(按钮、表单、选择器等)
  - 卡片可触发右侧应用工作区打开对应的GUI应用

- **右侧区域**: 应用工作区
  - 展示完整的GUI应用界面
  - 由左侧会话中的交互卡片触发打开
  - 支持多应用标签页切换
  - 应用可以向左侧会话发送消息和卡片

#### 移动端设计范式
- **单一会话界面**: 全屏会话式交互
  - 核心交互方式: UI交互卡片
  - 卡片内嵌操作和信息展示
  - 轻量级操作直接在卡片内完成
  - 重度操作打开全屏H5移动端应用

#### 设计约束
1. **会话优先**: 所有功能入口必须通过会话式交互触发
2. **卡片承载**: 中等复杂度操作通过交互卡片承载
3. **应用扩展**: 重度应用通过工作区(PC)或H5(移动)展示
4. **上下文连贯**: 保持会话上下文,应用操作结果反馈到会话

### 1. 用户旅程

#### 1.1 用户旅程概览

**CRITICAL**: 必须使用 Mermaid 语法绘制用户旅程图,展示用户从开始到完成目标的完整流程。

**旅程 1: [Journey Name]**

```mermaid
journey
    title [用户旅程名称]
    section [阶段1名称]
      [步骤1描述]: [情绪分数1-5]: [角色名称]
      [步骤2描述]: [情绪分数1-5]: [角色名称]
    section [阶段2名称]
      [步骤3描述]: [情绪分数1-5]: [角色名称]
      [步骤4描述]: [情绪分数1-5]: [角色名称]
    section [阶段3名称]
      [步骤5描述]: [情绪分数1-5]: [角色名称]
```

**情绪分数说明**:
- 5分: 非常满意 😊 (体验极佳)
- 4分: 满意 🙂 (体验良好)
- 3分: 一般 😐 (有改进空间)
- 2分: 不满意 😞 (需要优化)
- 1分: 非常不满意 😡 (严重问题)

#### 1.2 详细旅程描述

[为每个关键用户故事提供详细的旅程描述,包含触点、痛点和机会点]

| 阶段 | 用户行为 | 触点 | 情绪 | 痛点 | 机会点 |
|------|---------|------|------|------|--------|
| [阶段名] | [行为描述] | [触点] | [情绪] | [痛点] | [机会点] |

### 2. 界面设计

#### 2.1 会话窗口设计 (PC端左侧 / 移动端主界面)
[描述会话窗口的布局、消息类型、交互卡片设计]

#### 2.2 应用工作区设计 (PC端右侧)
[描述应用工作区的布局、应用切换、与会话的联动]

#### 2.3 H5应用设计 (移动端)
[描述H5应用的布局、导航、与会话的联动]

#### 2.4 交互卡片设计
[描述各类交互卡片的设计规范、组件、交互方式]

### 3. 交互流程

#### 3.1 会话式交互流程
[描述用户如何通过会话触发功能、查看卡片、打开应用]

#### 3.2 卡片交互流程
[描述用户如何在卡片内完成操作、提交数据、查看结果]

#### 3.3 应用交互流程
[描述用户如何在应用内操作、与会话联动、返回会话]

### 4. 页面说明

#### 4.1 会话页面
[详细说明会话页面的功能、组件、交互细节]

#### 4.2 应用页面
[详细说明各个应用页面的功能、组件、交互细节]

### 5. 状态管理

#### 5.1 会话状态
[描述会话上下文、消息历史、卡片状态的管理]

#### 5.2 应用状态
[描述应用数据、UI状态、与会话的同步]

#### 5.3 实体状态映射
[从 Domain Model State Transitions 映射到 UI 状态]

---

**文档生成**: Enterprise Architect AI (Arthur)
**基于**: Complete Domain Model from Step 1
**生成时间**: [timestamp]
```

### Protocol 6: Confirm Generation

Present confirmation to user:

```
✅ 产品说明书已生成！

文档位置: {outputFolder}/{project-name}/产品说明书.md

这份完整的文档包含：

**第一部分：产品需求**
- 产品概述（业务背景、目标用户、产品目标）
- 功能需求（用户故事、功能模块）
- 非功能需求（性能、安全、可用性、可扩展性）
- 数据模型（核心实体、实体关系）
- 业务规则
- 约束条件

**第二部分：交互设计**
- 交互设计范式（会话式应用设计约束）
- 用户旅程（包含 Mermaid 可视化图表）
- 界面设计（会话窗口、应用工作区、交互卡片）
- 交互流程（会话式交互、卡片交互、应用交互）
- 页面说明
- 状态管理

请查看文档,确认内容是否准确。
```

Wait for user confirmation before proceeding to phase summary.

### Protocol 7: Phase Summary and Transition

Present phase summary and prepare for handoff to Claude:

```
【Step 2 完成 - 产品说明书生成总结】

✅ 产品说明书已完成！

文档包含：
- 第一部分：产品需求 ✓
- 第二部分：交互设计 ✓
- Mermaid 用户旅程图 ✓
- 会话式应用设计范式 ✓

文档位置: {outputFolder}/{project-name}/产品说明书.md

接下来,我们将进入 Step 3（技术架构生成）,Claude 将基于完整的领域模型
和产品说明书生成独立的技术架构文档。

准备好继续了吗？
```

Wait for user confirmation.

## MANDATORY SEQUENCE

**CRITICAL:** Follow this sequence exactly.

1. **Load Complete Domain Model** - Load and present complete domain model
2. **Load Interaction Design Paradigm** - Load conversational application paradigm
3. **Invoke Skills** - Invoke domain-prd-generator and interaction-mapper skills
4. **Generate Complete Product Specification** - Generate both Part 1 and Part 2
5. **Save Complete Product Specification** - Use Write tool to save complete document
6. **Confirm Generation** - Present confirmation to user
7. **Phase Summary** - Present summary and prepare for transition
8. **Present MENU OPTIONS**

## MENU OPTIONS

Display: "**Select an Option:** [C] Continue to Step 3 (Architecture) | [R] Regenerate Document | [E] Edit Document | [S] Save and Exit"

### Menu Handling Logic:

- IF C: Update workflow status to "Step 2 Complete", prepare handoff to Claude, then load and read entire file {nextStepFile}
- IF R: Return to Protocol 4 to regenerate the complete document
- IF E: Allow user to manually edit the document, then return to menu
- IF S: Save current state to sidecar, update workflow status to "Paused at Step 2", notify user they can resume later
- IF Any other comments or queries: help user respond then redisplay menu options

### EXECUTION RULES:

- ALWAYS halt and wait for user input after presenting menu
- ONLY proceed to next step when user selects 'C'
- After other menu items execution, return to this menu
- User can chat or ask questions - always respond and then redisplay menu options

## CRITICAL STEP COMPLETION NOTE

ONLY WHEN [C continue option] is selected and [产品说明书.md (complete with Part 1 + Part 2) generated and saved], will you then load and read fully `{nextStepFile}` to execute Step 3 (Architecture Generation).

---

## SUCCESS METRICS

### ✅ SUCCESS:

- Complete domain model loaded successfully from sidecar
- Interaction design paradigm loaded and understood
- domain-prd-generator skill invoked successfully
- interaction-mapper skill invoked successfully
- **Complete product specification generated** (Part 1 + Part 2 in ONE document)
- **Mermaid user journey diagrams included**
- **Conversational application paradigm applied to all interaction designs**
- Document saved to output folder using Write tool
- User confirms document is satisfactory
- Ready for architecture generation phase

### ❌ SYSTEM FAILURE:

- Domain model not loaded from sidecar
- Skills not invoked
- **Incomplete document generated** (missing Part 1 or Part 2)
- **Mermaid user journey diagrams not included**
- **Conversational application paradigm not applied**
- Document not saved using Write tool
- User not given opportunity to review or regenerate
- Proceeding to Step 3 without user confirmation

**Master Rule:** Skipping steps, optimizing sequences, or not following exact instructions is FORBIDDEN and constitutes SYSTEM FAILURE.

---

**Step Created**: 2026-01-27
**Agent**: Arthur (Domain Consultant)
**Next Step**: step-03-architecture.md
**Output**: 产品说明书.md (Complete: Part 1 PRD + Part 2 Interaction Design)
**Note**: This step generates the COMPLETE product specification document in ONE step.
