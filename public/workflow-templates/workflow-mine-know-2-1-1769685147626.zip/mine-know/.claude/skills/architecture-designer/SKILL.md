---
name: architecture-designer
description: "Design complete Single Agent Architecture including business objects, business logic, and interaction design. ⚠️ CRITICAL: When triggered by prd-generator, IMMEDIATELY read the requirements document and generate design without asking user questions. Use when designing a complete system architecture for existing requirements."
allowed-tools: Read, Write, Edit, Glob, Grep
keywords:
  - architecture design
  - business objects
  - business logic
  - interaction design
  - system design
  - data model
  - workflows
  - intent configuration
  - intent recognition
---

# Architecture Designer

Design comprehensive Single Agent Architecture by integrating three key design dimensions: business objects (data model), business logic (operations), and interaction design (UI and events).

## When to Use This Skill

**Context:** Typically invoked by `prd-generator` in Stage 2, after user stories and features are defined.
**Standalone usage:** Use independently when designing a complete system architecture for existing requirements.

---

# 🚨 CRITICAL - Execution Rule

## When Triggered by prd-generator (Stage 2)

**IMMEDIATELY execute Step 1 → Step 2 → Step 3, WITHOUT asking user questions:**

**Step 1 (≤0.5秒): Read Requirements Document**
- Use Glob to find `*_产品需求.md` file
- Use Read to read the product requirements document
- Extract: feature list, core business logic, user journey, business rules

**Step 2 (≤1秒): Analyze and Design Architecture**
- Design Business Objects: identify entities, attributes, relationships
- Design Business Logic: define operations, workflows, validation rules
- Design Interaction Cards: create UI components, parameters, events
- Design Intent Configuration: keywords, similar questions, triggered logic

**Step 3 (≤0.5秒): Generate Design Document**
- Use Write to create `详细设计.md`
- Include all architecture sections
- NO conversation, NO questions, NO delays

**🚨 Execution Requirements:**
- 🚨 **DO NOT ask user any questions**
- 🚨 **DO NOT display progress messages**
- 🚨 **Only use Glob → Read → Write tools**
- 🚨 Complete generation in a single operation

---

## Intent Configuration ( Critical for Agent Intent Recognition )

Business logic can be triggered in two ways:

1. **User Intent Triggering**: Through natural language interaction
   - Keywords define what users can say to trigger actions
   - The Agent uses keywords to recognize user requests
   - Intent Configuration maps user input to business logic

2. **Card Event Triggering**: Through UI interactions
   - Card initialization events (onInit) - e.g., loading data when card displays
   - Card submission events (onSubmit) - e.g., processing form data
   - Custom card events - e.g., button clicks, field changes

Both triggering mechanisms must be clearly documented in the architecture design.

**Intent Structure Requirements:**
Each intent must include:
- **Intent Name**: Name of the intent
- **Intent Description**: Description of the user's purpose and scenario
- **Matching Keywords**: Keywords that directly trigger the intent (comma-separated)
- **Similar Questions**: Natural language variations users might ask (one per line)
- **Triggered Business Logic**: Business logic operations to invoke
- **Displayed Interaction Cards**: Cards to show to the user

---

## Input Requirements

1. **Feature List**: Core features and priorities
2. **Core Business Logic Summary**: High-level workflow description
3. **User Journey**: User personas and interaction patterns
4. **Business Rules**: Constraints and validation requirements

---

## Workflow (When Triggered by prd-generator)

### Step 1: Analyze Inputs (Immediately execute, no questions)

Analyze product requirements document holistically to identify:

**Data Layer (Business Objects):**
- Nouns representing domain entities
- Data that persists across sessions
- Relationships between entities

**Logic Layer (Business Logic):**
- Verbs/Actions from features
- Workflows spanning multiple steps
- Business rules and validation logic

**Presentation Layer (Interaction Design):**
- User-facing touchpoints
- User actions that trigger logic
- Events connecting UI to business logic

### Step 2: Design Architecture (Immediately execute, no questions)

**Design Business Objects:**
- Identify all entities from requirements
- Define attributes for each entity
- Define relationships between entities
- Add validation rules
- Create example data

**Design Business Logic:**
- Define operations for each feature
- Specify input parameters
- Specify output results
- Define step-by-step workflows
- Define business rules and validation
- Handle exceptions

**Design Interaction Cards:**
- Create card components for each major interaction
- Define input parameters
- Define output events
- Define layout structure
- Specify UI elements

**Design Intent Configuration:**
- Define intents for each user action
- Add matching keywords
- Add similar questions (natural language variations)
- Map intents to business logic
- Map intents to interaction cards

### Step 3: Generate Document (Immediately execute, no questions)

**Generate Detailed Design Document:**
- Use Write tool to create `详细设计.md`
- Include all sections: Architecture Overview, Business Objects, Business Logic, Interaction Cards, Intent Configuration, Data Flow Diagram, Technical Considerations
- NO intermediate output
- NO questions
- Complete in a single Write operation

---

## Design Guidelines

### Layer 1: Business Objects (Data Model)

For each business object, define:

**Object Structure:**
- **Name**: Singular noun (e.g., "User", not "Users")
- **Description**: What this object represents
- **Attributes**: name, data type, required, default, description
  - Always include: id, createdAt, updatedAt, status
- **Validation Rules**: Format, range, business constraints
- **Relationships**: How this object relates to others

**Design Guidelines:**
- ✅ Include standard metadata (id, timestamps, status)
- ✅ Define clear data types and validation rules
- ✅ Document relationships (one-to-one, one-to-many, many-to-many)
- ❌ Don't over-engineer with unnecessary attributes
- ❌ Don't include UI-specific fields

#### Layer 2: Business Logic (Operations)

For each business operation, define:

**Logic Structure:**
- **Name**: Verb-based (e.g., "CreateOrder", "ProcessPayment")
- **Description**: What it does and when invoked
- **Input Parameters**: name, type, required, description
- **Output Parameters**: name, type, description
- **Logic Steps**: Step-by-step workflow (validate → check rules → perform operations → update state → return)
- **Business Rules**: Constraints that must be satisfied
- **Error Handling**: Validation errors, business rule violations, system errors

**Output Format Requirements:**
Each logic operation must include:
```markdown
**Description:** [What this logic does]

**Input Parameters:**

| Parameter Name | Data Type | Required | Description |
|----------------|-----------|----------|-------------|
| [param] | [type] | [Yes/No] | [Description] |

**Output Parameters:**

| Parameter Name | Data Type | Description |
|----------------|-----------|-------------|
| [output] | [type] | [Description] |
| success | boolean | Whether operation succeeded |
| message | string | Result message |

**Execution Steps:**

1. **[Step 1 Name]**
   - Action: [What it does]
   - Judgment: [Condition to check]
   - Result: [What it produces]

2. **[Step 2 Name]**
   - Action: [What it does]
   - Judgment: [Condition to check]
   - Result: [What it produces]

**Business Rules:**
- **Rule 1:** [Rule description and scenario]
- **Rule 2:** [Rule description and scenario]

**Exception Handling:**

| Exception Type | Trigger Condition | Handling | Error Code |
|----------------|-------------------|----------|------------|
| [Error 1] | [Condition] | [Handling] | [ERR_CODE] |

**Called Operations:**
- [Logic Name]: [Usage scenario]

**Modified Objects:**
- [Object Name]: [How it's modified]
```

**Design Guidelines:**
- ✅ Name with clear action verbs
- ✅ Define explicit input/output contracts
- ✅ Reference business objects by name
- ✅ Consider state transitions
- ✅ Document error scenarios
- ❌ Don't include implementation details (code, SQL)
- ❌ Don't mix multiple responsibilities

#### Layer 3: Interaction Design (UI & Intent)

For each user-facing interaction, define:

**Interaction Cards:**
- **Name**: Descriptive (e.g., "OrderSummaryCard")
- **Description**: Purpose and functionality
- **Input Parameters**: Data needed to render
- **Events Emitted**: User actions (button clicks, form submits)
- **Card Events**: Lifecycle and interaction events that trigger business logic
  - Custom events: Domain-specific events (e.g., onItemSelected, onRefresh)
- **UI/UX Requirements**: Layout, elements, behaviors, accessibility

**Intent Configuration:**

For each intent, define:
- **Intent Name**: Clear intent name (e.g., "OnCreateOrder", "OnSearchProducts")
- **Intent Description**: User's purpose and scenario
- **Matching Keywords**: Keywords that directly trigger the intent (comma-separated)
  - Example: `borrow, reserve, lend`
- **Similar Questions**: Natural language variations (one per line)
  - Example:
    ```
    I want to borrow this book
    Can I borrow it?
    How do I borrow books
    Help me reserve a book
    ```
- **Triggered Business Logic**: Operations to call with parameters
- **Displayed Interaction Cards**: Cards to show with parameters
- **Priority**: High/Medium/Low

**Intent Configuration Best Practices:**
- ✅ Define clear matching keywords for each intent
- ✅ Map intents to business logic operations or card display
- ✅ Specify trigger source for each business logic (User Intent or Card Event)
- ✅ Document card events (onInit, onSubmit, custom events) that trigger logic
- ✅ Cover ALL user intents from feature list
- ✅ Include similar questions with various natural language patterns
- ✅ Consider both UI-triggered and conversational intents
- ❌ Don't miss any user intents - incomplete events mean Agent won't understand requests

### Step 4: Validate Consistency

**Data Flow Validation:**
- Every operation references valid business objects
- Every card displays data from business objects
- Every intent triggers valid operations
- Logic outputs match card input parameters

**Naming Consistency:**
- Use consistent naming conventions across layers
- Business objects referenced by same name everywhere
- Logic operations referenced by events use exact names

**Completeness Check:**
- All P0 features have corresponding logic and UI
- All business objects have CRUD operations (if applicable)
- All user actions have event handlers
- All user intents from feature list have corresponding events with keywords and similar questions

### Step 5: Generate Output

Generate structured output using the template in `references/output-template.md`.

**Output File Name:** `详细设计.md`

The output should include:
- Complete business object definitions
- Business logic operations with clear trigger mechanisms (User Intent or Card Events)
- Interaction cards with card events (onInit, onSubmit, etc.)
- Intent configuration mapping user intents and card events to business logic

---

## Design Patterns

### Common Patterns

**E-commerce:**
- Objects: User, Product, Order, Cart, Payment
- Logic: AddToCart, CreateOrder, ProcessPayment, TrackShipment
- Cards: ProductListCard, CartSummaryCard, CheckoutFormCard
- Intents: AddToCart, Checkout, Payment

**Content Management:**
- Objects: User, Article, Category, Tag, Comment
- Logic: CreateArticle, PublishArticle, AddComment, SearchArticles
- Cards: ArticleListCard, ArticleEditorCard, CommentThreadCard
- Intents: CreateArticle, Publish, AddComment

**Library Management:**
- Objects: User, Book, BorrowRecord, Category, Notification
- Logic: ReserveBook, BorrowBook, ReturnBook, RenewBook
- Cards: BookListCard, BookDetailCard, MyBorrowsCard
- Intents: ReserveBook, ReturnBook, RenewBook

---

## Integration with PRD Generator

When invoked by `prd-generator`:

1. Receives feature list, business logic summary, and user journey from Stage 1
2. IMMEDIATELY reads the requirements document using Glob and Read
3. IMMEDIATELY designs business objects, logic, and interactions
4. IMMEDIATELY generates complete architecture specification
5. Uses Write tool to create `详细设计.md`
6. NO intermediate questions, NO delays
7. Complete in a single operation

---

## References

- [Output Template](references/output-template.md) - Structured format for complete architecture
- [Design Examples](references/design-examples.md) - Example architectures for common domains

---

**Version:** 2.4 (CRITICAL FIX - Remove user questions when triggered by prd-generator)
**Created:** 2026-01-21
**Updated:** 2026-01-26 (Fixed to generate design without asking questions)
**Part of:** prd-generator ecosystem

**Major Changes:**
- v2.4 (2026-01-26): 🚨 CRITICAL修复 - 移除用户提问，改为直接生成
  - 移除AskUserQuestion工具，改为只使用Read/Write/Glob/Grep
  - 添加明确的执行规则：Step 1 → Step 2 → Step 3，不提问
  - 将原来的"Step 2: Ask Clarifying Questions"改为"Step 2: Design Architecture"
  - 强调"NO questions, NO delays"
  - 修改description，明确"IMMEDIATELY read the requirements document and generate design without asking user questions"
- v2.3 (2026-01-24): 改进架构设计流程
