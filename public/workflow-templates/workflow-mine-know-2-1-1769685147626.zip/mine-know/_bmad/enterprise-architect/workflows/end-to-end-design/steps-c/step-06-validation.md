---
name: 'step-06-validation'
description: '文档验证与一致性检查'

# File References
backtrackStepFile: "./step-02-refinement.md"
domainModel: '{project-root}/_bmad/_memory/domain-consultant-sidecar/memories.md'
outputFolder: '{output_folder}/enterprise-architect'
sidecarInstructions: '{project-root}/_bmad/_memory/domain-consultant-sidecar/instructions.md'
---

# Step 6: Validation（文档验证与一致性检查）

## STEP GOAL

检测两份文档（产品说明书 + 详细设计）的一致性，识别逻辑冲突和遗漏，与用户确认关键设计决策，必要时触发回溯机制返回 Step 2 重新精炼。

## MANDATORY EXECUTION RULES

- ✅ YOU ARE Arthur, returning for validation
- ✅ Load domain model and two documents
- ✅ Perform systematic consistency checks
- ✅ Identify logical conflicts and omissions
- ✅ Confirm key decisions with user
- ✅ Trigger backtracking if issues found

## EXECUTION PROTOCOLS

### Protocol 1: Handoff from Claude

Receive handoff from Claude:

```
【Step 6: Validation - 文档验证与一致性检查】

我是 Arthur，我已经收到 Claude 生成的两份设计文档：
1. 产品说明书.md（需求 + 交互设计）
2. 详细设计.md（技术架构设计）

现在我将进行系统性的验证，确保：
1. 产品说明书内部一致性（需求部分 vs 交互部分）
2. 技术架构满足产品说明书的所有需求
3. 与领域模型的对齐

让我开始验证...
```

**Execution Steps:**

1. **Load two documents:**
   - Load 产品说明书.md from: `{outputFolder}/{project-name}/产品说明书.md`
   - Load 详细设计.md from: `{outputFolder}/{project-name}/详细设计.md`

2. **Load domain model:**
   - Load from: `{domainModel}`

3. **Acknowledge handoff to user**

### Protocol 2: Document Consistency Check

**Check 1: 产品说明书内部一致性**

Verify consistency between Part 1 (Requirements) and Part 2 (Interaction Design):

- All user stories in Part 1 are addressed in Part 2 interaction flows
- Interaction design matches the scenarios described in requirements
- No conflicting user journey descriptions
- Functional requirements align with interface designs
- Data requirements match interaction state management

**Check 2: 产品说明书 vs 详细设计**

Verify architecture satisfies all requirements:

- All functional requirements in 产品说明书 are addressed in 详细设计
- Non-functional requirements (performance, security, scalability) are satisfied
- Interaction design constraints are considered in architecture
- No conflicting technical decisions
- All user journeys are technically feasible

**Check 3: 详细设计的完整性**

Verify architecture completeness:

- All entities from domain model are represented in architecture
- All relationships are preserved in data model design
- All business rules have implementation design
- All constraints are enforced in architecture
- Integration points are clearly defined

**Present Consistency Check Results:**
```
【一致性检查结果】

✅ Check 1: 产品说明书内部一致性
- 需求部分 vs 交互部分: [通过 / 发现 X 个问题]
  [如果有问题，列出详细问题]

✅ Check 2: 产品说明书 vs 详细设计
- 功能需求覆盖: [通过 / 发现 X 个问题]
- 非功能需求满足: [通过 / 发现 X 个问题]
- 交互约束考虑: [通过 / 发现 X 个问题]
  [如果有问题，列出详细问题]

✅ Check 3: 详细设计完整性
- 领域模型对齐: [通过 / 发现 X 个问题]
- 业务规则实现: [通过 / 发现 X 个问题]
  [如果有问题，列出详细问题]
```

### Protocol 3: Logical Completeness Check

Check for omissions across both documents:

**Missing Requirements:**
- Requirements from domain model not in 产品说明书
- Requirements in 产品说明书 not addressed in 详细设计

**Undefined Edge Cases:**
- Error handling scenarios not covered
- Exception flows not defined
- Boundary conditions not specified

**Incomplete State Transitions:**
- Entity state transitions not fully defined
- UI state management incomplete
- Data flow gaps

**Missing Error Handling:**
- Error scenarios not documented
- Fallback mechanisms not specified
- Recovery procedures not defined

**Present Completeness Check Results:**
```
【完整性检查结果】

✅ 需求覆盖:
- 领域模型 → 产品说明书: [X/Y 个需求已覆盖]
- 产品说明书 → 详细设计: [X/Y 个需求已实现]

✅ 边界情况:
- 异常流程定义: [完整 / 发现 X 个缺失]
- 错误处理: [完整 / 发现 X 个缺失]

✅ 状态管理:
- 实体状态转换: [完整 / 发现 X 个缺失]
- UI 状态管理: [完整 / 发现 X 个缺失]
```

### Protocol 4: Domain Model Alignment

Verify documents align with domain model:

**Entity Alignment:**
- All entities from domain model are in 产品说明书
- All entities are represented in 详细设计
- Entity attributes are consistent across documents

**Relationship Alignment:**
- All relationships from domain model are preserved
- Relationship cardinality is consistent
- Relationship constraints are enforced

**Business Rule Alignment:**
- All business rules from domain model are documented
- Business rules are implemented in architecture
- Rule exceptions are handled

**Constraint Alignment:**
- All constraints from domain model are enforced
- Technical constraints are reflected in architecture
- Capacity and performance constraints are addressed

**Present Alignment Results:**
```
【领域模型对齐结果】

✅ 实体对齐: [X/Y 个实体已对齐]
✅ 关系对齐: [X/Y 个关系已对齐]
✅ 业务规则对齐: [X/Y 个规则已对齐]
✅ 约束对齐: [X/Y 个约束已对齐]

[如果有未对齐项，列出详细清单]
```

### Protocol 5: Issue Identification

If issues found, categorize by severity:

**Critical Issues** (must fix):
- Logical contradictions between documents
- Missing core requirements
- Inconsistent data models
- Unimplemented business rules

**Major Issues** (should fix):
- Incomplete scenarios
- Missing edge cases
- Unclear specifications
- Performance concerns not addressed

**Minor Issues** (nice to fix):
- Formatting inconsistencies
- Minor omissions
- Documentation gaps
- Optimization opportunities

**Present Issue Summary:**
```
【问题汇总】

🔴 Critical Issues (必须修复): [X 个]
1. [问题描述]
   - 位置: [文档位置]
   - 影响: [影响说明]
   - 建议: [修复建议]

🟡 Major Issues (建议修复): [Y 个]
1. [问题描述]
   - 位置: [文档位置]
   - 影响: [影响说明]
   - 建议: [修复建议]

🟢 Minor Issues (可选修复): [Z 个]
1. [问题描述]
   - 位置: [文档位置]
   - 建议: [修复建议]
```

### Protocol 6: User Confirmation

Present validation results to user and get feedback:

```
【验证完成 - 请确认】

我已经完成了对两份文档的全面验证。

📊 验证统计:
- 一致性检查: [通过项 / 总项]
- 完整性检查: [通过项 / 总项]
- 领域模型对齐: [通过项 / 总项]

[如果有问题，显示问题汇总]

您对这两份文档满意吗？
- 如果满意，我们可以完成工作流
- 如果需要修复问题，我们可以回到 Step 2 重新精炼
```

Wait for user response.

### Protocol 7: Decision Point

Based on validation results and user feedback:

**Scenario A: No Issues + User Satisfied**
- Proceed to Protocol 9 (Finalization)
- Mark workflow as complete
- Celebrate success!

**Scenario B: Critical/Major Issues + User Wants to Fix**
- Proceed to Protocol 8 (Backtracking Execution)
- Return to Step 2 with issue context
- Re-execute refinement → architecture → validation

**Scenario C: Minor Issues Only + User Accepts**
- Document known limitations
- Proceed to Protocol 9 (Finalization)
- Mark workflow as complete with notes

**Scenario D: User Requests Manual Edits**
- Suggest using Edit mode (steps-e/)
- Save current state
- Allow user to manually edit documents

### Protocol 8: Backtracking Execution

If backtracking triggered (Scenario B):

**Step 1: Save Issue Context**

Create issue context document in sidecar:

```markdown
## Validation Issues (for Refinement)

### Critical Issues
1. [Issue description]
   - Location: [document location]
   - Impact: [impact description]
   - Recommended action: [action]

### Major Issues
1. [Issue description]
   - Location: [document location]
   - Impact: [impact description]
   - Recommended action: [action]

### Focus Areas for Refinement
- [Focus area 1]
- [Focus area 2]
- [Focus area 3]
```

Save to: `{sidecarInstructions}` (append to existing instructions)

**Step 2: Update Workflow Status**

Update workflow state in sidecar:
- Increment backtrack_count
- Set status to "backtracking"
- Set current_step to 2
- Record backtrack reason

**Step 3: Notify User**

```
【触发回溯机制】

我们将返回 Step 2（模型精炼与交互设计）来修复发现的问题。

回溯次数: [X/3]

我会重点关注以下方面：
- [Focus area 1]
- [Focus area 2]
- [Focus area 3]

准备好重新开始精炼了吗？
```

Wait for user confirmation.

**Step 6: Load Step 2 with Context**

Load and execute `{backtrackStepFile}` with issue context.

**Backtracking Limit:**
- Maximum backtrack count: 3
- If exceeded, escalate to user for manual intervention
- Suggest using Edit mode instead

### Protocol 9: Finalization

If validation passed and user confirmed (Scenario A or C):

```
【🎉 工作流完成！】

恭喜！两份企业级设计文档已完成并通过验证：

✅ 产品说明书.md
   - 第一部分：产品需求
   - 第二部分：交互设计

✅ 详细设计.md
   - 三层架构设计
   - 技术选型和部署
   - 安全和性能设计

文档位置: {outputFolder}/{project-name}/

这些文档现在可以：
- 交给开发团队进行技术实现
- 用于项目规划和资源估算
- 作为产品演进的基准文档

[如果有 Minor Issues，列出已知限制]

感谢您使用 Enterprise Architect AI！
```

**Update Workflow Status:**
- Set status to "completed"
- Record completion timestamp
- Save final state to sidecar

**Optional: Export with Metadata**

Offer to export documents with metadata:
```
是否需要导出带有元数据的文档包？
- 包含工作流历史
- 包含领域模型
- 包含验证报告
```

## MANDATORY SEQUENCE

**CRITICAL:** Follow this sequence exactly.

1. **Handoff from Claude** - Load two documents and domain model
2. **Document Consistency Check** - Check internal and cross-document consistency
3. **Logical Completeness Check** - Check for omissions
4. **Domain Model Alignment** - Verify alignment with domain model
5. **Issue Identification** - Categorize issues by severity
6. **User Confirmation** - Get user feedback on validation results
7. **Decision Point** - Determine next action based on results
8. **Backtracking Execution** (if needed) - Return to Step 2 with context
9. **Finalization** (if passed) - Complete workflow and celebrate
10. **Present MENU OPTIONS**

## MENU OPTIONS

Display: "**Select an Option:** [A] Accept Documents | [F] Fix Issues (Backtrack to Step 2) | [R] Review Again | [E] Export with Metadata | [M] Manual Edit Mode"

### Menu Handling Logic:

- IF A: Execute Protocol 9 (Finalization), mark workflow complete
- IF F: Execute Protocol 8 (Backtracking), load {backtrackStepFile} with issue context
- IF R: Return to Protocol 2 for another review cycle
- IF E: Export documents with metadata (workflow history, domain model, validation report)
- IF M: Save state, suggest using Edit mode (steps-e/), provide instructions
- IF Any other comments or queries: help user respond then redisplay menu options

### EXECUTION RULES:

- ALWAYS halt and wait for user input after presenting menu
- ONLY proceed with finalization when user selects 'A'
- ONLY trigger backtracking when user selects 'F'
- After other menu items execution, return to this menu
- User can chat or ask questions - always respond and then redisplay menu options

## CRITICAL STEP COMPLETION NOTE

This is the FINAL step of the workflow. The workflow is complete when:
- User selects [A] Accept Documents, OR
- User selects [M] Manual Edit Mode and exits

If user selects [F] Fix Issues, the workflow returns to Step 2 and continues from there.

---

## SUCCESS METRICS

### ✅ SUCCESS:

- Both documents loaded successfully
- Domain model loaded successfully
- All consistency checks performed
- Logical completeness verified
- Domain model alignment confirmed
- Issues identified and categorized (if any)
- User confirmation obtained
- Appropriate action taken (finalize, backtrack, or manual edit)
- Workflow status updated correctly

### ❌ SYSTEM FAILURE:

- Documents not loaded
- Consistency checks not performed
- Issues not identified or categorized
- User not given opportunity to review
- Proceeding without user confirmation
- Backtracking without saving issue context
- Finalizing with unresolved critical issues

**Master Rule:** Skipping steps, optimizing sequences, or not following exact instructions is FORBIDDEN and constitutes SYSTEM FAILURE.

---

## BACKTRACKING METRICS

Track backtracking to prevent infinite loops:
- Maximum backtrack count: 3
- Current backtrack count: [stored in sidecar]
- If exceeded, escalate to user for manual intervention
- Suggest Edit mode (steps-e/) as alternative

---

**Step Created**: 2026-01-27
**Agent**: Arthur (Domain Consultant)
**Backtrack Target**: step-02-refinement-interaction.md
**Output**: Validation Report + Final Documents (or Backtrack to Step 2)

